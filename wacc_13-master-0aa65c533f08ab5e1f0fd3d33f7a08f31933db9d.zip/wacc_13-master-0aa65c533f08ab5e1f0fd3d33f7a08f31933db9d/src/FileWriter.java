import BackEnd.Instructions.DirectiveInstruction;
import BackEnd.Instructions.Instruction;
import BackEnd.Instructions.LabelInstruction;
import BackEnd.Instructions.MessageLabel;
import BackEnd.Instructions.PrintLabel;
import BackEnd.Program;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;

class FileWriter {

  private final PrintWriter file;

  FileWriter(String fileName){
    try {

      String[] tokens = fileName.split("\\.");
      tokens = tokens[0].split("/");
      String assemblyFileName = tokens[tokens.length-1] + ".s";

      this.file = new PrintWriter(assemblyFileName,
          "UTF-8");

    } catch (FileNotFoundException | UnsupportedEncodingException e) {
      throw new RuntimeException("Error creating file");
    }
  }

  void writeToFile(Program program) {
    List<Instruction> instructions = program.getInstructions();
    if (instructions == null) {
      // No commands so exit and close file
      file.close();
      return;
    }

    // Print all commands with correct indentation
    for (Instruction instruction : instructions) {

      if (instruction instanceof DirectiveInstruction || instruction instanceof LabelInstruction || instruction instanceof PrintLabel || instruction instanceof MessageLabel){
        file.println(instruction.generateCode() + "\n");
      }
      else {
        file.println("\t" + instruction.generateCode());

      }

    }

    file.close();
  }

}
