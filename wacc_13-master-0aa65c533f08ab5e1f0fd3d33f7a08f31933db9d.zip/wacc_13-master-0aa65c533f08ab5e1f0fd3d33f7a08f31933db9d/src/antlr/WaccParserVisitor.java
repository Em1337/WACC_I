// Generated from ./WaccParser.g4 by ANTLR 4.4
package antlr;
import org.antlr.v4.runtime.misc.NotNull;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link WaccParserParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface WaccParserVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by the {@code unaryOperationExpr}
	 * labeled alternative in {@link WaccParserParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryOperationExpr(@NotNull WaccParserParser.UnaryOperationExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#unaryexpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryexpr(@NotNull WaccParserParser.UnaryexprContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#charltrl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharltrl(@NotNull WaccParserParser.CharltrlContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryMul}
	 * labeled alternative in {@link WaccParserParser#binaryoper1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryMul(@NotNull WaccParserParser.BinaryMulContext ctx);
	/**
	 * Visit a parse tree produced by the {@code skipStatement}
	 * labeled alternative in {@link WaccParserParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSkipStatement(@NotNull WaccParserParser.SkipStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#ident}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdent(@NotNull WaccParserParser.IdentContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#arrayltrl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrayltrl(@NotNull WaccParserParser.ArrayltrlContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assignrhsArrayLtrl}
	 * labeled alternative in {@link WaccParserParser#assignrhs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignrhsArrayLtrl(@NotNull WaccParserParser.AssignrhsArrayLtrlContext ctx);
	/**
	 * Visit a parse tree produced by the {@code readStatement}
	 * labeled alternative in {@link WaccParserParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReadStatement(@NotNull WaccParserParser.ReadStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#intltrl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntltrl(@NotNull WaccParserParser.IntltrlContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(@NotNull WaccParserParser.ProgramContext ctx);
	/**
	 * Visit a parse tree produced by the {@code typeBase}
	 * labeled alternative in {@link WaccParserParser#type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTypeBase(@NotNull WaccParserParser.TypeBaseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code identExpr}
	 * labeled alternative in {@link WaccParserParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdentExpr(@NotNull WaccParserParser.IdentExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assignrhsPairelem}
	 * labeled alternative in {@link WaccParserParser#assignrhs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignrhsPairelem(@NotNull WaccParserParser.AssignrhsPairelemContext ctx);
	/**
	 * Visit a parse tree produced by the {@code typePair}
	 * labeled alternative in {@link WaccParserParser#type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTypePair(@NotNull WaccParserParser.TypePairContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryChr}
	 * labeled alternative in {@link WaccParserParser#unaryoper}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryChr(@NotNull WaccParserParser.UnaryChrContext ctx);
	/**
	 * Visit a parse tree produced by the {@code pairLiteral}
	 * labeled alternative in {@link WaccParserParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPairLiteral(@NotNull WaccParserParser.PairLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryGTE}
	 * labeled alternative in {@link WaccParserParser#binaryoper3}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryGTE(@NotNull WaccParserParser.BinaryGTEContext ctx);
	/**
	 * Visit a parse tree produced by the {@code logicalAnd}
	 * labeled alternative in {@link WaccParserParser#logicaloper}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogicalAnd(@NotNull WaccParserParser.LogicalAndContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#paramlist}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParamlist(@NotNull WaccParserParser.ParamlistContext ctx);
	/**
	 * Visit a parse tree produced by the {@code pairElemFst}
	 * labeled alternative in {@link WaccParserParser#pairelem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPairElemFst(@NotNull WaccParserParser.PairElemFstContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#strltrl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStrltrl(@NotNull WaccParserParser.StrltrlContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryDiv}
	 * labeled alternative in {@link WaccParserParser#binaryoper1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryDiv(@NotNull WaccParserParser.BinaryDivContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryEquals}
	 * labeled alternative in {@link WaccParserParser#binaryoper4}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryEquals(@NotNull WaccParserParser.BinaryEqualsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code printStatement}
	 * labeled alternative in {@link WaccParserParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrintStatement(@NotNull WaccParserParser.PrintStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#arraytype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArraytype(@NotNull WaccParserParser.ArraytypeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assignlhsArrayElem}
	 * labeled alternative in {@link WaccParserParser#assignlhs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignlhsArrayElem(@NotNull WaccParserParser.AssignlhsArrayElemContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryMinus}
	 * labeled alternative in {@link WaccParserParser#unaryoper}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryMinus(@NotNull WaccParserParser.UnaryMinusContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assignrhsPair}
	 * labeled alternative in {@link WaccParserParser#assignrhs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignrhsPair(@NotNull WaccParserParser.AssignrhsPairContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#boolltrl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolltrl(@NotNull WaccParserParser.BoolltrlContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryMinus}
	 * labeled alternative in {@link WaccParserParser#binaryoper2}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryMinus(@NotNull WaccParserParser.BinaryMinusContext ctx);
	/**
	 * Visit a parse tree produced by the {@code logicalOr}
	 * labeled alternative in {@link WaccParserParser#logicaloper}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogicalOr(@NotNull WaccParserParser.LogicalOrContext ctx);
	/**
	 * Visit a parse tree produced by the {@code printlnStatement}
	 * labeled alternative in {@link WaccParserParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrintlnStatement(@NotNull WaccParserParser.PrintlnStatementContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryLen}
	 * labeled alternative in {@link WaccParserParser#unaryoper}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryLen(@NotNull WaccParserParser.UnaryLenContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryPlus}
	 * labeled alternative in {@link WaccParserParser#binaryoper2}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryPlus(@NotNull WaccParserParser.BinaryPlusContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assignrhsFunctionCall}
	 * labeled alternative in {@link WaccParserParser#assignrhs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignrhsFunctionCall(@NotNull WaccParserParser.AssignrhsFunctionCallContext ctx);
	/**
	 * Visit a parse tree produced by the {@code pairelemTypeBase}
	 * labeled alternative in {@link WaccParserParser#pairelemtype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPairelemTypeBase(@NotNull WaccParserParser.PairelemTypeBaseContext ctx);
	/**
	 * Visit a parse tree produced by the {@code pairelemTypePair}
	 * labeled alternative in {@link WaccParserParser#pairelemtype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPairelemTypePair(@NotNull WaccParserParser.PairelemTypePairContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryMod}
	 * labeled alternative in {@link WaccParserParser#binaryoper1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryMod(@NotNull WaccParserParser.BinaryModContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryST}
	 * labeled alternative in {@link WaccParserParser#binaryoper3}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryST(@NotNull WaccParserParser.BinarySTContext ctx);
	/**
	 * Visit a parse tree produced by the {@code declareStatement}
	 * labeled alternative in {@link WaccParserParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclareStatement(@NotNull WaccParserParser.DeclareStatementContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assignlhsIdent}
	 * labeled alternative in {@link WaccParserParser#assignlhs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignlhsIdent(@NotNull WaccParserParser.AssignlhsIdentContext ctx);
	/**
	 * Visit a parse tree produced by the {@code exitStatement}
	 * labeled alternative in {@link WaccParserParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExitStatement(@NotNull WaccParserParser.ExitStatementContext ctx);
	/**
	 * Visit a parse tree produced by the {@code logicalOperationExpr}
	 * labeled alternative in {@link WaccParserParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLogicalOperationExpr(@NotNull WaccParserParser.LogicalOperationExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code arrayLiteral}
	 * labeled alternative in {@link WaccParserParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrayLiteral(@NotNull WaccParserParser.ArrayLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#nestedarray}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNestedarray(@NotNull WaccParserParser.NestedarrayContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryOperation3Expr}
	 * labeled alternative in {@link WaccParserParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryOperation3Expr(@NotNull WaccParserParser.BinaryOperation3ExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code returnStatement}
	 * labeled alternative in {@link WaccParserParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturnStatement(@NotNull WaccParserParser.ReturnStatementContext ctx);
	/**
	 * Visit a parse tree produced by the {@code boolLiteral}
	 * labeled alternative in {@link WaccParserParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolLiteral(@NotNull WaccParserParser.BoolLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryGT}
	 * labeled alternative in {@link WaccParserParser#binaryoper3}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryGT(@NotNull WaccParserParser.BinaryGTContext ctx);
	/**
	 * Visit a parse tree produced by the {@code freeStatement}
	 * labeled alternative in {@link WaccParserParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFreeStatement(@NotNull WaccParserParser.FreeStatementContext ctx);
	/**
	 * Visit a parse tree produced by the {@code bracketedExpr}
	 * labeled alternative in {@link WaccParserParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBracketedExpr(@NotNull WaccParserParser.BracketedExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assignrhsExpr}
	 * labeled alternative in {@link WaccParserParser#assignrhs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignrhsExpr(@NotNull WaccParserParser.AssignrhsExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code beginStatement}
	 * labeled alternative in {@link WaccParserParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBeginStatement(@NotNull WaccParserParser.BeginStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#param}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParam(@NotNull WaccParserParser.ParamContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryOperation4Expr}
	 * labeled alternative in {@link WaccParserParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryOperation4Expr(@NotNull WaccParserParser.BinaryOperation4ExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#arglist}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArglist(@NotNull WaccParserParser.ArglistContext ctx);
	/**
	 * Visit a parse tree produced by the {@code strLiteral}
	 * labeled alternative in {@link WaccParserParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStrLiteral(@NotNull WaccParserParser.StrLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binarySTE}
	 * labeled alternative in {@link WaccParserParser#binaryoper3}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinarySTE(@NotNull WaccParserParser.BinarySTEContext ctx);
	/**
	 * Visit a parse tree produced by the {@code intLiteral}
	 * labeled alternative in {@link WaccParserParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntLiteral(@NotNull WaccParserParser.IntLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryOrd}
	 * labeled alternative in {@link WaccParserParser#unaryoper}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryOrd(@NotNull WaccParserParser.UnaryOrdContext ctx);
	/**
	 * Visit a parse tree produced by the {@code charLiteral}
	 * labeled alternative in {@link WaccParserParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharLiteral(@NotNull WaccParserParser.CharLiteralContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ifStatement}
	 * labeled alternative in {@link WaccParserParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfStatement(@NotNull WaccParserParser.IfStatementContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryOperation1Expr}
	 * labeled alternative in {@link WaccParserParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryOperation1Expr(@NotNull WaccParserParser.BinaryOperation1ExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryNotEquals}
	 * labeled alternative in {@link WaccParserParser#binaryoper4}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryNotEquals(@NotNull WaccParserParser.BinaryNotEqualsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code pairelemTypeArray}
	 * labeled alternative in {@link WaccParserParser#pairelemtype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPairelemTypeArray(@NotNull WaccParserParser.PairelemTypeArrayContext ctx);
	/**
	 * Visit a parse tree produced by the {@code seqComposition}
	 * labeled alternative in {@link WaccParserParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSeqComposition(@NotNull WaccParserParser.SeqCompositionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code whileStatement}
	 * labeled alternative in {@link WaccParserParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhileStatement(@NotNull WaccParserParser.WhileStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#arrayelem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrayelem(@NotNull WaccParserParser.ArrayelemContext ctx);
	/**
	 * Visit a parse tree produced by the {@code typeArray}
	 * labeled alternative in {@link WaccParserParser#type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTypeArray(@NotNull WaccParserParser.TypeArrayContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#func}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunc(@NotNull WaccParserParser.FuncContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assignlhsPairelem}
	 * labeled alternative in {@link WaccParserParser#assignlhs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignlhsPairelem(@NotNull WaccParserParser.AssignlhsPairelemContext ctx);
	/**
	 * Visit a parse tree produced by the {@code pairElemSnd}
	 * labeled alternative in {@link WaccParserParser#pairelem}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPairElemSnd(@NotNull WaccParserParser.PairElemSndContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assignStatement}
	 * labeled alternative in {@link WaccParserParser#stat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignStatement(@NotNull WaccParserParser.AssignStatementContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#basetype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBasetype(@NotNull WaccParserParser.BasetypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#pairltrl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPairltrl(@NotNull WaccParserParser.PairltrlContext ctx);
	/**
	 * Visit a parse tree produced by the {@code binaryOperation2Expr}
	 * labeled alternative in {@link WaccParserParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBinaryOperation2Expr(@NotNull WaccParserParser.BinaryOperation2ExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link WaccParserParser#pairtype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPairtype(@NotNull WaccParserParser.PairtypeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code unaryNot}
	 * labeled alternative in {@link WaccParserParser#unaryoper}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUnaryNot(@NotNull WaccParserParser.UnaryNotContext ctx);
}