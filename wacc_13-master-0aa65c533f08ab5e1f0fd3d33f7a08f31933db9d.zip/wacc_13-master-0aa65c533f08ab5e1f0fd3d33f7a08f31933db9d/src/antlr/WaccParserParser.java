// Generated from ./WaccParser.g4 by ANTLR 4.4
package antlr;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class WaccParserParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.4", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, WS=2, BEGIN=3, END=4, IF=5, THEN=6, ELSE=7, FI=8, WHILE=9, DO=10, 
		DONE=11, PRINT=12, PRINTLN=13, EXIT=14, RETURN=15, FREE=16, READ=17, SKIP=18, 
		NEWPAIR=19, CALL=20, FST=21, SND=22, PAIR=23, MUL=24, DIV=25, MOD=26, 
		PLUS=27, MINUS=28, EQUALS=29, GT=30, GTE=31, ST=32, STE=33, EQUALITY=34, 
		NEQUALITY=35, AND=36, OR=37, NOT=38, LEN=39, ORD=40, CHR=41, OPENBRACKET=42, 
		CLOSEBRACKET=43, OPENPAREN=44, CLOSEPAREN=45, OPENBRACE=46, CLOSEBRACE=47, 
		SEMICOLON=48, COMMA=49, BASETYPE=50, STRLTRL=51, PAIRLTRL=52, BOOLLTRL=53, 
		CHARLTRL=54, INT=55, IDENT=56, CHAR=57, COMMENT=58;
	public static final String[] tokenNames = {
		"<INVALID>", "'is'", "WS", "'begin'", "'end'", "'if'", "'then'", "'else'", 
		"'fi'", "'while'", "'do'", "'done'", "'print'", "'println'", "'exit'", 
		"'return'", "'free'", "'read'", "'skip'", "'newpair'", "'call'", "'fst'", 
		"'snd'", "'pair'", "'*'", "'/'", "'%'", "'+'", "'-'", "'='", "'>'", "'>='", 
		"'<'", "'<='", "'=='", "'!='", "'&&'", "'||'", "'!'", "'len'", "'ord'", 
		"'chr'", "'['", "']'", "'('", "')'", "'{'", "'}'", "';'", "','", "BASETYPE", 
		"STRLTRL", "'null'", "BOOLLTRL", "CHARLTRL", "INT", "IDENT", "CHAR", "COMMENT"
	};
	public static final int
		RULE_program = 0, RULE_func = 1, RULE_paramlist = 2, RULE_param = 3, RULE_stat = 4, 
		RULE_assignlhs = 5, RULE_assignrhs = 6, RULE_arglist = 7, RULE_pairelem = 8, 
		RULE_type = 9, RULE_nestedarray = 10, RULE_basetype = 11, RULE_arraytype = 12, 
		RULE_pairtype = 13, RULE_pairelemtype = 14, RULE_expr = 15, RULE_arrayelem = 16, 
		RULE_intltrl = 17, RULE_boolltrl = 18, RULE_charltrl = 19, RULE_strltrl = 20, 
		RULE_pairltrl = 21, RULE_arrayltrl = 22, RULE_ident = 23, RULE_unaryoper = 24, 
		RULE_unaryexpr = 25, RULE_binaryoper1 = 26, RULE_binaryoper2 = 27, RULE_binaryoper3 = 28, 
		RULE_binaryoper4 = 29, RULE_logicaloper = 30;
	public static final String[] ruleNames = {
		"program", "func", "paramlist", "param", "stat", "assignlhs", "assignrhs", 
		"arglist", "pairelem", "type", "nestedarray", "basetype", "arraytype", 
		"pairtype", "pairelemtype", "expr", "arrayelem", "intltrl", "boolltrl", 
		"charltrl", "strltrl", "pairltrl", "arrayltrl", "ident", "unaryoper", 
		"unaryexpr", "binaryoper1", "binaryoper2", "binaryoper3", "binaryoper4", 
		"logicaloper"
	};

	@Override
	public String getGrammarFileName() { return "WaccParser.g4"; }

	@Override
	public String[] getTokenNames() { return tokenNames; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public WaccParserParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class ProgramContext extends ParserRuleContext {
		public TerminalNode EOF() { return getToken(WaccParserParser.EOF, 0); }
		public List<FuncContext> func() {
			return getRuleContexts(FuncContext.class);
		}
		public FuncContext func(int i) {
			return getRuleContext(FuncContext.class,i);
		}
		public StatContext stat() {
			return getRuleContext(StatContext.class,0);
		}
		public ProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_program; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitProgram(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ProgramContext program() throws RecognitionException {
		ProgramContext _localctx = new ProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_program);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(62); match(BEGIN);
			setState(66);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,0,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(63); func();
					}
					} 
				}
				setState(68);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,0,_ctx);
			}
			setState(69); stat(0);
			setState(70); match(END);
			setState(71); match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FuncContext extends ParserRuleContext {
		public ParamlistContext paramlist() {
			return getRuleContext(ParamlistContext.class,0);
		}
		public TerminalNode CLOSEPAREN() { return getToken(WaccParserParser.CLOSEPAREN, 0); }
		public IdentContext ident() {
			return getRuleContext(IdentContext.class,0);
		}
		public TerminalNode OPENPAREN() { return getToken(WaccParserParser.OPENPAREN, 0); }
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public StatContext stat() {
			return getRuleContext(StatContext.class,0);
		}
		public FuncContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_func; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitFunc(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FuncContext func() throws RecognitionException {
		FuncContext _localctx = new FuncContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_func);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(73); type();
			setState(74); ident();
			setState(75); match(OPENPAREN);
			setState(77);
			_la = _input.LA(1);
			if (_la==PAIR || _la==BASETYPE) {
				{
				setState(76); paramlist();
				}
			}

			setState(79); match(CLOSEPAREN);
			setState(80); match(T__0);
			setState(81); stat(0);
			setState(82); match(END);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParamlistContext extends ParserRuleContext {
		public List<ParamContext> param() {
			return getRuleContexts(ParamContext.class);
		}
		public List<TerminalNode> COMMA() { return getTokens(WaccParserParser.COMMA); }
		public ParamContext param(int i) {
			return getRuleContext(ParamContext.class,i);
		}
		public TerminalNode COMMA(int i) {
			return getToken(WaccParserParser.COMMA, i);
		}
		public ParamlistContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_paramlist; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitParamlist(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParamlistContext paramlist() throws RecognitionException {
		ParamlistContext _localctx = new ParamlistContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_paramlist);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(84); param();
			setState(89);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(85); match(COMMA);
				setState(86); param();
				}
				}
				setState(91);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ParamContext extends ParserRuleContext {
		public IdentContext ident() {
			return getRuleContext(IdentContext.class,0);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public ParamContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_param; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitParam(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ParamContext param() throws RecognitionException {
		ParamContext _localctx = new ParamContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_param);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(92); type();
			setState(93); ident();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatContext extends ParserRuleContext {
		public StatContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_stat; }
	 
		public StatContext() { }
		public void copyFrom(StatContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class SkipStatementContext extends StatContext {
		public SkipStatementContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitSkipStatement(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class DeclareStatementContext extends StatContext {
		public TerminalNode EQUALS() { return getToken(WaccParserParser.EQUALS, 0); }
		public AssignrhsContext assignrhs() {
			return getRuleContext(AssignrhsContext.class,0);
		}
		public IdentContext ident() {
			return getRuleContext(IdentContext.class,0);
		}
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public DeclareStatementContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitDeclareStatement(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ExitStatementContext extends StatContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public ExitStatementContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitExitStatement(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ReadStatementContext extends StatContext {
		public AssignlhsContext assignlhs() {
			return getRuleContext(AssignlhsContext.class,0);
		}
		public ReadStatementContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitReadStatement(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ReturnStatementContext extends StatContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public ReturnStatementContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitReturnStatement(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class IfStatementContext extends StatContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public StatContext stat(int i) {
			return getRuleContext(StatContext.class,i);
		}
		public List<StatContext> stat() {
			return getRuleContexts(StatContext.class);
		}
		public IfStatementContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitIfStatement(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class FreeStatementContext extends StatContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public FreeStatementContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitFreeStatement(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class SeqCompositionContext extends StatContext {
		public TerminalNode SEMICOLON() { return getToken(WaccParserParser.SEMICOLON, 0); }
		public StatContext stat(int i) {
			return getRuleContext(StatContext.class,i);
		}
		public List<StatContext> stat() {
			return getRuleContexts(StatContext.class);
		}
		public SeqCompositionContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitSeqComposition(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class WhileStatementContext extends StatContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public StatContext stat() {
			return getRuleContext(StatContext.class,0);
		}
		public WhileStatementContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitWhileStatement(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PrintStatementContext extends StatContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public PrintStatementContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitPrintStatement(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BeginStatementContext extends StatContext {
		public StatContext stat() {
			return getRuleContext(StatContext.class,0);
		}
		public BeginStatementContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBeginStatement(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class AssignStatementContext extends StatContext {
		public TerminalNode EQUALS() { return getToken(WaccParserParser.EQUALS, 0); }
		public AssignlhsContext assignlhs() {
			return getRuleContext(AssignlhsContext.class,0);
		}
		public AssignrhsContext assignrhs() {
			return getRuleContext(AssignrhsContext.class,0);
		}
		public AssignStatementContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitAssignStatement(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PrintlnStatementContext extends StatContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public PrintlnStatementContext(StatContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitPrintlnStatement(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StatContext stat() throws RecognitionException {
		return stat(0);
	}

	private StatContext stat(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		StatContext _localctx = new StatContext(_ctx, _parentState);
		StatContext _prevctx = _localctx;
		int _startState = 8;
		enterRecursionRule(_localctx, 8, RULE_stat, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(136);
			switch (_input.LA(1)) {
			case SKIP:
				{
				_localctx = new SkipStatementContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(96); match(SKIP);
				}
				break;
			case PAIR:
			case BASETYPE:
				{
				_localctx = new DeclareStatementContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(97); type();
				setState(98); ident();
				setState(99); match(EQUALS);
				setState(100); assignrhs();
				}
				break;
			case FST:
			case SND:
			case IDENT:
				{
				_localctx = new AssignStatementContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(102); assignlhs();
				setState(103); match(EQUALS);
				setState(104); assignrhs();
				}
				break;
			case READ:
				{
				_localctx = new ReadStatementContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(106); match(READ);
				setState(107); assignlhs();
				}
				break;
			case FREE:
				{
				_localctx = new FreeStatementContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(108); match(FREE);
				setState(109); expr(0);
				}
				break;
			case EXIT:
				{
				_localctx = new ExitStatementContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(110); match(EXIT);
				setState(111); expr(0);
				}
				break;
			case RETURN:
				{
				_localctx = new ReturnStatementContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(112); match(RETURN);
				setState(113); expr(0);
				}
				break;
			case PRINT:
				{
				_localctx = new PrintStatementContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(114); match(PRINT);
				setState(115); expr(0);
				}
				break;
			case PRINTLN:
				{
				_localctx = new PrintlnStatementContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(116); match(PRINTLN);
				setState(117); expr(0);
				}
				break;
			case IF:
				{
				_localctx = new IfStatementContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(118); match(IF);
				setState(119); expr(0);
				setState(120); match(THEN);
				setState(121); stat(0);
				setState(122); match(ELSE);
				setState(123); stat(0);
				setState(124); match(FI);
				}
				break;
			case WHILE:
				{
				_localctx = new WhileStatementContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(126); match(WHILE);
				setState(127); expr(0);
				setState(128); match(DO);
				setState(129); stat(0);
				setState(130); match(DONE);
				}
				break;
			case BEGIN:
				{
				_localctx = new BeginStatementContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(132); match(BEGIN);
				setState(133); stat(0);
				setState(134); match(END);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(143);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new SeqCompositionContext(new StatContext(_parentctx, _parentState));
					pushNewRecursionContext(_localctx, _startState, RULE_stat);
					setState(138);
					if (!(precpred(_ctx, 1))) throw new FailedPredicateException(this, "precpred(_ctx, 1)");
					setState(139); match(SEMICOLON);
					setState(140); stat(2);
					}
					} 
				}
				setState(145);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class AssignlhsContext extends ParserRuleContext {
		public AssignlhsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignlhs; }
	 
		public AssignlhsContext() { }
		public void copyFrom(AssignlhsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class AssignlhsIdentContext extends AssignlhsContext {
		public IdentContext ident() {
			return getRuleContext(IdentContext.class,0);
		}
		public AssignlhsIdentContext(AssignlhsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitAssignlhsIdent(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class AssignlhsPairelemContext extends AssignlhsContext {
		public PairelemContext pairelem() {
			return getRuleContext(PairelemContext.class,0);
		}
		public AssignlhsPairelemContext(AssignlhsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitAssignlhsPairelem(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class AssignlhsArrayElemContext extends AssignlhsContext {
		public ArrayelemContext arrayelem() {
			return getRuleContext(ArrayelemContext.class,0);
		}
		public AssignlhsArrayElemContext(AssignlhsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitAssignlhsArrayElem(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssignlhsContext assignlhs() throws RecognitionException {
		AssignlhsContext _localctx = new AssignlhsContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_assignlhs);
		try {
			setState(149);
			switch ( getInterpreter().adaptivePredict(_input,5,_ctx) ) {
			case 1:
				_localctx = new AssignlhsIdentContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(146); ident();
				}
				break;
			case 2:
				_localctx = new AssignlhsArrayElemContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(147); arrayelem();
				}
				break;
			case 3:
				_localctx = new AssignlhsPairelemContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(148); pairelem();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AssignrhsContext extends ParserRuleContext {
		public AssignrhsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignrhs; }
	 
		public AssignrhsContext() { }
		public void copyFrom(AssignrhsContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class AssignrhsFunctionCallContext extends AssignrhsContext {
		public TerminalNode CLOSEPAREN() { return getToken(WaccParserParser.CLOSEPAREN, 0); }
		public IdentContext ident() {
			return getRuleContext(IdentContext.class,0);
		}
		public TerminalNode OPENPAREN() { return getToken(WaccParserParser.OPENPAREN, 0); }
		public ArglistContext arglist() {
			return getRuleContext(ArglistContext.class,0);
		}
		public AssignrhsFunctionCallContext(AssignrhsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitAssignrhsFunctionCall(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class AssignrhsPairelemContext extends AssignrhsContext {
		public PairelemContext pairelem() {
			return getRuleContext(PairelemContext.class,0);
		}
		public AssignrhsPairelemContext(AssignrhsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitAssignrhsPairelem(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class AssignrhsArrayLtrlContext extends AssignrhsContext {
		public ArrayltrlContext arrayltrl() {
			return getRuleContext(ArrayltrlContext.class,0);
		}
		public AssignrhsArrayLtrlContext(AssignrhsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitAssignrhsArrayLtrl(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class AssignrhsPairContext extends AssignrhsContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public TerminalNode CLOSEPAREN() { return getToken(WaccParserParser.CLOSEPAREN, 0); }
		public TerminalNode COMMA() { return getToken(WaccParserParser.COMMA, 0); }
		public TerminalNode OPENPAREN() { return getToken(WaccParserParser.OPENPAREN, 0); }
		public AssignrhsPairContext(AssignrhsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitAssignrhsPair(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class AssignrhsExprContext extends AssignrhsContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public AssignrhsExprContext(AssignrhsContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitAssignrhsExpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssignrhsContext assignrhs() throws RecognitionException {
		AssignrhsContext _localctx = new AssignrhsContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_assignrhs);
		int _la;
		try {
			setState(169);
			switch (_input.LA(1)) {
			case PLUS:
			case MINUS:
			case NOT:
			case LEN:
			case ORD:
			case CHR:
			case OPENPAREN:
			case STRLTRL:
			case PAIRLTRL:
			case BOOLLTRL:
			case CHARLTRL:
			case INT:
			case IDENT:
				_localctx = new AssignrhsExprContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(151); expr(0);
				}
				break;
			case OPENBRACKET:
				_localctx = new AssignrhsArrayLtrlContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(152); arrayltrl();
				}
				break;
			case NEWPAIR:
				_localctx = new AssignrhsPairContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(153); match(NEWPAIR);
				setState(154); match(OPENPAREN);
				setState(155); expr(0);
				setState(156); match(COMMA);
				setState(157); expr(0);
				setState(158); match(CLOSEPAREN);
				}
				break;
			case FST:
			case SND:
				_localctx = new AssignrhsPairelemContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(160); pairelem();
				}
				break;
			case CALL:
				_localctx = new AssignrhsFunctionCallContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(161); match(CALL);
				setState(162); ident();
				setState(163); match(OPENPAREN);
				setState(165);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << PLUS) | (1L << MINUS) | (1L << NOT) | (1L << LEN) | (1L << ORD) | (1L << CHR) | (1L << OPENPAREN) | (1L << STRLTRL) | (1L << PAIRLTRL) | (1L << BOOLLTRL) | (1L << CHARLTRL) | (1L << INT) | (1L << IDENT))) != 0)) {
					{
					setState(164); arglist();
					}
				}

				setState(167); match(CLOSEPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArglistContext extends ParserRuleContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(WaccParserParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(WaccParserParser.COMMA, i);
		}
		public ArglistContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arglist; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitArglist(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArglistContext arglist() throws RecognitionException {
		ArglistContext _localctx = new ArglistContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_arglist);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(171); expr(0);
			setState(176);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(172); match(COMMA);
				setState(173); expr(0);
				}
				}
				setState(178);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PairelemContext extends ParserRuleContext {
		public PairelemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pairelem; }
	 
		public PairelemContext() { }
		public void copyFrom(PairelemContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class PairElemSndContext extends PairelemContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public PairElemSndContext(PairelemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitPairElemSnd(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PairElemFstContext extends PairelemContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public PairElemFstContext(PairelemContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitPairElemFst(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PairelemContext pairelem() throws RecognitionException {
		PairelemContext _localctx = new PairelemContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_pairelem);
		try {
			setState(183);
			switch (_input.LA(1)) {
			case FST:
				_localctx = new PairElemFstContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(179); match(FST);
				setState(180); expr(0);
				}
				break;
			case SND:
				_localctx = new PairElemSndContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(181); match(SND);
				setState(182); expr(0);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TypeContext extends ParserRuleContext {
		public TypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type; }
	 
		public TypeContext() { }
		public void copyFrom(TypeContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class TypeArrayContext extends TypeContext {
		public ArraytypeContext arraytype() {
			return getRuleContext(ArraytypeContext.class,0);
		}
		public TypeArrayContext(TypeContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitTypeArray(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class TypePairContext extends TypeContext {
		public PairtypeContext pairtype() {
			return getRuleContext(PairtypeContext.class,0);
		}
		public TypePairContext(TypeContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitTypePair(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class TypeBaseContext extends TypeContext {
		public BasetypeContext basetype() {
			return getRuleContext(BasetypeContext.class,0);
		}
		public TypeBaseContext(TypeContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitTypeBase(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TypeContext type() throws RecognitionException {
		TypeContext _localctx = new TypeContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_type);
		try {
			setState(188);
			switch ( getInterpreter().adaptivePredict(_input,10,_ctx) ) {
			case 1:
				_localctx = new TypeBaseContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(185); basetype();
				}
				break;
			case 2:
				_localctx = new TypeArrayContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(186); arraytype();
				}
				break;
			case 3:
				_localctx = new TypePairContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(187); pairtype();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NestedarrayContext extends ParserRuleContext {
		public List<NestedarrayContext> nestedarray() {
			return getRuleContexts(NestedarrayContext.class);
		}
		public TerminalNode CLOSEBRACKET(int i) {
			return getToken(WaccParserParser.CLOSEBRACKET, i);
		}
		public List<TerminalNode> OPENBRACKET() { return getTokens(WaccParserParser.OPENBRACKET); }
		public NestedarrayContext nestedarray(int i) {
			return getRuleContext(NestedarrayContext.class,i);
		}
		public List<TerminalNode> CLOSEBRACKET() { return getTokens(WaccParserParser.CLOSEBRACKET); }
		public TerminalNode OPENBRACKET(int i) {
			return getToken(WaccParserParser.OPENBRACKET, i);
		}
		public NestedarrayContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_nestedarray; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitNestedarray(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NestedarrayContext nestedarray() throws RecognitionException {
		NestedarrayContext _localctx = new NestedarrayContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_nestedarray);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(195);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,11,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(190); match(OPENBRACKET);
					setState(191); match(CLOSEBRACKET);
					setState(192); nestedarray();
					}
					} 
				}
				setState(197);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,11,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BasetypeContext extends ParserRuleContext {
		public TerminalNode BASETYPE() { return getToken(WaccParserParser.BASETYPE, 0); }
		public BasetypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_basetype; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBasetype(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BasetypeContext basetype() throws RecognitionException {
		BasetypeContext _localctx = new BasetypeContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_basetype);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(198); match(BASETYPE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArraytypeContext extends ParserRuleContext {
		public NestedarrayContext nestedarray() {
			return getRuleContext(NestedarrayContext.class,0);
		}
		public TerminalNode OPENBRACKET() { return getToken(WaccParserParser.OPENBRACKET, 0); }
		public PairtypeContext pairtype() {
			return getRuleContext(PairtypeContext.class,0);
		}
		public BasetypeContext basetype() {
			return getRuleContext(BasetypeContext.class,0);
		}
		public TerminalNode CLOSEBRACKET() { return getToken(WaccParserParser.CLOSEBRACKET, 0); }
		public ArraytypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arraytype; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitArraytype(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArraytypeContext arraytype() throws RecognitionException {
		ArraytypeContext _localctx = new ArraytypeContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_arraytype);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(202);
			switch (_input.LA(1)) {
			case BASETYPE:
				{
				setState(200); basetype();
				}
				break;
			case PAIR:
				{
				setState(201); pairtype();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(204); match(OPENBRACKET);
			setState(205); match(CLOSEBRACKET);
			setState(206); nestedarray();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PairtypeContext extends ParserRuleContext {
		public List<PairelemtypeContext> pairelemtype() {
			return getRuleContexts(PairelemtypeContext.class);
		}
		public PairelemtypeContext pairelemtype(int i) {
			return getRuleContext(PairelemtypeContext.class,i);
		}
		public TerminalNode CLOSEPAREN() { return getToken(WaccParserParser.CLOSEPAREN, 0); }
		public TerminalNode COMMA() { return getToken(WaccParserParser.COMMA, 0); }
		public TerminalNode OPENPAREN() { return getToken(WaccParserParser.OPENPAREN, 0); }
		public PairtypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pairtype; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitPairtype(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PairtypeContext pairtype() throws RecognitionException {
		PairtypeContext _localctx = new PairtypeContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_pairtype);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(208); match(PAIR);
			setState(209); match(OPENPAREN);
			setState(210); pairelemtype();
			setState(211); match(COMMA);
			setState(212); pairelemtype();
			setState(213); match(CLOSEPAREN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PairelemtypeContext extends ParserRuleContext {
		public PairelemtypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pairelemtype; }
	 
		public PairelemtypeContext() { }
		public void copyFrom(PairelemtypeContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class PairelemTypeBaseContext extends PairelemtypeContext {
		public BasetypeContext basetype() {
			return getRuleContext(BasetypeContext.class,0);
		}
		public PairelemTypeBaseContext(PairelemtypeContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitPairelemTypeBase(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PairelemTypePairContext extends PairelemtypeContext {
		public PairelemTypePairContext(PairelemtypeContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitPairelemTypePair(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PairelemTypeArrayContext extends PairelemtypeContext {
		public ArraytypeContext arraytype() {
			return getRuleContext(ArraytypeContext.class,0);
		}
		public PairelemTypeArrayContext(PairelemtypeContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitPairelemTypeArray(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PairelemtypeContext pairelemtype() throws RecognitionException {
		PairelemtypeContext _localctx = new PairelemtypeContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_pairelemtype);
		try {
			setState(218);
			switch ( getInterpreter().adaptivePredict(_input,13,_ctx) ) {
			case 1:
				_localctx = new PairelemTypeBaseContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(215); basetype();
				}
				break;
			case 2:
				_localctx = new PairelemTypeArrayContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(216); arraytype();
				}
				break;
			case 3:
				_localctx = new PairelemTypePairContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(217); match(PAIR);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExprContext extends ParserRuleContext {
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
	 
		public ExprContext() { }
		public void copyFrom(ExprContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class StrLiteralContext extends ExprContext {
		public StrltrlContext strltrl() {
			return getRuleContext(StrltrlContext.class,0);
		}
		public StrLiteralContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitStrLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class UnaryOperationExprContext extends ExprContext {
		public UnaryexprContext unaryexpr() {
			return getRuleContext(UnaryexprContext.class,0);
		}
		public UnaryOperationExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitUnaryOperationExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class LogicalOperationExprContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public LogicaloperContext logicaloper() {
			return getRuleContext(LogicaloperContext.class,0);
		}
		public LogicalOperationExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitLogicalOperationExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class ArrayLiteralContext extends ExprContext {
		public ArrayelemContext arrayelem() {
			return getRuleContext(ArrayelemContext.class,0);
		}
		public ArrayLiteralContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitArrayLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class PairLiteralContext extends ExprContext {
		public PairltrlContext pairltrl() {
			return getRuleContext(PairltrlContext.class,0);
		}
		public PairLiteralContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitPairLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class IntLiteralContext extends ExprContext {
		public IntltrlContext intltrl() {
			return getRuleContext(IntltrlContext.class,0);
		}
		public IntLiteralContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitIntLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class CharLiteralContext extends ExprContext {
		public CharltrlContext charltrl() {
			return getRuleContext(CharltrlContext.class,0);
		}
		public CharLiteralContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitCharLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BinaryOperation3ExprContext extends ExprContext {
		public Binaryoper3Context binaryoper3() {
			return getRuleContext(Binaryoper3Context.class,0);
		}
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public BinaryOperation3ExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBinaryOperation3Expr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BinaryOperation1ExprContext extends ExprContext {
		public Binaryoper1Context binaryoper1() {
			return getRuleContext(Binaryoper1Context.class,0);
		}
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public BinaryOperation1ExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBinaryOperation1Expr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BoolLiteralContext extends ExprContext {
		public BoolltrlContext boolltrl() {
			return getRuleContext(BoolltrlContext.class,0);
		}
		public BoolLiteralContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBoolLiteral(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BracketedExprContext extends ExprContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode CLOSEPAREN() { return getToken(WaccParserParser.CLOSEPAREN, 0); }
		public TerminalNode OPENPAREN() { return getToken(WaccParserParser.OPENPAREN, 0); }
		public BracketedExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBracketedExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class IdentExprContext extends ExprContext {
		public IdentContext ident() {
			return getRuleContext(IdentContext.class,0);
		}
		public IdentExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitIdentExpr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BinaryOperation4ExprContext extends ExprContext {
		public Binaryoper4Context binaryoper4() {
			return getRuleContext(Binaryoper4Context.class,0);
		}
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public BinaryOperation4ExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBinaryOperation4Expr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BinaryOperation2ExprContext extends ExprContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public Binaryoper2Context binaryoper2() {
			return getRuleContext(Binaryoper2Context.class,0);
		}
		public BinaryOperation2ExprContext(ExprContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBinaryOperation2Expr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ExprContext expr() throws RecognitionException {
		return expr(0);
	}

	private ExprContext expr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExprContext _localctx = new ExprContext(_ctx, _parentState);
		ExprContext _prevctx = _localctx;
		int _startState = 30;
		enterRecursionRule(_localctx, 30, RULE_expr, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(233);
			switch ( getInterpreter().adaptivePredict(_input,14,_ctx) ) {
			case 1:
				{
				_localctx = new IntLiteralContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(221); intltrl();
				}
				break;
			case 2:
				{
				_localctx = new BoolLiteralContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(222); boolltrl();
				}
				break;
			case 3:
				{
				_localctx = new StrLiteralContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(223); strltrl();
				}
				break;
			case 4:
				{
				_localctx = new CharLiteralContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(224); charltrl();
				}
				break;
			case 5:
				{
				_localctx = new PairLiteralContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(225); pairltrl();
				}
				break;
			case 6:
				{
				_localctx = new ArrayLiteralContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(226); arrayelem();
				}
				break;
			case 7:
				{
				_localctx = new UnaryOperationExprContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(227); unaryexpr();
				}
				break;
			case 8:
				{
				_localctx = new IdentExprContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(228); ident();
				}
				break;
			case 9:
				{
				_localctx = new BracketedExprContext(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(229); match(OPENPAREN);
				setState(230); expr(0);
				setState(231); match(CLOSEPAREN);
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(257);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,16,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(255);
					switch ( getInterpreter().adaptivePredict(_input,15,_ctx) ) {
					case 1:
						{
						_localctx = new BinaryOperation1ExprContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(235);
						if (!(precpred(_ctx, 6))) throw new FailedPredicateException(this, "precpred(_ctx, 6)");
						setState(236); binaryoper1();
						setState(237); expr(7);
						}
						break;
					case 2:
						{
						_localctx = new BinaryOperation2ExprContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(239);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(240); binaryoper2();
						setState(241); expr(6);
						}
						break;
					case 3:
						{
						_localctx = new BinaryOperation3ExprContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(243);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(244); binaryoper3();
						setState(245); expr(5);
						}
						break;
					case 4:
						{
						_localctx = new BinaryOperation4ExprContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(247);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(248); binaryoper4();
						setState(249); expr(4);
						}
						break;
					case 5:
						{
						_localctx = new LogicalOperationExprContext(new ExprContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(251);
						if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
						setState(252); logicaloper();
						setState(253); expr(3);
						}
						break;
					}
					} 
				}
				setState(259);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,16,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class ArrayelemContext extends ParserRuleContext {
		public TerminalNode CLOSEBRACKET(int i) {
			return getToken(WaccParserParser.CLOSEBRACKET, i);
		}
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public List<TerminalNode> OPENBRACKET() { return getTokens(WaccParserParser.OPENBRACKET); }
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public List<TerminalNode> CLOSEBRACKET() { return getTokens(WaccParserParser.CLOSEBRACKET); }
		public TerminalNode IDENT() { return getToken(WaccParserParser.IDENT, 0); }
		public TerminalNode OPENBRACKET(int i) {
			return getToken(WaccParserParser.OPENBRACKET, i);
		}
		public ArrayelemContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arrayelem; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitArrayelem(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArrayelemContext arrayelem() throws RecognitionException {
		ArrayelemContext _localctx = new ArrayelemContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_arrayelem);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			setState(260); match(IDENT);
			}
			setState(265); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(261); match(OPENBRACKET);
					{
					setState(262); expr(0);
					}
					setState(263); match(CLOSEBRACKET);
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(267); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,17,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IntltrlContext extends ParserRuleContext {
		public TerminalNode PLUS() { return getToken(WaccParserParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(WaccParserParser.MINUS, 0); }
		public TerminalNode INT() { return getToken(WaccParserParser.INT, 0); }
		public IntltrlContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_intltrl; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitIntltrl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IntltrlContext intltrl() throws RecognitionException {
		IntltrlContext _localctx = new IntltrlContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_intltrl);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(270);
			_la = _input.LA(1);
			if (_la==PLUS || _la==MINUS) {
				{
				setState(269);
				_la = _input.LA(1);
				if ( !(_la==PLUS || _la==MINUS) ) {
				_errHandler.recoverInline(this);
				}
				consume();
				}
			}

			setState(272); match(INT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BoolltrlContext extends ParserRuleContext {
		public TerminalNode BOOLLTRL() { return getToken(WaccParserParser.BOOLLTRL, 0); }
		public BoolltrlContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_boolltrl; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBoolltrl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BoolltrlContext boolltrl() throws RecognitionException {
		BoolltrlContext _localctx = new BoolltrlContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_boolltrl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(274); match(BOOLLTRL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CharltrlContext extends ParserRuleContext {
		public TerminalNode CHARLTRL() { return getToken(WaccParserParser.CHARLTRL, 0); }
		public CharltrlContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_charltrl; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitCharltrl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CharltrlContext charltrl() throws RecognitionException {
		CharltrlContext _localctx = new CharltrlContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_charltrl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(276); match(CHARLTRL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StrltrlContext extends ParserRuleContext {
		public TerminalNode STRLTRL() { return getToken(WaccParserParser.STRLTRL, 0); }
		public StrltrlContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_strltrl; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitStrltrl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final StrltrlContext strltrl() throws RecognitionException {
		StrltrlContext _localctx = new StrltrlContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_strltrl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(278); match(STRLTRL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PairltrlContext extends ParserRuleContext {
		public TerminalNode PAIRLTRL() { return getToken(WaccParserParser.PAIRLTRL, 0); }
		public PairltrlContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pairltrl; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitPairltrl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PairltrlContext pairltrl() throws RecognitionException {
		PairltrlContext _localctx = new PairltrlContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_pairltrl);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(280); match(PAIRLTRL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArrayltrlContext extends ParserRuleContext {
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public TerminalNode OPENBRACKET() { return getToken(WaccParserParser.OPENBRACKET, 0); }
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(WaccParserParser.COMMA); }
		public TerminalNode CLOSEBRACKET() { return getToken(WaccParserParser.CLOSEBRACKET, 0); }
		public TerminalNode COMMA(int i) {
			return getToken(WaccParserParser.COMMA, i);
		}
		public ArrayltrlContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arrayltrl; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitArrayltrl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArrayltrlContext arrayltrl() throws RecognitionException {
		ArrayltrlContext _localctx = new ArrayltrlContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_arrayltrl);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(282); match(OPENBRACKET);
			setState(291);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << PLUS) | (1L << MINUS) | (1L << NOT) | (1L << LEN) | (1L << ORD) | (1L << CHR) | (1L << OPENPAREN) | (1L << STRLTRL) | (1L << PAIRLTRL) | (1L << BOOLLTRL) | (1L << CHARLTRL) | (1L << INT) | (1L << IDENT))) != 0)) {
				{
				{
				setState(283); expr(0);
				}
				setState(288);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(284); match(COMMA);
					setState(285); expr(0);
					}
					}
					setState(290);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
			}

			setState(293); match(CLOSEBRACKET);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IdentContext extends ParserRuleContext {
		public TerminalNode IDENT() { return getToken(WaccParserParser.IDENT, 0); }
		public IdentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ident; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitIdent(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IdentContext ident() throws RecognitionException {
		IdentContext _localctx = new IdentContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_ident);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(295); match(IDENT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class UnaryoperContext extends ParserRuleContext {
		public UnaryoperContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unaryoper; }
	 
		public UnaryoperContext() { }
		public void copyFrom(UnaryoperContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class UnaryChrContext extends UnaryoperContext {
		public TerminalNode CHR() { return getToken(WaccParserParser.CHR, 0); }
		public UnaryChrContext(UnaryoperContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitUnaryChr(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class UnaryMinusContext extends UnaryoperContext {
		public TerminalNode MINUS() { return getToken(WaccParserParser.MINUS, 0); }
		public UnaryMinusContext(UnaryoperContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitUnaryMinus(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class UnaryOrdContext extends UnaryoperContext {
		public TerminalNode ORD() { return getToken(WaccParserParser.ORD, 0); }
		public UnaryOrdContext(UnaryoperContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitUnaryOrd(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class UnaryLenContext extends UnaryoperContext {
		public TerminalNode LEN() { return getToken(WaccParserParser.LEN, 0); }
		public UnaryLenContext(UnaryoperContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitUnaryLen(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class UnaryNotContext extends UnaryoperContext {
		public TerminalNode NOT() { return getToken(WaccParserParser.NOT, 0); }
		public UnaryNotContext(UnaryoperContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitUnaryNot(this);
			else return visitor.visitChildren(this);
		}
	}

	public final UnaryoperContext unaryoper() throws RecognitionException {
		UnaryoperContext _localctx = new UnaryoperContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_unaryoper);
		try {
			setState(302);
			switch (_input.LA(1)) {
			case NOT:
				_localctx = new UnaryNotContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(297); match(NOT);
				}
				break;
			case MINUS:
				_localctx = new UnaryMinusContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(298); match(MINUS);
				}
				break;
			case LEN:
				_localctx = new UnaryLenContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(299); match(LEN);
				}
				break;
			case ORD:
				_localctx = new UnaryOrdContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(300); match(ORD);
				}
				break;
			case CHR:
				_localctx = new UnaryChrContext(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(301); match(CHR);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class UnaryexprContext extends ParserRuleContext {
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public UnaryoperContext unaryoper() {
			return getRuleContext(UnaryoperContext.class,0);
		}
		public UnaryexprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_unaryexpr; }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitUnaryexpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final UnaryexprContext unaryexpr() throws RecognitionException {
		UnaryexprContext _localctx = new UnaryexprContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_unaryexpr);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(304); unaryoper();
			setState(305); expr(0);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Binaryoper1Context extends ParserRuleContext {
		public Binaryoper1Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_binaryoper1; }
	 
		public Binaryoper1Context() { }
		public void copyFrom(Binaryoper1Context ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class BinaryModContext extends Binaryoper1Context {
		public TerminalNode MOD() { return getToken(WaccParserParser.MOD, 0); }
		public BinaryModContext(Binaryoper1Context ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBinaryMod(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BinaryMulContext extends Binaryoper1Context {
		public TerminalNode MUL() { return getToken(WaccParserParser.MUL, 0); }
		public BinaryMulContext(Binaryoper1Context ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBinaryMul(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BinaryDivContext extends Binaryoper1Context {
		public TerminalNode DIV() { return getToken(WaccParserParser.DIV, 0); }
		public BinaryDivContext(Binaryoper1Context ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBinaryDiv(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Binaryoper1Context binaryoper1() throws RecognitionException {
		Binaryoper1Context _localctx = new Binaryoper1Context(_ctx, getState());
		enterRule(_localctx, 52, RULE_binaryoper1);
		try {
			setState(310);
			switch (_input.LA(1)) {
			case MUL:
				_localctx = new BinaryMulContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(307); match(MUL);
				}
				break;
			case DIV:
				_localctx = new BinaryDivContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(308); match(DIV);
				}
				break;
			case MOD:
				_localctx = new BinaryModContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(309); match(MOD);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Binaryoper2Context extends ParserRuleContext {
		public Binaryoper2Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_binaryoper2; }
	 
		public Binaryoper2Context() { }
		public void copyFrom(Binaryoper2Context ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class BinaryMinusContext extends Binaryoper2Context {
		public TerminalNode MINUS() { return getToken(WaccParserParser.MINUS, 0); }
		public BinaryMinusContext(Binaryoper2Context ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBinaryMinus(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BinaryPlusContext extends Binaryoper2Context {
		public TerminalNode PLUS() { return getToken(WaccParserParser.PLUS, 0); }
		public BinaryPlusContext(Binaryoper2Context ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBinaryPlus(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Binaryoper2Context binaryoper2() throws RecognitionException {
		Binaryoper2Context _localctx = new Binaryoper2Context(_ctx, getState());
		enterRule(_localctx, 54, RULE_binaryoper2);
		try {
			setState(314);
			switch (_input.LA(1)) {
			case PLUS:
				_localctx = new BinaryPlusContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(312); match(PLUS);
				}
				break;
			case MINUS:
				_localctx = new BinaryMinusContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(313); match(MINUS);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Binaryoper3Context extends ParserRuleContext {
		public Binaryoper3Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_binaryoper3; }
	 
		public Binaryoper3Context() { }
		public void copyFrom(Binaryoper3Context ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class BinarySTContext extends Binaryoper3Context {
		public TerminalNode ST() { return getToken(WaccParserParser.ST, 0); }
		public BinarySTContext(Binaryoper3Context ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBinaryST(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BinarySTEContext extends Binaryoper3Context {
		public TerminalNode STE() { return getToken(WaccParserParser.STE, 0); }
		public BinarySTEContext(Binaryoper3Context ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBinarySTE(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BinaryGTEContext extends Binaryoper3Context {
		public TerminalNode GTE() { return getToken(WaccParserParser.GTE, 0); }
		public BinaryGTEContext(Binaryoper3Context ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBinaryGTE(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BinaryGTContext extends Binaryoper3Context {
		public TerminalNode GT() { return getToken(WaccParserParser.GT, 0); }
		public BinaryGTContext(Binaryoper3Context ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBinaryGT(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Binaryoper3Context binaryoper3() throws RecognitionException {
		Binaryoper3Context _localctx = new Binaryoper3Context(_ctx, getState());
		enterRule(_localctx, 56, RULE_binaryoper3);
		try {
			setState(320);
			switch (_input.LA(1)) {
			case GT:
				_localctx = new BinaryGTContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(316); match(GT);
				}
				break;
			case GTE:
				_localctx = new BinaryGTEContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(317); match(GTE);
				}
				break;
			case ST:
				_localctx = new BinarySTContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(318); match(ST);
				}
				break;
			case STE:
				_localctx = new BinarySTEContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(319); match(STE);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Binaryoper4Context extends ParserRuleContext {
		public Binaryoper4Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_binaryoper4; }
	 
		public Binaryoper4Context() { }
		public void copyFrom(Binaryoper4Context ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class BinaryEqualsContext extends Binaryoper4Context {
		public TerminalNode EQUALITY() { return getToken(WaccParserParser.EQUALITY, 0); }
		public BinaryEqualsContext(Binaryoper4Context ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBinaryEquals(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class BinaryNotEqualsContext extends Binaryoper4Context {
		public TerminalNode NEQUALITY() { return getToken(WaccParserParser.NEQUALITY, 0); }
		public BinaryNotEqualsContext(Binaryoper4Context ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitBinaryNotEquals(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Binaryoper4Context binaryoper4() throws RecognitionException {
		Binaryoper4Context _localctx = new Binaryoper4Context(_ctx, getState());
		enterRule(_localctx, 58, RULE_binaryoper4);
		try {
			setState(324);
			switch (_input.LA(1)) {
			case EQUALITY:
				_localctx = new BinaryEqualsContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(322); match(EQUALITY);
				}
				break;
			case NEQUALITY:
				_localctx = new BinaryNotEqualsContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(323); match(NEQUALITY);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LogicaloperContext extends ParserRuleContext {
		public LogicaloperContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_logicaloper; }
	 
		public LogicaloperContext() { }
		public void copyFrom(LogicaloperContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class LogicalAndContext extends LogicaloperContext {
		public TerminalNode AND() { return getToken(WaccParserParser.AND, 0); }
		public LogicalAndContext(LogicaloperContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitLogicalAnd(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class LogicalOrContext extends LogicaloperContext {
		public TerminalNode OR() { return getToken(WaccParserParser.OR, 0); }
		public LogicalOrContext(LogicaloperContext ctx) { copyFrom(ctx); }
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof WaccParserVisitor ) return ((WaccParserVisitor<? extends T>)visitor).visitLogicalOr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LogicaloperContext logicaloper() throws RecognitionException {
		LogicaloperContext _localctx = new LogicaloperContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_logicaloper);
		try {
			setState(328);
			switch (_input.LA(1)) {
			case AND:
				_localctx = new LogicalAndContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(326); match(AND);
				}
				break;
			case OR:
				_localctx = new LogicalOrContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(327); match(OR);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 4: return stat_sempred((StatContext)_localctx, predIndex);
		case 15: return expr_sempred((ExprContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean stat_sempred(StatContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0: return precpred(_ctx, 1);
		}
		return true;
	}
	private boolean expr_sempred(ExprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 1: return precpred(_ctx, 6);
		case 2: return precpred(_ctx, 5);
		case 3: return precpred(_ctx, 4);
		case 4: return precpred(_ctx, 3);
		case 5: return precpred(_ctx, 2);
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3<\u014d\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36\4\37\t\37\4 \t \3\2"+
		"\3\2\7\2C\n\2\f\2\16\2F\13\2\3\2\3\2\3\2\3\2\3\3\3\3\3\3\3\3\5\3P\n\3"+
		"\3\3\3\3\3\3\3\3\3\3\3\4\3\4\3\4\7\4Z\n\4\f\4\16\4]\13\4\3\5\3\5\3\5\3"+
		"\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6"+
		"\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3"+
		"\6\3\6\3\6\3\6\3\6\3\6\5\6\u008b\n\6\3\6\3\6\3\6\7\6\u0090\n\6\f\6\16"+
		"\6\u0093\13\6\3\7\3\7\3\7\5\7\u0098\n\7\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3"+
		"\b\3\b\3\b\3\b\3\b\3\b\3\b\5\b\u00a8\n\b\3\b\3\b\5\b\u00ac\n\b\3\t\3\t"+
		"\3\t\7\t\u00b1\n\t\f\t\16\t\u00b4\13\t\3\n\3\n\3\n\3\n\5\n\u00ba\n\n\3"+
		"\13\3\13\3\13\5\13\u00bf\n\13\3\f\3\f\3\f\7\f\u00c4\n\f\f\f\16\f\u00c7"+
		"\13\f\3\r\3\r\3\16\3\16\5\16\u00cd\n\16\3\16\3\16\3\16\3\16\3\17\3\17"+
		"\3\17\3\17\3\17\3\17\3\17\3\20\3\20\3\20\5\20\u00dd\n\20\3\21\3\21\3\21"+
		"\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\5\21\u00ec\n\21\3\21"+
		"\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21\3\21"+
		"\3\21\3\21\3\21\3\21\3\21\7\21\u0102\n\21\f\21\16\21\u0105\13\21\3\22"+
		"\3\22\3\22\3\22\3\22\6\22\u010c\n\22\r\22\16\22\u010d\3\23\5\23\u0111"+
		"\n\23\3\23\3\23\3\24\3\24\3\25\3\25\3\26\3\26\3\27\3\27\3\30\3\30\3\30"+
		"\3\30\7\30\u0121\n\30\f\30\16\30\u0124\13\30\5\30\u0126\n\30\3\30\3\30"+
		"\3\31\3\31\3\32\3\32\3\32\3\32\3\32\5\32\u0131\n\32\3\33\3\33\3\33\3\34"+
		"\3\34\3\34\5\34\u0139\n\34\3\35\3\35\5\35\u013d\n\35\3\36\3\36\3\36\3"+
		"\36\5\36\u0143\n\36\3\37\3\37\5\37\u0147\n\37\3 \3 \5 \u014b\n \3 \2\4"+
		"\n !\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,.\60\62\64\668:<>\2"+
		"\3\3\2\35\36\u0168\2@\3\2\2\2\4K\3\2\2\2\6V\3\2\2\2\b^\3\2\2\2\n\u008a"+
		"\3\2\2\2\f\u0097\3\2\2\2\16\u00ab\3\2\2\2\20\u00ad\3\2\2\2\22\u00b9\3"+
		"\2\2\2\24\u00be\3\2\2\2\26\u00c5\3\2\2\2\30\u00c8\3\2\2\2\32\u00cc\3\2"+
		"\2\2\34\u00d2\3\2\2\2\36\u00dc\3\2\2\2 \u00eb\3\2\2\2\"\u0106\3\2\2\2"+
		"$\u0110\3\2\2\2&\u0114\3\2\2\2(\u0116\3\2\2\2*\u0118\3\2\2\2,\u011a\3"+
		"\2\2\2.\u011c\3\2\2\2\60\u0129\3\2\2\2\62\u0130\3\2\2\2\64\u0132\3\2\2"+
		"\2\66\u0138\3\2\2\28\u013c\3\2\2\2:\u0142\3\2\2\2<\u0146\3\2\2\2>\u014a"+
		"\3\2\2\2@D\7\5\2\2AC\5\4\3\2BA\3\2\2\2CF\3\2\2\2DB\3\2\2\2DE\3\2\2\2E"+
		"G\3\2\2\2FD\3\2\2\2GH\5\n\6\2HI\7\6\2\2IJ\7\2\2\3J\3\3\2\2\2KL\5\24\13"+
		"\2LM\5\60\31\2MO\7.\2\2NP\5\6\4\2ON\3\2\2\2OP\3\2\2\2PQ\3\2\2\2QR\7/\2"+
		"\2RS\7\3\2\2ST\5\n\6\2TU\7\6\2\2U\5\3\2\2\2V[\5\b\5\2WX\7\63\2\2XZ\5\b"+
		"\5\2YW\3\2\2\2Z]\3\2\2\2[Y\3\2\2\2[\\\3\2\2\2\\\7\3\2\2\2][\3\2\2\2^_"+
		"\5\24\13\2_`\5\60\31\2`\t\3\2\2\2ab\b\6\1\2b\u008b\7\24\2\2cd\5\24\13"+
		"\2de\5\60\31\2ef\7\37\2\2fg\5\16\b\2g\u008b\3\2\2\2hi\5\f\7\2ij\7\37\2"+
		"\2jk\5\16\b\2k\u008b\3\2\2\2lm\7\23\2\2m\u008b\5\f\7\2no\7\22\2\2o\u008b"+
		"\5 \21\2pq\7\20\2\2q\u008b\5 \21\2rs\7\21\2\2s\u008b\5 \21\2tu\7\16\2"+
		"\2u\u008b\5 \21\2vw\7\17\2\2w\u008b\5 \21\2xy\7\7\2\2yz\5 \21\2z{\7\b"+
		"\2\2{|\5\n\6\2|}\7\t\2\2}~\5\n\6\2~\177\7\n\2\2\177\u008b\3\2\2\2\u0080"+
		"\u0081\7\13\2\2\u0081\u0082\5 \21\2\u0082\u0083\7\f\2\2\u0083\u0084\5"+
		"\n\6\2\u0084\u0085\7\r\2\2\u0085\u008b\3\2\2\2\u0086\u0087\7\5\2\2\u0087"+
		"\u0088\5\n\6\2\u0088\u0089\7\6\2\2\u0089\u008b\3\2\2\2\u008aa\3\2\2\2"+
		"\u008ac\3\2\2\2\u008ah\3\2\2\2\u008al\3\2\2\2\u008an\3\2\2\2\u008ap\3"+
		"\2\2\2\u008ar\3\2\2\2\u008at\3\2\2\2\u008av\3\2\2\2\u008ax\3\2\2\2\u008a"+
		"\u0080\3\2\2\2\u008a\u0086\3\2\2\2\u008b\u0091\3\2\2\2\u008c\u008d\f\3"+
		"\2\2\u008d\u008e\7\62\2\2\u008e\u0090\5\n\6\4\u008f\u008c\3\2\2\2\u0090"+
		"\u0093\3\2\2\2\u0091\u008f\3\2\2\2\u0091\u0092\3\2\2\2\u0092\13\3\2\2"+
		"\2\u0093\u0091\3\2\2\2\u0094\u0098\5\60\31\2\u0095\u0098\5\"\22\2\u0096"+
		"\u0098\5\22\n\2\u0097\u0094\3\2\2\2\u0097\u0095\3\2\2\2\u0097\u0096\3"+
		"\2\2\2\u0098\r\3\2\2\2\u0099\u00ac\5 \21\2\u009a\u00ac\5.\30\2\u009b\u009c"+
		"\7\25\2\2\u009c\u009d\7.\2\2\u009d\u009e\5 \21\2\u009e\u009f\7\63\2\2"+
		"\u009f\u00a0\5 \21\2\u00a0\u00a1\7/\2\2\u00a1\u00ac\3\2\2\2\u00a2\u00ac"+
		"\5\22\n\2\u00a3\u00a4\7\26\2\2\u00a4\u00a5\5\60\31\2\u00a5\u00a7\7.\2"+
		"\2\u00a6\u00a8\5\20\t\2\u00a7\u00a6\3\2\2\2\u00a7\u00a8\3\2\2\2\u00a8"+
		"\u00a9\3\2\2\2\u00a9\u00aa\7/\2\2\u00aa\u00ac\3\2\2\2\u00ab\u0099\3\2"+
		"\2\2\u00ab\u009a\3\2\2\2\u00ab\u009b\3\2\2\2\u00ab\u00a2\3\2\2\2\u00ab"+
		"\u00a3\3\2\2\2\u00ac\17\3\2\2\2\u00ad\u00b2\5 \21\2\u00ae\u00af\7\63\2"+
		"\2\u00af\u00b1\5 \21\2\u00b0\u00ae\3\2\2\2\u00b1\u00b4\3\2\2\2\u00b2\u00b0"+
		"\3\2\2\2\u00b2\u00b3\3\2\2\2\u00b3\21\3\2\2\2\u00b4\u00b2\3\2\2\2\u00b5"+
		"\u00b6\7\27\2\2\u00b6\u00ba\5 \21\2\u00b7\u00b8\7\30\2\2\u00b8\u00ba\5"+
		" \21\2\u00b9\u00b5\3\2\2\2\u00b9\u00b7\3\2\2\2\u00ba\23\3\2\2\2\u00bb"+
		"\u00bf\5\30\r\2\u00bc\u00bf\5\32\16\2\u00bd\u00bf\5\34\17\2\u00be\u00bb"+
		"\3\2\2\2\u00be\u00bc\3\2\2\2\u00be\u00bd\3\2\2\2\u00bf\25\3\2\2\2\u00c0"+
		"\u00c1\7,\2\2\u00c1\u00c2\7-\2\2\u00c2\u00c4\5\26\f\2\u00c3\u00c0\3\2"+
		"\2\2\u00c4\u00c7\3\2\2\2\u00c5\u00c3\3\2\2\2\u00c5\u00c6\3\2\2\2\u00c6"+
		"\27\3\2\2\2\u00c7\u00c5\3\2\2\2\u00c8\u00c9\7\64\2\2\u00c9\31\3\2\2\2"+
		"\u00ca\u00cd\5\30\r\2\u00cb\u00cd\5\34\17\2\u00cc\u00ca\3\2\2\2\u00cc"+
		"\u00cb\3\2\2\2\u00cd\u00ce\3\2\2\2\u00ce\u00cf\7,\2\2\u00cf\u00d0\7-\2"+
		"\2\u00d0\u00d1\5\26\f\2\u00d1\33\3\2\2\2\u00d2\u00d3\7\31\2\2\u00d3\u00d4"+
		"\7.\2\2\u00d4\u00d5\5\36\20\2\u00d5\u00d6\7\63\2\2\u00d6\u00d7\5\36\20"+
		"\2\u00d7\u00d8\7/\2\2\u00d8\35\3\2\2\2\u00d9\u00dd\5\30\r\2\u00da\u00dd"+
		"\5\32\16\2\u00db\u00dd\7\31\2\2\u00dc\u00d9\3\2\2\2\u00dc\u00da\3\2\2"+
		"\2\u00dc\u00db\3\2\2\2\u00dd\37\3\2\2\2\u00de\u00df\b\21\1\2\u00df\u00ec"+
		"\5$\23\2\u00e0\u00ec\5&\24\2\u00e1\u00ec\5*\26\2\u00e2\u00ec\5(\25\2\u00e3"+
		"\u00ec\5,\27\2\u00e4\u00ec\5\"\22\2\u00e5\u00ec\5\64\33\2\u00e6\u00ec"+
		"\5\60\31\2\u00e7\u00e8\7.\2\2\u00e8\u00e9\5 \21\2\u00e9\u00ea\7/\2\2\u00ea"+
		"\u00ec\3\2\2\2\u00eb\u00de\3\2\2\2\u00eb\u00e0\3\2\2\2\u00eb\u00e1\3\2"+
		"\2\2\u00eb\u00e2\3\2\2\2\u00eb\u00e3\3\2\2\2\u00eb\u00e4\3\2\2\2\u00eb"+
		"\u00e5\3\2\2\2\u00eb\u00e6\3\2\2\2\u00eb\u00e7\3\2\2\2\u00ec\u0103\3\2"+
		"\2\2\u00ed\u00ee\f\b\2\2\u00ee\u00ef\5\66\34\2\u00ef\u00f0\5 \21\t\u00f0"+
		"\u0102\3\2\2\2\u00f1\u00f2\f\7\2\2\u00f2\u00f3\58\35\2\u00f3\u00f4\5 "+
		"\21\b\u00f4\u0102\3\2\2\2\u00f5\u00f6\f\6\2\2\u00f6\u00f7\5:\36\2\u00f7"+
		"\u00f8\5 \21\7\u00f8\u0102\3\2\2\2\u00f9\u00fa\f\5\2\2\u00fa\u00fb\5<"+
		"\37\2\u00fb\u00fc\5 \21\6\u00fc\u0102\3\2\2\2\u00fd\u00fe\f\4\2\2\u00fe"+
		"\u00ff\5> \2\u00ff\u0100\5 \21\5\u0100\u0102\3\2\2\2\u0101\u00ed\3\2\2"+
		"\2\u0101\u00f1\3\2\2\2\u0101\u00f5\3\2\2\2\u0101\u00f9\3\2\2\2\u0101\u00fd"+
		"\3\2\2\2\u0102\u0105\3\2\2\2\u0103\u0101\3\2\2\2\u0103\u0104\3\2\2\2\u0104"+
		"!\3\2\2\2\u0105\u0103\3\2\2\2\u0106\u010b\7:\2\2\u0107\u0108\7,\2\2\u0108"+
		"\u0109\5 \21\2\u0109\u010a\7-\2\2\u010a\u010c\3\2\2\2\u010b\u0107\3\2"+
		"\2\2\u010c\u010d\3\2\2\2\u010d\u010b\3\2\2\2\u010d\u010e\3\2\2\2\u010e"+
		"#\3\2\2\2\u010f\u0111\t\2\2\2\u0110\u010f\3\2\2\2\u0110\u0111\3\2\2\2"+
		"\u0111\u0112\3\2\2\2\u0112\u0113\79\2\2\u0113%\3\2\2\2\u0114\u0115\7\67"+
		"\2\2\u0115\'\3\2\2\2\u0116\u0117\78\2\2\u0117)\3\2\2\2\u0118\u0119\7\65"+
		"\2\2\u0119+\3\2\2\2\u011a\u011b\7\66\2\2\u011b-\3\2\2\2\u011c\u0125\7"+
		",\2\2\u011d\u0122\5 \21\2\u011e\u011f\7\63\2\2\u011f\u0121\5 \21\2\u0120"+
		"\u011e\3\2\2\2\u0121\u0124\3\2\2\2\u0122\u0120\3\2\2\2\u0122\u0123\3\2"+
		"\2\2\u0123\u0126\3\2\2\2\u0124\u0122\3\2\2\2\u0125\u011d\3\2\2\2\u0125"+
		"\u0126\3\2\2\2\u0126\u0127\3\2\2\2\u0127\u0128\7-\2\2\u0128/\3\2\2\2\u0129"+
		"\u012a\7:\2\2\u012a\61\3\2\2\2\u012b\u0131\7(\2\2\u012c\u0131\7\36\2\2"+
		"\u012d\u0131\7)\2\2\u012e\u0131\7*\2\2\u012f\u0131\7+\2\2\u0130\u012b"+
		"\3\2\2\2\u0130\u012c\3\2\2\2\u0130\u012d\3\2\2\2\u0130\u012e\3\2\2\2\u0130"+
		"\u012f\3\2\2\2\u0131\63\3\2\2\2\u0132\u0133\5\62\32\2\u0133\u0134\5 \21"+
		"\2\u0134\65\3\2\2\2\u0135\u0139\7\32\2\2\u0136\u0139\7\33\2\2\u0137\u0139"+
		"\7\34\2\2\u0138\u0135\3\2\2\2\u0138\u0136\3\2\2\2\u0138\u0137\3\2\2\2"+
		"\u0139\67\3\2\2\2\u013a\u013d\7\35\2\2\u013b\u013d\7\36\2\2\u013c\u013a"+
		"\3\2\2\2\u013c\u013b\3\2\2\2\u013d9\3\2\2\2\u013e\u0143\7 \2\2\u013f\u0143"+
		"\7!\2\2\u0140\u0143\7\"\2\2\u0141\u0143\7#\2\2\u0142\u013e\3\2\2\2\u0142"+
		"\u013f\3\2\2\2\u0142\u0140\3\2\2\2\u0142\u0141\3\2\2\2\u0143;\3\2\2\2"+
		"\u0144\u0147\7$\2\2\u0145\u0147\7%\2\2\u0146\u0144\3\2\2\2\u0146\u0145"+
		"\3\2\2\2\u0147=\3\2\2\2\u0148\u014b\7&\2\2\u0149\u014b\7\'\2\2\u014a\u0148"+
		"\3\2\2\2\u014a\u0149\3\2\2\2\u014b?\3\2\2\2\35DO[\u008a\u0091\u0097\u00a7"+
		"\u00ab\u00b2\u00b9\u00be\u00c5\u00cc\u00dc\u00eb\u0101\u0103\u010d\u0110"+
		"\u0122\u0125\u0130\u0138\u013c\u0142\u0146\u014a";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}