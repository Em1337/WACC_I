package BackEnd;

import java.util.ArrayList;
import java.util.List;

public class Registers {

  private List<Register> registers = new ArrayList<>();

  Registers() {
    for (int i = 0; i < 4; i++) {
      registers.add(new Register("r" + i, false));
    }
    for (int i = 4; i < 12; i++) {
      registers.add(new Register("r" + i));
    }
    registers.add(new Register("sp")); // should be something else
    registers.add(new Register("lr"));
    registers.add(new Register("pc"));
    registers.add(new Register("fp"));
    registers.add(new Register("src"));
  }

  Register getRegister(String name) {
    for (Register register : registers) {
      if (register.getName().equals(name)) {
        return register;
      }
    }
    return null;
  }

  Register getFreeRegister() {

    for (Register register : registers) {
      if (register.isFree() &&
          !register.getName().equals("sp") &&
          !register.getName().equals("lr") &&
          !register.getName().equals("pc") &&
          !register.getName().equals("fp") &&
          !register.getName().equals("src")) {
        register.inUse();
        return register;
      }
    }
    return null;
  }

  void freeRegister(String name) {
    getRegister(name).setFree();
  }

  void freeRegister(Register register) {
    register.setFree();
  }

  public enum Sizes {
    B, SB, W
  }

}
