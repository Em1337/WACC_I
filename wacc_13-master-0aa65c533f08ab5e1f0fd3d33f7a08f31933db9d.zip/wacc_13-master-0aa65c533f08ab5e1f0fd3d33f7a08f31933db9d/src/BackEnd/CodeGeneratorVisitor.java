package BackEnd;

import static FrontEnd.SymbolTable.SymbolTable.PC_OFFSET;

import BackEnd.Instructions.*;
import BackEnd.Registers.Sizes;
import FrontEnd.ErrorHandler;
import FrontEnd.SymbolTable.Function;
import FrontEnd.SymbolTable.Symbol;
import FrontEnd.SymbolTable.SymbolTable;
import FrontEnd.SymbolTable.Variable;
import FrontEnd.Types.ArrayType;
import FrontEnd.Types.BaseType;
import FrontEnd.Types.PairType;
import FrontEnd.Types.Type;
import FrontEnd.Types.baseTypeEnum;
import antlr.WaccParserBaseVisitor;
import antlr.WaccParserParser.*;
import java.util.List;
import java.util.Stack;
import org.antlr.v4.runtime.misc.NotNull;

public class CodeGeneratorVisitor extends WaccParserBaseVisitor<Void> {

  private ErrorHandler errorHandler = new ErrorHandler();
  private static final String LABEL_NAME = "L";
  private static final Sizes byteSize = Sizes.B;
  private static final Sizes word = Sizes.W;
  private Stack<Integer> constantStack = new Stack<>();
  private static int labelCount = 0;
  private Program program = new Program();

  public CodeGeneratorVisitor(SymbolTable symbolTable) {
    program.setSymbolTable(symbolTable);
  }

  private static String getLabelAndIncrementCounter() {
    String label = LABEL_NAME + labelCount;
    labelCount++;
    return label;
  }

  public Program getProgram() {
    return program;
  }


  @Override
  public Void visitProgram(@NotNull ProgramContext ctx) {
    //instructions for main
    program.addInstructions(new DirectiveInstruction("text"));
    program.addInstructions(new DirectiveInstruction("global", "main"));
    //start function
    program.beginFunction("main");
    //visit all functions in the program
    if (ctx.func() != null) {
      for (int i = 0; i < ctx.func().size(); i++) {
        //get respective symbolTable for function
        Function function = program.symbolTable
            .getFirstFunc(Symbol.symbol(ctx.func(i).ident().getText()));
        //set the program symbolTable to function symbolTable
        program.setSymbolTable(function.getSymbolTable());
        //initialises offsets and sets variable memory sizes for function scope
        program.symbolTable.initializeOffsets(PC_OFFSET);
        visit(ctx.func(i));
      }
    }
    //initialises offsets and sets variable memory sizes for main scope
    program.symbolTable.initializeOffsets(0);
    int totalOffset = program.symbolTable.getTotalOffset();
    //adjusts stack pointer according to offset
    List<Instruction> subStackInstructions = program.initializeScopeOffset(totalOffset);
    for (Instruction instruction : subStackInstructions) {
      program.addInstructions(instruction);
    }
    //visit body
    visit(ctx.stat());
    //resets stack pointer
    List<Instruction> addStackInstructions = program.returnScopeOffset(totalOffset);
    for (Instruction instruction : addStackInstructions) {
      program.addInstructions(instruction);
    }

    program.addInstructions(
        new LoadInstruction(Sizes.W, program.getRegisters().getRegister("r0"), "0"));
    program.endFunction("main");

    return null;
  }

  @Override
  public Void visitFunc(@NotNull FuncContext ctx) {
    String functionName = ctx.ident().getText();
    Symbol functionSymbol = Symbol.symbol(functionName);
    Function function = program.symbolTable.getFirstFunc(functionSymbol);
    // visit function params
    if (ctx.paramlist() != null) {
      visit(ctx.paramlist());
    }
    // move into body symbolTable
    program.moveIntoNextScope();
    int totalOffset = program.symbolTable.getTotalOffset();
    program.beginFunction(functionName);
    //adjust stack pointer according to offset
    List<Instruction> subStackInstructions = program.initializeScopeOffset(totalOffset);
    for (Instruction instruction : subStackInstructions) {
      program.addInstructions(instruction);
    }
    // visit body
    visit(ctx.stat());
    program.endFunction(functionName);
    // reset symbolTable to outter scope
    program.setSymbolTable(function.getSymbolTable().getParentSymbolTable());
    return null;
  }

  @Override
  public Void visitParam(@NotNull ParamContext ctx) {
    String varName = ctx.ident().getText();
    Symbol varSymbol = Symbol.symbol(varName);
    // set param variable in symbolTable to intialised
    program.symbolTable.setAlreadyInitialised(varSymbol);
    return null;
  }

  @Override
  public Void visitAssignStatement(@NotNull AssignStatementContext ctx) {
    //visit rhs and lhs
    visit(ctx.assignrhs());
    visit(ctx.assignlhs());

    String ident = "";
    String pairElemCase = "";

    if (ctx.assignlhs() instanceof AssignlhsIdentContext) {
      // if lhs is an Ident just get the name
      ident = ((AssignlhsIdentContext) ctx.assignlhs()).ident().getText();
    }
    if (ctx.assignlhs() instanceof AssignlhsPairelemContext) {
      if (((AssignlhsPairelemContext) ctx.assignlhs()).pairelem() instanceof PairElemFstContext) {
        if (((PairElemFstContext) ((AssignlhsPairelemContext) ctx.assignlhs()).pairelem())
            .expr() instanceof IdentExprContext) {
          // if lhs is a fst pairElem and an ident get the ident name
          ident = ((IdentExprContext) ((PairElemFstContext) ((AssignlhsPairelemContext) ctx
              .assignlhs()).pairelem()).expr()).ident().getText();
          // set the case we are in
          pairElemCase = "fst";
        }
      }
    }
    if (ctx.assignlhs() instanceof AssignlhsPairelemContext) {
      if (((AssignlhsPairelemContext) ctx.assignlhs()).pairelem() instanceof PairElemSndContext) {
        if (((PairElemSndContext) ((AssignlhsPairelemContext) ctx.assignlhs()).pairelem())
            .expr() instanceof IdentExprContext) {
          // if lhs is a snd pairElem and an ident get the name
          ident = ((IdentExprContext) ((PairElemSndContext) ((AssignlhsPairelemContext) ctx
              .assignlhs()).pairelem()).expr()).ident().getText();
          // set the case we are in
          pairElemCase = "snd";
        }
      }
    }
    if (ctx.assignlhs() instanceof AssignlhsArrayElemContext) {
      // if lhs is an ArrayElem get the ident name
      ident = ((AssignlhsArrayElemContext) ctx.assignlhs()).arrayelem().IDENT().getText();
    }
    // get offset for ident
    int offset = program.symbolTable.getVariableTotalOffset(ident);
    String offsetString = String.valueOf(offset);

    StoreInstruction strAssignment = null;

    if (ctx.assignlhs() instanceof AssignlhsPairelemContext) {
      //if lhs is a pairElem pop Registers for rhs result and str register

      Register rhsRegister = program.usedRegisters.pop();
      program.getRegisters().freeRegister(rhsRegister);

      Register strRegister = program.usedRegisters.pop();
      program.getRegisters().freeRegister(strRegister);

      // cast type to pairType
      PairType pair
          = (PairType) program.symbolTable.getFirstVar(Symbol.symbol(ident)).getType();

      int elemRequestedSize = 0;

      Type pairElementType;

      if (pairElemCase.equals("fst")) {
        // fst case
        // find the type of the fst elem of the pair
        pairElementType = pair.getFst();

        if (pairElementType != null) {

          // gets the size of the element
          if (pairElementType.typeCheck(new BaseType(baseTypeEnum.BOOL))
              || pairElementType.typeCheck(new BaseType(baseTypeEnum.CHAR))) {

            elemRequestedSize = SymbolTable.STACK_SIZE_1;

          } else {

            elemRequestedSize = SymbolTable.STACK_SIZE_4;

          }
        } else {
          elemRequestedSize = SymbolTable.STACK_SIZE_4;
        }

      } else if (pairElemCase.equals("snd")) {
        // find the type of the first element of the pair
        pairElementType = pair.getSnd();

        if (pairElementType != null) {

          // gets the correct size of the element depending on the
          // type of the element
          if (pairElementType.typeCheck(new BaseType(baseTypeEnum.BOOL))
              || pairElementType.typeCheck(new BaseType(baseTypeEnum.CHAR))) {

            elemRequestedSize = SymbolTable.STACK_SIZE_1;

          } else {

            elemRequestedSize = SymbolTable.STACK_SIZE_4;
          }

        } else {
          elemRequestedSize = SymbolTable.STACK_SIZE_4;
        }

      }

      // generate the appropriate store command corresponding to
      // element size
      if (elemRequestedSize == SymbolTable.STACK_SIZE_1) {

        strAssignment = new StoreInstruction(byteSize,
            strRegister, rhsRegister);

      } else if (elemRequestedSize == SymbolTable.STACK_SIZE_4) {

        strAssignment = new StoreInstruction(word,
            strRegister, rhsRegister);

      }

    } else if (ctx.assignlhs() instanceof AssignlhsArrayElemContext) {

      Register lhsRegister = program.usedRegisters.pop();
      program.getRegisters().freeRegister(lhsRegister);

      Register strRegister = program.usedRegisters.pop();
      program.getRegisters().freeRegister(strRegister);

      int variableSize = 0;

      Type type = program.symbolTable.getFirstVar(Symbol.symbol(ident)).getType();

      if (type instanceof ArrayType) {

        while (((ArrayType) type).getType() instanceof ArrayType) {

          type = ((ArrayType) type).getType();
        }

        type = ((ArrayType) type).getType();

        if (type.typeCheck(
            new BaseType(baseTypeEnum.BOOL)) || type.typeCheck(
            new BaseType(baseTypeEnum.CHAR))) {

          variableSize = SymbolTable.STACK_SIZE_1;

        } else {
          variableSize = SymbolTable.STACK_SIZE_4;
        }

      } else if (type.typeCheck(new BaseType(baseTypeEnum.STRING))) {
        variableSize = SymbolTable.STACK_SIZE_1;
      }

      if (variableSize == SymbolTable.STACK_SIZE_1) {

        // Store Byte with no register offset
        strAssignment = new StoreInstruction(byteSize,
            strRegister, lhsRegister);

      } else if (variableSize == SymbolTable.STACK_SIZE_4) {

        // Store Word with no register offset
        strAssignment = new StoreInstruction(word,
            strRegister, lhsRegister);

      }


    } else if (ctx.assignlhs() instanceof AssignlhsIdentContext) {

      Register strRegister = program.usedRegisters.pop();
      program.getRegisters().freeRegister(strRegister);

      int variableSize = program.symbolTable.getFirstVar(Symbol.symbol(ident)).
          getMemorySize();

      if (variableSize == SymbolTable.STACK_SIZE_1 && offset == 0) {

        // Store Byte with no register offset
        strAssignment = new StoreInstruction(byteSize,
            strRegister, program.getRegisters().getRegister("sp"));

      } else if (variableSize == SymbolTable.STACK_SIZE_4
          && offset == 0) {

        // Store Word with no register offset
        strAssignment = new StoreInstruction(word,
            strRegister, program.getRegisters().getRegister("sp"));

      } else if (variableSize == SymbolTable.STACK_SIZE_1) {

        // Store Byte with a register offset
        strAssignment = new StoreInstruction(byteSize,
            strRegister, program.getRegisters().getRegister("sp"), offsetString, true, false);

      } else if (variableSize == SymbolTable.STACK_SIZE_4) {

        // Store Word with a register offset
        strAssignment = new StoreInstruction(word,
            strRegister, program.getRegisters().getRegister("sp"), offsetString, true, false);
      }
    }

    program.addInstructions(strAssignment);

    return null;
  }

  @Override
  public Void visitPrintlnStatement(@NotNull PrintlnStatementContext ctx) {
    ExprContext expression = ctx.expr();
    Type expressionType = null;
    Register r0 = program.getRegisters().getRegister("r0");

    if (expression instanceof IdentExprContext) {
      IdentExprContext express = (IdentExprContext) expression;
      expressionType = program.symbolTable.getFirstVar(Symbol.symbol(express.ident().getText()))
          .getType();
      visit(expression);
      Register register = program.usedRegisters.pop();
      program.getRegisters().freeRegister(register);
      if (expressionType instanceof ArrayType || expressionType instanceof PairType) {
        program.addInstructions(new MovInstruction(r0, register));
        program.addInstructions(new BLInstruction("p_Print_Ref"));
        if (!program.functionAlreadyDefined("Print_Ref")) {
          program.printRef();
        }
      }
    }
    if (expression instanceof PairLiteralContext) {
      visit(expression);
      Register register = program.usedRegisters.pop();
      program.getRegisters().freeRegister(register.getName());
      program.addInstructions(new MovInstruction(r0, register));
      program.addInstructions(new BLInstruction("p_Print_Ref"));
      if (!program.functionAlreadyDefined("Print_Ref")) {
        program.printRef();
      }
    }

    if (expression instanceof ArrayLiteralContext) {
      visit(expression);
      Register register = program.usedRegisters.pop();
      program.getRegisters().freeRegister(register);
      program.addInstructions(new MovInstruction(r0, register));
      String ident = ((ArrayLiteralContext) expression).arrayelem().IDENT().getText();
      ArrayType type = (ArrayType) program.symbolTable.getFirstVar(Symbol.symbol(ident)).getType();
      while (type.getType() instanceof ArrayType) {
        type = (ArrayType) type.getType();
      }

      Type innerArrayType = type.getType();

      if (innerArrayType instanceof BaseType) {

        if (innerArrayType.typeCheck(new BaseType(baseTypeEnum.BOOL))) {
          program.addInstructions(new BLInstruction("p_Print_Bool"));
          if (!program.functionAlreadyDefined("Print_Bool")) {
            program.printBool();
          }
        } else if (innerArrayType.typeCheck(new BaseType(baseTypeEnum.STRING))) {
          program.addInstructions(new BLInstruction("p_Print_String"));
          if (!program.functionAlreadyDefined("Print_String")) {
            program.printString();
          }
        } else if (innerArrayType.typeCheck(new BaseType(baseTypeEnum.CHAR))) {
          program.addInstructions(new BLInstruction("p_Print_String"));
          if (!program.functionAlreadyDefined("Print_String")) {
            program.printString();
          }
        } else if (innerArrayType.typeCheck(new BaseType(baseTypeEnum.INT))) {
          program.addInstructions(new BLInstruction("p_Print_Int"));
          if (!program.functionAlreadyDefined("Print_Int")) {
            program.printInt();
          }
        }
      }
    }

    if (expression instanceof BracketedExprContext) {
      BracketedExprContext express = (BracketedExprContext) expression;
      expression = express.expr();
    }
    if (expression instanceof UnaryOperationExprContext) {
      UnaryOperationExprContext express = (UnaryOperationExprContext) expression;
      switch (express.unaryexpr().unaryoper().getText()) {
        case "!":
          expressionType = new BaseType(baseTypeEnum.BOOL);
          break;
        case "len":
        case "-":
        case "ord":
          expressionType = new BaseType(baseTypeEnum.INT);
          break;
        case "chr":
          expressionType = new BaseType(baseTypeEnum.CHAR);
          break;
        default:
          break;
      }
    }
    if (expression instanceof BinaryOperation1ExprContext) {
      BinaryOperation1ExprContext express = (BinaryOperation1ExprContext) expression;
      switch (express.binaryoper1().getText()) {
        case "*":
        case "/":
        case "%":
          expressionType = new BaseType(baseTypeEnum.INT);
          break;
        default:
          break;
      }
    } else if (expression instanceof BinaryOperation2ExprContext) {
      BinaryOperation2ExprContext express = (BinaryOperation2ExprContext) expression;
      switch (express.binaryoper2().getText()) {
        case "+":
        case "-":
          expressionType = new BaseType(baseTypeEnum.INT);
          break;
        default:
          break;
      }
    } else if (expression instanceof BinaryOperation3ExprContext) {
      BinaryOperation3ExprContext express = (BinaryOperation3ExprContext) expression;
      switch (express.binaryoper3().getText()) {
        case "<":
        case "<=":
        case ">":
        case ">=":
          expressionType = new BaseType(baseTypeEnum.BOOL);
          break;
        default:
          break;
      }
    } else if (expression instanceof BinaryOperation4ExprContext) {
      BinaryOperation4ExprContext express = (BinaryOperation4ExprContext) expression;
      switch (express.binaryoper4().getText()) {
        case "==":
        case "!=":
          expressionType = new BaseType(baseTypeEnum.BOOL);
          break;
        default:
          break;
      }
    }
    if (expression instanceof LogicalOperationExprContext) {
      expressionType = new BaseType(baseTypeEnum.BOOL);
    }
    if (expression instanceof IntLiteralContext || (expressionType != null && expressionType
        .typeCheck(new BaseType(baseTypeEnum.INT)))) {

      visit(expression);

      Register register = program.usedRegisters.pop();
      program.getRegisters().freeRegister(register);
      // print int

      program.addInstructions(new MovInstruction(r0, register));
      program.addInstructions(new BLInstruction("p_Print_Int"));
      if (!program.functionAlreadyDefined("Print_Int")) {
        program.printInt();
      }

    } else if (expression instanceof CharLiteralContext || (expressionType != null && expressionType
        .typeCheck(new BaseType(baseTypeEnum.CHAR)))) {

      visit(expression);

      Register register = program.usedRegisters.pop();
      program.getRegisters().freeRegister(register);

      program.addInstructions(new MovInstruction(r0, register));
      program.addInstructions(new BLInstruction("putchar"));

    } else if (expression instanceof StrLiteralContext || (expressionType != null && expressionType
        .typeCheck(new BaseType(baseTypeEnum.STRING)))) {

      visit(ctx.expr());

      Register register = program.usedRegisters.pop();
      program.getRegisters().freeRegister(register);

      program.addInstructions(new MovInstruction(r0, register));

      program.addInstructions(new BLInstruction("p_Print_String"));
      if (!program.functionAlreadyDefined("Print_String")) {
        program.printString();
      }
    } else if (expression instanceof BoolLiteralContext || (expressionType != null && expressionType
        .typeCheck(new BaseType(baseTypeEnum.BOOL)))) {
      visit(ctx.expr());
      Register register = program.usedRegisters.pop();
      program.getRegisters().freeRegister(register);
      program.addInstructions(new MovInstruction(r0, register));
      program.addInstructions(new BLInstruction("p_Print_Bool"));
      if (!program.functionAlreadyDefined("Print_Bool")) {
        program.printBool();
      }
    }

    program.addInstructions(new BLInstruction("p_Print_Ln"));
    if (!program.functionAlreadyDefined("Print_Ln")) {
      program.printLn();
    }

    return null;
  }

  @Override
  public Void visitPrintStatement(@NotNull PrintStatementContext ctx) {
    ExprContext expression = ctx.expr();
    Type expressionType = null;
    Register r0 = program.getRegisters().getRegister("r0");

    if (expression instanceof IdentExprContext) {
      IdentExprContext express = (IdentExprContext) expression;
      expressionType = program.symbolTable.getFirstVar(Symbol.symbol(express.ident().getText()))
          .getType();
      visit(expression);
      Register register = program.usedRegisters.pop();
      program.getRegisters().freeRegister(register);
      if (expressionType instanceof ArrayType || expressionType instanceof PairType) {
        program.addInstructions(new MovInstruction(r0, register));
        program.addInstructions(new BLInstruction("p_Print_Ref"));
        if (!program.functionAlreadyDefined("Print_Ref")) {
          program.printRef();
        }
      }
    }
    if (expression instanceof PairLiteralContext) {
      visit(expression);
      Register register = program.usedRegisters.pop();
      program.getRegisters().freeRegister(register);
      program.addInstructions(new MovInstruction(r0, register));
      program.addInstructions(new BLInstruction("p_Print_Ref"));
    }
    if (expression instanceof ArrayLiteralContext) {
      visit(expression);
      Register register = program.usedRegisters.pop();
      program.getRegisters().freeRegister(register);
      program.addInstructions(new MovInstruction(r0, register));
      String ident = ((ArrayLiteralContext) expression).arrayelem().IDENT().getText();
      ArrayType type = (ArrayType) program.symbolTable.getFirstVar(Symbol.symbol(ident)).getType();
      Type arrayType = type.getType();

      if (arrayType instanceof BaseType) {

        if (arrayType.typeCheck(new BaseType(baseTypeEnum.BOOL))) {
          program.addInstructions(new BLInstruction("p_Print_Bool"));
          if (!program.functionAlreadyDefined("Print_Bool")) {
            program.printBool();
          }
        } else if (arrayType.typeCheck(new BaseType(baseTypeEnum.STRING))) {
          program.addInstructions(new BLInstruction("p_Print_String"));
          if (!program.functionAlreadyDefined("Print_String")) {
            program.printString();
          }
        } else if (arrayType.typeCheck(new BaseType(baseTypeEnum.CHAR))) {
          program.addInstructions(new BLInstruction("putchar"));
        } else if (arrayType.typeCheck(new BaseType(baseTypeEnum.INT))) {
          program.addInstructions(new BLInstruction("p_Print_Int"));
          if (!program.functionAlreadyDefined("Print_Int")) {
            program.printInt();
          }
        }
      }
    }
    if (expression instanceof BracketedExprContext) {
      BracketedExprContext express = (BracketedExprContext) expression;
      expression = express.expr();
    }
    if (expression instanceof UnaryOperationExprContext) {
      UnaryOperationExprContext express = (UnaryOperationExprContext) expression;
      switch (express.unaryexpr().unaryoper().getText()) {
        case "!":
          expressionType = new BaseType(baseTypeEnum.BOOL);
          break;
        case "len":
        case "-":
        case "ord":
          expressionType = new BaseType(baseTypeEnum.INT);
          break;
        case "chr":
          expressionType = new BaseType(baseTypeEnum.CHAR);
          break;
        default:
          break;
      }
    }
    if (expression instanceof BinaryOperation1ExprContext) {
      BinaryOperation1ExprContext express = (BinaryOperation1ExprContext) expression;
      switch (express.binaryoper1().getText()) {
        case "*":
        case "/":
        case "%":
          expressionType = new BaseType(baseTypeEnum.INT);
          break;
        default:
          break;
      }
    } else if (expression instanceof BinaryOperation2ExprContext) {
      BinaryOperation2ExprContext express = (BinaryOperation2ExprContext) expression;
      switch (express.binaryoper2().getText()) {
        case "+":
        case "-":
          expressionType = new BaseType(baseTypeEnum.INT);
          break;
        default:
          break;
      }
    } else if (expression instanceof BinaryOperation3ExprContext) {
      BinaryOperation3ExprContext express = (BinaryOperation3ExprContext) expression;
      switch (express.binaryoper3().getText()) {
        case "<":
        case "<=":
        case ">":
        case ">=":
          expressionType = new BaseType(baseTypeEnum.BOOL);
          break;
        default:
          break;
      }
    } else if (expression instanceof BinaryOperation4ExprContext) {
      BinaryOperation4ExprContext express = (BinaryOperation4ExprContext) expression;
      switch (express.binaryoper4().getText()) {
        case "==":
        case "!=":
          expressionType = new BaseType(baseTypeEnum.BOOL);
          break;
        default:
          break;
      }
    }
    if (expression instanceof LogicalOperationExprContext) {
      expressionType = new BaseType(baseTypeEnum.BOOL);
    }
    if (expression instanceof IntLiteralContext || (expressionType != null && expressionType
        .typeCheck(new BaseType(baseTypeEnum.INT)))) {

      visit(expression);

      Register register = program.usedRegisters.pop();
      program.getRegisters().freeRegister(register);
      // print int

      program.addInstructions(new MovInstruction(r0, register));
      program.addInstructions(new BLInstruction("p_Print_Int"));
      if (!program.functionAlreadyDefined("Print_Int")) {
        program.printInt();
      }

    } else if (expression instanceof CharLiteralContext || (expressionType != null && expressionType
        .typeCheck(new BaseType(baseTypeEnum.CHAR)))) {

      visit(expression);

      Register register = program.usedRegisters.pop();
      program.getRegisters().freeRegister(register);

      program.addInstructions(new MovInstruction(r0, register));
      program.addInstructions(new BLInstruction("putchar"));
    } else if (expression instanceof StrLiteralContext || (expressionType != null && expressionType
        .typeCheck(new BaseType(baseTypeEnum.STRING)))) {

      visit(ctx.expr());

      Register register = program.usedRegisters.pop();
      program.getRegisters().freeRegister(register);

      program.addInstructions(new MovInstruction(r0, register));

      program.addInstructions(new BLInstruction("p_Print_String"));
      if (!program.functionAlreadyDefined("Print_String")) {
        program.printString();
      }
    } else if (expression instanceof BoolLiteralContext || (expressionType != null && expressionType
        .typeCheck(new BaseType(baseTypeEnum.BOOL)))) {
      visit(ctx.expr());
      Register register = program.usedRegisters.pop();
      program.getRegisters().freeRegister(register);
      program.addInstructions(new MovInstruction(r0, register));
      program.addInstructions(new BLInstruction("p_Print_Bool"));
      if (!program.functionAlreadyDefined("Print_Bool")) {
        program.printBool();
      }
    }
    return null;
  }

  @Override
  public Void visitDeclareStatement(@NotNull DeclareStatementContext ctx) {
    visit(ctx.assignrhs());

    String ident = ctx.ident().getText();
    Symbol varSymbol = Symbol.symbol(ident);

    Register sp = program.getRegisters().getRegister("sp");

    Register storeRegister = program.usedRegisters.pop();
    program.getRegisters().freeRegister(storeRegister.getName());

    program.symbolTable.getVar(varSymbol).setDeclaredInScope();
    // set ident to be intialised
    program.symbolTable.setAlreadyInitialised(varSymbol);

    int offset = program.symbolTable.getVariableTotalOffset(ident);
    // get offset
    int variableSize = program.symbolTable.getFirstVar(varSymbol).getMemorySize();
    // get string value
    Instruction storeInstruction = null;

    if (variableSize == SymbolTable.STACK_SIZE_1 && offset == 0) {

      // Store Byte with no register offset
      storeInstruction = new StoreInstruction(byteSize, storeRegister, sp);

    } else if (variableSize == SymbolTable.STACK_SIZE_4 && offset == 0) {

      // Store Word with no register offset
      storeInstruction = new StoreInstruction(word, storeRegister, sp);

    } else if (variableSize == SymbolTable.STACK_SIZE_1) {

      // Store Byte with a register offset
      storeInstruction = new StoreInstruction(byteSize, storeRegister,
          sp, String.valueOf(offset), true, false);

    } else if (variableSize == SymbolTable.STACK_SIZE_4) {

      // Store Word with a register offset
      storeInstruction = new StoreInstruction(word, storeRegister,
          sp, String.valueOf(offset), true, false);
    }
    program.addInstructions(storeInstruction);

    return null;
  }

  @Override
  public Void visitSeqComposition(@NotNull SeqCompositionContext ctx) {
    // call visit on statement 1 n 2
    visit(ctx.stat(0));
    visit(ctx.stat(1));
    return null;
  }

  @Override
  public Void visitBeginStatement(@NotNull BeginStatementContext ctx) {

    // Moving to next scope and retrieving totalOffSet for new scope
    program.moveIntoNextScope();

    int totalOffset = program.symbolTable.getTotalOffset();

//     Move the stack pointer depending on total offSet
    List<Instruction> stackSubtraction =
        program.initializeScopeOffset(totalOffset);
    for (Instruction instruction : stackSubtraction) {
      program.addInstructions(instruction);
    }

    // Generate command for the statement
    visit(ctx.stat());

    // Reset stack pointer to its original value if totalOffset is not zero
    List<Instruction> stackAddition =
        program.returnScopeOffset(totalOffset);
    for (Instruction instruction : stackAddition) {
      program.addInstructions(instruction);
    }

    // Leave the begin statement scope
    program.setSymbolTable(program.symbolTable.getParentSymbolTable());
    return null;
  }

  @Override
  public Void visitSkipStatement(@NotNull SkipStatementContext ctx) {
    // no code needs to be generated
    return null;
  }

  @Override
  public Void visitReadStatement(@NotNull ReadStatementContext ctx) {

    // Puts the right variable address in r0
    visit(ctx.assignlhs());

    Register r0 = program.getRegisters().getRegister("r0");

    String identifier = "";
    if (ctx.assignlhs() instanceof AssignlhsIdentContext) {
      identifier = ((AssignlhsIdentContext) ctx.assignlhs()).ident().getText();
    }

    Register register = program.getRegisters().getFreeRegister();
    int offset = program.symbolTable.getVariableTotalOffset(identifier);
    String offsetString = String.valueOf(offset);

    // Putting address of variable into a new register
    program.addInstructions(
        new AddInstruction(register, program.getRegisters().getRegister("sp"), offsetString));

    // Putting address in r0
    program.addInstructions(new MovInstruction(r0, register));

    if (ctx.assignlhs() instanceof AssignlhsArrayElemContext) {

      Type type = program.symbolTable.getFirstVar(Symbol.symbol(identifier)).getType();

      while (type instanceof ArrayType) {

        type = ((ArrayType) type).getType();
      }

      if (type.typeCheck(new BaseType(baseTypeEnum.CHAR))) {
        program.addInstructions(new BLInstruction("p_Read_Char"));
        if (!program.functionAlreadyDefined("Read_Char")) {
          program.readChar();
        }

      } else if (type.typeCheck(new BaseType(baseTypeEnum.INT))) {
        program.addInstructions(new BLInstruction("p_Read_Int"));
        if (!program.functionAlreadyDefined("Read_Int")) {
          program.readInt();
        }
      }

    } else if (ctx.assignlhs() instanceof AssignlhsPairelemContext) {

      Type type;

      PairType pairType
          = (PairType) program.symbolTable.getFirstVar(Symbol.symbol(identifier)).getType();
      Type pairElemType = null;

      if ((((AssignlhsPairelemContext) ctx.assignlhs()).pairelem()) instanceof PairElemFstContext) {

        pairElemType = pairType.getFst();

      } else if ((((AssignlhsPairelemContext) ctx.assignlhs())
          .pairelem()) instanceof PairElemSndContext) {

        pairElemType = pairType.getSnd();

      }

      if (pairElemType != null) {
        if (pairElemType instanceof ArrayType) {
          while (((ArrayType) pairElemType).getType() instanceof ArrayType) {
            pairElemType = ((ArrayType) pairElemType).getType();
          }

          type = ((ArrayType) pairElemType).getType();
        } else {
          type = pairElemType;
        }
      } else {
        throw new RuntimeException("Trying to read invalid variable");
      }
      if (type.typeCheck(new BaseType(baseTypeEnum.CHAR))) {
        program.addInstructions(new BLInstruction("p_Read_Char"));
        if (!program.functionAlreadyDefined("Read_Char")) {
          program.readChar();
        }

      } else if (type.typeCheck(new BaseType(baseTypeEnum.INT))) {
        program.addInstructions(new BLInstruction("p_Read_Int"));
        if (!program.functionAlreadyDefined("Read_Int")) {
          program.readInt();
        }
      }
    } else if (ctx.assignlhs() instanceof AssignlhsIdentContext) {

      Type type = program.symbolTable.getFirstVar(Symbol.symbol(identifier)).getType();

      if (type.typeCheck(new BaseType(baseTypeEnum.CHAR))) {
        program.addInstructions(new BLInstruction("p_Read_Char"));
        if (!program.functionAlreadyDefined("Read_Char")) {
          program.readChar();
        }

      } else if (type.typeCheck(new BaseType(baseTypeEnum.INT))) {
        program.addInstructions(new BLInstruction("p_Read_Int"));
        if (!program.functionAlreadyDefined("Read_Int")) {
          program.readInt();
        }
      }

    }

    // Call method read (int or char depending on the type)
    program.getRegisters().freeRegister(register);

    return null;
  }

  @Override
  public Void visitReturnStatement(@NotNull ReturnStatementContext ctx) {
    Register register0 = program.getRegisters().getRegister("r0");
    visit(ctx.expr());
    Register storageRegister = program.usedRegisters.pop();
    program.addInstructions(new MovInstruction(register0, storageRegister));
    program.addInstructions(new PopInstruction(program.getRegisters().getRegister("pc")));
    program.getRegisters().freeRegister(storageRegister);
    return null;
  }

  @Override
  public Void visitExitStatement(ExitStatementContext ctx) {

    visit(ctx.expr());
    Register resultRegister = program.usedRegisters.pop();
    program.getRegisters().freeRegister(resultRegister);
    Register r0 = program.getRegisters().getRegister("r0");
    program.addInstructions(new MovInstruction(r0, resultRegister));
    program.addInstructions(new BLInstruction("exit"));

    return null;
  }


  @Override
  public Void visitBracketedExpr(@NotNull BracketedExprContext ctx) {
    visit(ctx.expr());
    return null;
  }

  @Override
  public Void visitIntltrl(@NotNull IntltrlContext ctx) {
    Register register = program.getRegisters().getFreeRegister();
    // add register to storage stack
    program.usedRegisters.push(register);
    // get value of Int from string
    int integer = Integer.parseInt(ctx.getText());
    String result = String.valueOf(integer);
    // ldr command register int
    program.addInstructions(new LoadInstruction(word, register, result));
    return null;
  }

  @Override
  public Void visitBoolltrl(@NotNull BoolltrlContext ctx) {
    // get free register
    Register register = program.getRegisters().getFreeRegister();
    // add register to storage stack
    program.usedRegisters.push(register);
    // convert bool string to bool value aka 1 for true 0 for false
    String bool = ctx.BOOLLTRL().getText();
    int boolValue;
    if (bool.equals("true")) {
      boolValue = 1;
    } else {
      boolValue = 0;
    }

    program.addInstructions(new MovInstruction(register, boolValue));
    return null;
  }

  @Override
  public Void visitCharltrl(@NotNull CharltrlContext ctx) {

    // get free register
    Register register = program.getRegisters().getFreeRegister();
    // add register to storage stack
    program.usedRegisters.push(register);
    // get value of the char
    String charLtrl = ctx.getText();
    program.addInstructions(new MovInstruction(register, charLtrl));

    return null;
  }

  @Override
  public Void visitPairltrl(@NotNull PairltrlContext ctx) {

    // get free register
    Register register = program.getRegisters().getFreeRegister();
    // add register to storage stack
    program.usedRegisters.push(register);

    program.addInstructions(new LoadInstruction(word, register, "0"));
    return null;
  }

  @Override
  public Void visitStrltrl(@NotNull StrltrlContext ctx) {

    String stringltrl = ctx.STRLTRL().getText();
    stringltrl = stringltrl.substring(1, stringltrl.length() - 1);
    // get free register
    Register register = program.getRegisters().getFreeRegister();

    String label = program.MessageLabelGenerator(stringltrl);
    // add register to storage stack
    program.usedRegisters.push(register);
    // make label for string
    program.addInstructions(new LoadInstruction(word, register, label));

    return null;
  }

  @Override
  public Void visitArrayLiteral(ArrayLiteralContext ctx) {
    visit(ctx.arrayelem());
    return null;
  }

  @Override
  public Void visitArrayelem(ArrayelemContext ctx) {

    // gets a free register and add it in the storage register stack
    Register arrayReg = program.getRegisters().getFreeRegister();
    program.usedRegisters.push(arrayReg);

    // creates variable needed in commands
    Register sp = program.getRegisters().getRegister("sp");

    // gets variable offset and its string value
    String ident = ctx.IDENT().getText();
    Symbol varSymbol = Symbol.symbol(ident);
    Variable variable = program.symbolTable.getFirstVar(varSymbol);
    int offset = variable.getCurrentOffset();
    String offsetString = String.valueOf(offset);

    // add the command for the array address in the stack and shifts it
    // using the correct offset
    program.addInstructions(new AddInstruction(arrayReg, sp, offsetString));

    // gets R0 and R1 registers from the HardwareManager
    Register register0 = program.getRegisters().getRegister("r0");
    Register register1 = program.getRegisters().getRegister("r1");

    int exprOffset = 0;

    // generates commands of the the expression in arrayAccess
    for (int i = 0; ctx.expr().size() > i; i++) {
//      Expression arrayAccess : arrayAccesses

      // generates all the commands of the expression
      visit(ctx.expr(i));

      // loads the array in the memory
      program.addInstructions(new LoadInstruction(word, arrayReg, arrayReg));

      // gets the expression register
      Register exprReg = program.usedRegisters.pop();

      // mov the value of the expression register into the register R0

      program.addInstructions(new MovInstruction(register0, exprReg));

      // mov the arrayRegister into R1

      program.addInstructions(new MovInstruction(register1, arrayReg));

      program.addInstructions(new BLInstruction("p_Array_Out_Bounds"));
      if (!program.functionAlreadyDefined("Array_Out_Bounds")) {
        program.arrayOutBounds();
      }
      // mov array register in memory and offset it by 4
      program.addInstructions(new AddInstruction(arrayReg, arrayReg, "4"));

      // get the array element at the requested index

      Type innerArrayType = ((ArrayType) program.symbolTable.getFirstVar(varSymbol).getType())
          .getType();

      if (innerArrayType.typeCheck(new BaseType(baseTypeEnum.CHAR))
          || innerArrayType.typeCheck(new BaseType(baseTypeEnum.BOOL))) {
        program.addInstructions(new AddInstruction(arrayReg, arrayReg, exprReg));

        exprOffset = SymbolTable.STACK_SIZE_1;

      } else {
        program.addInstructions(new AddInstruction(arrayReg, arrayReg, exprReg, "LSL #2"));
        exprOffset = SymbolTable.STACK_SIZE_4;

      }

      // frees the expression register
      program.getRegisters().freeRegister(exprReg);

    }

    LoadInstruction loadElemIntoArrayRegister;

    if (exprOffset == SymbolTable.STACK_SIZE_1) {

      // loads the array element into the array register
      loadElemIntoArrayRegister
          = new LoadInstruction(byteSize, arrayReg, arrayReg);

    } else {

      loadElemIntoArrayRegister
          = new LoadInstruction(word, arrayReg, arrayReg);

    }

    program.addInstructions(loadElemIntoArrayRegister);

    return null;
  }

  @Override
  public Void visitIfStatement(IfStatementContext ctx) {

    String firstLabel = getLabelAndIncrementCounter();
    String secondLabel = getLabelAndIncrementCounter();

    // Moving to next scope and retrieving totalOffSet for new scope

    // Generate commands for ifCondition
    visit(ctx.expr());

    program.moveIntoNextScope();

    int totalOffset = program.symbolTable.getTotalOffset();

    // Evaluate ifCondition and free register
    Register ifConditionReturnRegister =
        program.usedRegisters.pop();
    program.addInstructions(new CmpInstruction(ifConditionReturnRegister, "0"));
    program.getRegisters().freeRegister(ifConditionReturnRegister);

    // Test if ifCondition is false
    program.addInstructions(new BEQInstruction("f_" + firstLabel));

    // Move the stack pointer depending on total offSet
    // (variable initialization) if not equal to zero
    List<Instruction> stackSubtraction =
        program.initializeScopeOffset(totalOffset);
    for (Instruction instruction : stackSubtraction) {
      program.addInstructions(instruction);
    }
    // Generate commands for thenStatement
    visit(ctx.stat(0));

    // Reset stack pointer to its original value if totalOffset is not zero
    List<Instruction> stackAddition =
        program.returnScopeOffset(totalOffset);
    for (Instruction instruction : stackAddition) {
      program.addInstructions(instruction);
    }

    // Test if ifCondition is true
    program.addInstructions(new BInstruction("f_" + secondLabel));

    // Moving to next scope and retrieving totalOffSet for new scope
    program.setSymbolTable(program.symbolTable.getParentSymbolTable());
    program.moveIntoNextScope();
    totalOffset = program.symbolTable.getTotalOffset();

    // Create label for else
    program.addInstructions(new LabelInstruction(firstLabel));

    // Move the stack pointer depending on total offSet
    // (variable initialization) if not equal to zero
    List<Instruction> stackSubtraction2 =
        program.initializeScopeOffset(totalOffset);
    for (Instruction instruction : stackSubtraction2) {
      program.addInstructions(instruction);
    }

    // Generate commands for ifStatement
    visit(ctx.stat(1));

    // Reset stack pointer to its original value if totalOffset is not zero
    List<Instruction> stackAddition2 =
        program.returnScopeOffset(totalOffset);
    for (Instruction instruction : stackAddition2) {
      program.addInstructions(instruction);
    }

    // Create label for rest of the code
    LabelInstruction labelRestOfProgram = new LabelInstruction(secondLabel);
    program.addInstructions(labelRestOfProgram);

    // Returning to if parent scope
    program.setSymbolTable(program.symbolTable.getParentSymbolTable());

    return null;
  }

  @Override
  public Void visitLogicalOperationExpr(LogicalOperationExprContext ctx) {
    visit(ctx.expr(0));

    Register register = program.usedRegisters.pop();

    // If we run out of registers, push r10 on the stack and free it in the
    // hardware manager as it has been push and can be used again
    if (register.getName().equals("r10")) {
      program.addInstructions(new PushInstruction(register));
      program.getRegisters().freeRegister(register);
    }

    program.usedRegisters.push(register);

    Register register2 = register;

    // generate commands for the right expression
    visit(ctx.expr(1));

    // get the storage register of right expression
    Register register3 = program.usedRegisters.pop();

    // frees register r3
    program.getRegisters().freeRegister(register3);

    // If we had run out of registers, then pop back the result from the
    // stack in r11 to perform operations
    if (register3.getName().equals("r10")) {
      // Perform check to see if we really ran our of registers
      Register nextStorageRegister
          = program.usedRegisters.pop();

      if (nextStorageRegister.getName().equals("r10")) {
        // Pop in register r11
        register3 = program.getRegisters().getRegister("r11");
        program.addInstructions(new PopInstruction(register3));

        // switch registers for operations
        register2 = register3;
        register3 = register;
      }

      // Put back the register taken to check if we ran out of registers
      program.usedRegisters.push(nextStorageRegister);
    }

    switch (ctx.logicaloper().getText()) {
      case "&&":
        // creates the and command
        program.addInstructions(new AndInstruction(register, register2, register3));
        break;

      case "||":
        // creates the or command
        program.addInstructions(new OrInstruction(register, register2, register3));

        break;
    }
    return null;
  }

  private void visitChildBinaryOperation1Expr(ExprContext ctx) {
    // A child binary op so then dont generate instruction jus put value on stack
    BinaryOperation1ExprContext expr = (BinaryOperation1ExprContext) ctx;

    int integer1 = 0;
    int integer2 = 0;
    int result = 0;
    ExprContext lExpr = expr.expr(0);
    ExprContext rExpr = expr.expr(1);

    if ((lExpr instanceof IntLiteralContext || lExpr instanceof BinaryOperation1ExprContext
        || lExpr instanceof BinaryOperation2ExprContext)
        && (rExpr instanceof IntLiteralContext || rExpr instanceof BinaryOperation1ExprContext
        || rExpr instanceof BinaryOperation2ExprContext)) {
      if (lExpr instanceof IntLiteralContext) {
        integer1 = Integer.parseInt(lExpr.getText());
      } else if (lExpr instanceof BinaryOperation1ExprContext) {
        visitChildBinaryOperation1Expr(lExpr);
        integer1 = constantStack.pop();
      } else {
        visitChildBinaryOperation2Expr(lExpr);
        integer1 = constantStack.pop();
      }
      if (rExpr instanceof IntLiteralContext) {
        integer2 = Integer.parseInt(rExpr.getText());
      } else if (rExpr instanceof BinaryOperation1ExprContext) {
        visitChildBinaryOperation1Expr(rExpr);
        integer2 = constantStack.pop();
      } else {
        visitChildBinaryOperation2Expr(rExpr);
        integer2 = constantStack.pop();
      }
    }

    switch (expr.binaryoper1().getText()) {

      case "*":
        result = integer1 * integer2;
        break;
      case "/":
        result = integer1 / integer2;
        break;
      case "%":
        result = integer1 % integer2;
        break;
      default:
        break;
    }
    constantStack.push(result);
  }

  private void visitChildBinaryOperation2Expr(ExprContext ctx) {
    // A child binary op so then dont generate instruction jus put value on stack
    BinaryOperation2ExprContext expr = (BinaryOperation2ExprContext) ctx;

    int integer1 = 0;
    int integer2 = 0;
    int result = 0;
    ExprContext lExpr = expr.expr(0);
    ExprContext rExpr = expr.expr(1);

    if ((lExpr instanceof IntLiteralContext || lExpr instanceof BinaryOperation1ExprContext
        || lExpr instanceof BinaryOperation2ExprContext)
        && (rExpr instanceof IntLiteralContext || rExpr instanceof BinaryOperation1ExprContext
        || rExpr instanceof BinaryOperation2ExprContext)) {
      if (lExpr instanceof IntLiteralContext) {
        integer1 = Integer.parseInt(lExpr.getText());
      } else if (lExpr instanceof BinaryOperation1ExprContext) {
        visitChildBinaryOperation1Expr(lExpr);
        integer1 = constantStack.pop();
      } else {
        visitChildBinaryOperation2Expr(lExpr);
        integer1 = constantStack.pop();
      }
      if (rExpr instanceof IntLiteralContext) {
        integer2 = Integer.parseInt(rExpr.getText());
      } else if (rExpr instanceof BinaryOperation1ExprContext) {
        visitChildBinaryOperation1Expr(rExpr);
        integer2 = constantStack.pop();
      } else {
        visitChildBinaryOperation2Expr(rExpr);
        integer2 = constantStack.pop();
      }
    }

    switch (expr.binaryoper2().getText()) {

      case "+":
        result = integer1 + integer2;
        break;
      case "-":
        result = integer1 - integer2;
        break;
      default:
        break;
    }
    constantStack.push(result);
  }


  @Override
  public Void visitBinaryOperation1Expr(BinaryOperation1ExprContext ctx) {

    int integer1;
    int integer2;
    int result;
    ExprContext lExpr = ctx.expr(0);
    ExprContext rExpr = ctx.expr(1);

    if ((lExpr instanceof IntLiteralContext || lExpr instanceof BinaryOperation1ExprContext
        || lExpr instanceof BinaryOperation2ExprContext)
        && (rExpr instanceof IntLiteralContext || rExpr instanceof BinaryOperation1ExprContext
        || rExpr instanceof BinaryOperation2ExprContext)) {
      if (lExpr instanceof IntLiteralContext) {
        integer1 = Integer.parseInt(lExpr.getText());
      } else if (lExpr instanceof BinaryOperation1ExprContext) {
        visitChildBinaryOperation1Expr(lExpr);
        integer1 = constantStack.pop();
      } else {
        visitChildBinaryOperation2Expr(lExpr);
        integer1 = constantStack.pop();
      }
      if (rExpr instanceof IntLiteralContext) {
        integer2 = Integer.parseInt(rExpr.getText());
      } else if (rExpr instanceof BinaryOperation1ExprContext) {
        visitChildBinaryOperation1Expr(rExpr);
        integer2 = constantStack.pop();
      } else {
        visitChildBinaryOperation2Expr(rExpr);
        integer2 = constantStack.pop();
      }

      switch (ctx.binaryoper1().getText()) {
        case "*":
          result = integer1 * integer2;
          String value = String.valueOf(result);
          Register freeReg = program.getRegisters().getFreeRegister();
          program.addInstructions(new LoadInstruction(freeReg, value));
          program.usedRegisters.push(freeReg);
          break;

        case "/":
          if (integer2 == 0) {
            errorHandler.divideByZero(ctx);
            break;
          }
          result = integer1 / integer2;
          value = String.valueOf(result);
          freeReg = program.getRegisters().getFreeRegister();
          program.addInstructions(new LoadInstruction(freeReg, value));
          program.usedRegisters.push(freeReg);
          break;

        case "%":
          result = integer1 / integer2;
          value = String.valueOf(result);
          freeReg = program.getRegisters().getFreeRegister();
          program.addInstructions(new LoadInstruction(freeReg, value));
          program.usedRegisters.push(freeReg);
          break;
        default:
          break;
      }

      return null;
    }

    // generate the commands of the left expression
    visit(ctx.expr(0));

    Register register = program.usedRegisters.peek();

    // If we run out of registers, push r10 on the stack and free it in the
    // hardware manager as it has been push and can be used again

    if (register.getName().equals("r10")) {
      program.addInstructions(new PushInstruction(register));
      program.getRegisters().freeRegister(register);
    }

    // program.usedRegisters.push(register);

    visit(ctx.expr(1));

    // get the storage register of right expression
    Register register3 = program.usedRegisters.pop();

    // frees register r3
    program.getRegisters().freeRegister(register3);

    // If we had run out of registers, then pop back the result from the
    // stack in r11 to perform operations
    if (register3.getName().equals("r10")) {
      // Perform check to see if we really ran our of registers
      Register nextStorageRegister = program.usedRegisters.pop();

      if (nextStorageRegister.getName().equals("r10")) {
        // Pop in register r11
        register3 = program.getRegisters().getRegister("r11");
        program.addInstructions(new PopInstruction(register3));

        // switch registers for operations
        register3 = register;
      }

      // Put back the register taken to check if we ran out of registers
      program.usedRegisters.push(nextStorageRegister);
    }

    Register register0 = program.getRegisters().getRegister("r0");
    Register register1 = program.getRegisters().getRegister("r1");

    // creations of the variables that are used in commands

    switch (ctx.binaryoper1().getText()) {

      case "*":

        Register overflowReg = program.getRegisters().getFreeRegister();
        program.addInstructions(new MulInstruction(register, overflowReg, register, register3));
        program.addInstructions(new CmpInstruction(overflowReg, register, "ASR #31"));
        program.addInstructions(new BLNEInstruction("f_Overflow"));
        if (!program.fNames.contains("Overflow")) {
          program.addOverflowFunc();
        }
        break;

      case "/":

        program.addInstructions(new MovInstruction(register0, register));
        program.addInstructions(new MovInstruction(register1, register3));
        program.addInstructions(new BLInstruction("p_Divide_By_Zero"));
        if (!program.functionAlreadyDefined("Divide_By_Zero")) {
          program.divideByZero();
        }
        program.addInstructions(new BLInstruction("__aeabi_idiv"));
        program.addInstructions(new MovInstruction(register, register0));

        break;

      case "%":

        program.addInstructions(new MovInstruction(register0, register));
        program.addInstructions(new MovInstruction(register1, register3));
        program.addInstructions(new BLInstruction("p_Divide_By_Zero"));
        if (!program.functionAlreadyDefined("Divide_By_Zero")) {
          program.divideByZero();
        }
        program.addInstructions(new BLInstruction("__aeabi_idivmod"));
        program.addInstructions(new MovInstruction(register, register1));

        break;

      default:
        break;
    }

    return null;
  }

  @Override
  public Void visitBinaryOperation2Expr(@NotNull BinaryOperation2ExprContext ctx) {

    int integer1;
    int integer2;
    int result;
    ExprContext lExpr = ctx.expr(0);
    ExprContext rExpr = ctx.expr(1);

    if ((lExpr instanceof IntLiteralContext || lExpr instanceof BinaryOperation1ExprContext
        || lExpr instanceof BinaryOperation2ExprContext)
        && (rExpr instanceof IntLiteralContext || rExpr instanceof BinaryOperation1ExprContext
        || rExpr instanceof BinaryOperation2ExprContext)) {
      if (lExpr instanceof IntLiteralContext) {
        integer1 = Integer.parseInt(lExpr.getText());
      } else if (lExpr instanceof BinaryOperation1ExprContext) {
        visitChildBinaryOperation1Expr(lExpr);
        integer1 = constantStack.pop();
      } else {
        visitChildBinaryOperation2Expr(lExpr);
        integer1 = constantStack.pop();
      }
      if (rExpr instanceof IntLiteralContext) {
        integer2 = Integer.parseInt(rExpr.getText());
      } else if (rExpr instanceof BinaryOperation1ExprContext) {
        visitChildBinaryOperation1Expr(rExpr);
        integer2 = constantStack.pop();
      } else {
        visitChildBinaryOperation2Expr(rExpr);
        integer2 = constantStack.pop();
      }

      switch (ctx.binaryoper2().getText()) {
        case "+":
          result = integer1 + integer2;
          String value = String.valueOf(result);
          Register freeReg = program.getRegisters().getFreeRegister();
          program.addInstructions(new LoadInstruction(freeReg, value));
          program.usedRegisters.push(freeReg);
          break;

        case "-":
          result = integer1 - integer2;
          value = String.valueOf(result);
          freeReg = program.getRegisters().getFreeRegister();
          program.addInstructions(new LoadInstruction(freeReg, value));
          program.usedRegisters.push(freeReg);
          break;

        default:
          break;
      }

      return null;
    }

    // generate the commands of the left expression
    visit(ctx.expr(0));

    Register register = program.usedRegisters.pop();

    // If we run out of registers, push r10 on the stack and free it in the
    // hardware manager as it has been push and can be used again
    if (register.getName().equals("r10")) {
      program.addInstructions(new PushInstruction(register));
      program.getRegisters().freeRegister(register);
    }

    program.usedRegisters.push(register);

    Register register2 = register;

    // generate commands for the right expression
    visit(ctx.expr(1));

    // get the storage register of right expression
    Register register3 = program.usedRegisters.pop();

    // frees register r3
    program.getRegisters().freeRegister(register3);

    // If we had run out of registers, then pop back the result from the
    // stack in r11 to perform operations
    if (register3.getName().equals("r10")) {
      // Perform check to see if we really ran our of registers
      Register nextStorageRegister
          = program.usedRegisters.pop();

      if (nextStorageRegister.getName().equals("r10")) {
        // Pop in register r11
        register3 = program.getRegisters().getRegister("r11");
        program.addInstructions(new PopInstruction(register3));

        // switch registers for operations
        register2 = register3;
        register3 = register;
      }

      // Put back the register taken to check if we ran out of registers
      program.usedRegisters.push(nextStorageRegister);
    }

    switch (ctx.binaryoper2().getText()) {

      case "+":
        program.addInstructions(new AddsInstruction(register, register2, register3));
        program.addInstructions(new BLVSInstruction("f_Overflow"));
        if (!program.fNames.contains("Overflow")) {
          program.addOverflowFunc();
        }
        break;

      case "-":
        // subtract r1 r3

        program.addInstructions(new SubsInstruction(register, register2, register3));
        program.addInstructions(new BLVSInstruction("f_Overflow"));
        if (!program.fNames.contains("Overflow")) {
          program.addOverflowFunc();
        }
        break;

      default:
        break;
    }

    return null;
  }

  @Override
  public Void visitBinaryOperation3Expr(@NotNull BinaryOperation3ExprContext ctx) {

    // generate the commands of the left expression
    visit(ctx.expr(0));

    Register register = program.usedRegisters.pop();

    // If we run out of registers, push r10 on the stack and free it in the
    // hardware manager as it has been push and can be used again
    if (register.getName().equals("r10")) {
      program.addInstructions(new PushInstruction(register));
      program.getRegisters().freeRegister(register);
    }

    program.usedRegisters.push(register);

    // generate commands for the right expression
    visit(ctx.expr(1));

    // get the storage register of right expression
    Register register3 = program.usedRegisters.pop();

    // frees register r3
    program.getRegisters().freeRegister(register3);

    // If we had run out of registers, then pop back the result from the
    // stack in r11 to perform operations
    if (register3.getName().equals("r10")) {
      // Perform check to see if we really ran our of registers
      Register nextStorageRegister
          = program.usedRegisters.pop();

      if (nextStorageRegister.getName().equals("r10")) {
        // Pop in register r11
        register3 = program.getRegisters().getRegister("r11");
        program.addInstructions(new PopInstruction(register3));

        // switch registers for operations
        register3 = register;
      }

      // Put back the register taken to check if we ran out of registers
      program.usedRegisters.push(nextStorageRegister);
    }

    // creations of the variables that are used in commands

    switch (ctx.binaryoper3().getText()) {

      case "<":
        // checks if r1 < r3
        program.addInstructions(new CmpInstruction(register, register3));

        // if true then r1 becomes 1 else becomes 0

        program.addInstructions(new MovLTInstruction(register, "1"));
        program.addInstructions(new MovGEInstruction(register, "0"));
        break;

      case "<=":
        // checks if r1 <= r3
        program.addInstructions(new CmpInstruction(register, register3));

        // if true then r1 becomes 1 else becomes 0

        program.addInstructions(new MovLEInstruction(register, "1"));
        program.addInstructions(new MovGTInstruction(register, "0"));
        break;

      case ">":
        // checks if r1 > r3
        program.addInstructions(new CmpInstruction(register, register3));

        // if true then r1 becomes 1 else becomes 0

        program.addInstructions(new MovGTInstruction(register, "1"));
        program.addInstructions(new MovLEInstruction(register, "0"));
        break;

      case ">=":
        // checks if r1 >= r3
        program.addInstructions(new CmpInstruction(register, register3));

        // if true then r1 becomes 1 else becomes 0

        program.addInstructions(new MovGEInstruction(register, "1"));
        program.addInstructions(new MovLTInstruction(register, "0"));
        break;

      default:
        break;
    }

    return null;
  }

  @Override
  public Void visitBinaryOperation4Expr(@NotNull BinaryOperation4ExprContext ctx) {

    // generate the commands of the left expression
    visit(ctx.expr(0));

    Register register = program.usedRegisters.pop();

    // If we run out of registers, push r10 on the stack and free it in the
    // hardware manager as it has been push and can be used again
    if (register.getName().equals("r10")) {
      program.addInstructions(new PushInstruction(register));
      program.getRegisters().freeRegister(register);
    }

    program.usedRegisters.push(register);


    // generate commands for the right expression
    visit(ctx.expr(1));

    // get the storage register of right expression
    Register register3 = program.usedRegisters.pop();

    // frees register r3
    program.getRegisters().freeRegister(register3);

    // If we had run out of registers, then pop back the result from the
    // stack in r11 to perform operations
    if (register3.getName().equals("r10")) {
      // Perform check to see if we really ran our of registers
      Register nextStorageRegister
          = program.usedRegisters.pop();

      if (nextStorageRegister.getName().equals("r10")) {
        // Pop in register r11
        register3 = program.getRegisters().getRegister("r11");
        program.addInstructions(new PopInstruction(register3));

        // switch registers for operations
        register3 = register;
      }

      // Put back the register taken to check if we ran out of registers
      program.usedRegisters.push(nextStorageRegister);
    }

    // creations of the variables that are used in commands

    switch (ctx.binaryoper4().getText()) {

      case "==":
        program.addInstructions(new CmpInstruction(register, register3));
        program.addInstructions(new MovEQInstruction(register, "1"));
        program.addInstructions(new MovNEInstruction(register, "0"));
        break;

      case "!=":
        program.addInstructions(new CmpInstruction(register, register3));
        program.addInstructions(new MovNEInstruction(register, "1"));
        program.addInstructions(new MovEQInstruction(register, "0"));
        break;

      default:
        break;
    }

    return null;
  }

  @Override
  public Void visitUnaryexpr(UnaryexprContext ctx) {
    visit(ctx.expr());

    Register register = program.usedRegisters.peek();

    switch (ctx.unaryoper().getText()) {
      case "!":
        // if unaryOp if !expression
        program.addInstructions(new EorInstruction(register, register, "1"));
        break;

      case "-":
        // if unaryOp if -expression
        program.addInstructions(new RSBInstruction(register, register, "0"));

        program.addInstructions(new BLVSInstruction("f_Overflow"));
        if (!program.functionAlreadyDefined("Overflow")) {
          program.addOverflowFunc();
        }

        break;

      case "len":

        // load the value of register in use in the memory

        program.addInstructions(new LoadInstruction(word, register, register));

        break;

      case "ord":

      case "chr":

      default:
        break;
    }

    return null;
  }

  @Override
  public Void visitAssignlhsIdent(AssignlhsIdentContext ctx) {
    visit(ctx.ident());
    return null;
  }

  @Override
  public Void visitIdentExpr(IdentExprContext ctx) {
    Register register = program.getRegisters().getFreeRegister();
    program.usedRegisters.push(register);
    if (program.isMemoryAddressBeingFreed()) {
      if (program.hasAlreadyBeenFreed(ctx.ident().getText())) {
        if (!program.functionAlreadyDefined("Runtime_Error")) {
          program.addRuntimeError();
        }
      } else {
        program.setToALreadyFreed(ctx.ident().getText());
        program.setMemoryAddressBeingFreed(false);
      }
    }

    Register sp = program.getRegisters().getRegister("sp");
    Variable variable = program.symbolTable.getFirstVar(Symbol.symbol(ctx.ident().getText()));
    int variableSize = variable.getMemorySize();
    int offset = program.symbolTable.getVariableTotalOffset(ctx.ident().getText())
        + program.getTemporaryScopeOffset();
    String offsetString = String.valueOf(offset);

    LoadInstruction loadVariable = null;

    if (variableSize == SymbolTable.STACK_SIZE_1 && offset == 0) {
      loadVariable
          = new LoadInstruction(Sizes.SB, register, sp);

    } else if (variableSize == SymbolTable.STACK_SIZE_4 && offset == 0) {
      loadVariable
          = new LoadInstruction(word, register, sp);

    } else if (variableSize == SymbolTable.STACK_SIZE_1) {
      loadVariable
          = new LoadInstruction(Sizes.SB, register, sp,
          offsetString, true, false);

    } else if (variableSize == SymbolTable.STACK_SIZE_4) {
      loadVariable
          = new LoadInstruction(word, register, sp,
          offsetString, true, false);
    }

    program.addInstructions(loadVariable);

    return null;
  }

  @Override
  public Void visitWhileStatement(WhileStatementContext ctx) {

    String firstLabel = getLabelAndIncrementCounter();
    String secondLabel = getLabelAndIncrementCounter();

    // Moving to next scope and retrieving totalOffSet for new scope
    program.moveIntoNextScope();
    int totalOffset = program.symbolTable.getTotalOffset();

    // Jump to test if whileCondition is true
    program.addInstructions(new BInstruction("f_" + firstLabel));

    // Create label for loop
    program.addInstructions(new LabelInstruction(secondLabel));

    // Move the stack pointer depending on total offSet
    // (variable initialization) if not equal to zero
    List<Instruction> stackSubtractions =
        program.initializeScopeOffset(totalOffset);
    for (Instruction stackSubtraction : stackSubtractions) {
      program.addInstructions(stackSubtraction);
    }

    // Generate command for doStatement
    visit(ctx.stat());

    // Reset stack pointer to its original value if totalOffset is not zero
    List<Instruction> stackAddition =
        program.returnScopeOffset(totalOffset);
    for (Instruction instruction : stackAddition) {
      program.addInstructions(instruction);
    }

    // Create label for test whileCondition and rest of the code
    program.addInstructions(new LabelInstruction(firstLabel));

    // Generate command for doStatement
    visit(ctx.expr());

    // Evaluate WhileCondition
    Register whileConditionReturnRegister = program.usedRegisters.pop();
    program.addInstructions(new CmpInstruction(whileConditionReturnRegister, "1"));
    program.getRegisters().freeRegister(whileConditionReturnRegister);

    // Test if whileCondition is false
    program.addInstructions(new BEQInstruction("f_" + secondLabel));

    // Leave the while statement scope
    program.setSymbolTable(program.symbolTable.getParentSymbolTable());
    return null;
  }

  @Override
  public Void visitAssignlhsArrayElem(AssignlhsArrayElemContext ctx) {

    Register sp = program.getRegisters().getRegister("sp");

    String varName = ctx.arrayelem().IDENT().getText();
    int offset = program.symbolTable.getVariableTotalOffset(varName);
    String offsetString = String.valueOf(offset);

    // gets R0 and R1 registers from the HardwareManager
    Register register0 = program.getRegisters().getRegister("r0");
    Register register1 = program.getRegisters().getRegister("r1");

    Register arrayReg = program.getRegisters().getFreeRegister();
    program.usedRegisters.push(arrayReg);

    // add the command for the array address in the stack and shifts it
    // using the correct offset
    program.addInstructions(new AddInstruction(arrayReg, sp, offsetString));

    // generates commands of the the expression in arrayAccess
    for (ExprContext expr : ctx.arrayelem().expr()) {

      // generates all the commands of the expression
      visit(expr);

      // loads the array in the memory
      program.addInstructions(new LoadInstruction(word, arrayReg, arrayReg));

      // gets the expression register
      Register exprReg = program.usedRegisters.pop();

      // mov the value of the expression register into the register R0
      program.addInstructions(new MovInstruction(register0, exprReg));

      // mov the arrayRegister into R1
      program.addInstructions(new MovInstruction(register1, arrayReg));

      program.addInstructions(new BLInstruction("p_Array_Out_Bounds"));
      if (!program.functionAlreadyDefined("Array_Out_Bounds")) {
        program.arrayOutBounds();
      }

      // mov array register in memory and offset it by 4
      program.addInstructions(new AddInstruction(arrayReg, arrayReg, "4"));

      // get the array element at the requested index
      Type innerArrayType = program.symbolTable.getFirstVar(Symbol.symbol(varName)).getType();

      while (innerArrayType instanceof ArrayType) {
        innerArrayType = ((ArrayType) innerArrayType).getType();
      }

      if (innerArrayType.typeCheck(new BaseType(baseTypeEnum.CHAR))
          || innerArrayType.typeCheck(new BaseType(baseTypeEnum.BOOL))) {

        program.addInstructions(new AddInstruction(arrayReg,
            arrayReg, exprReg));

      } else {
        program.addInstructions(new AddInstruction(arrayReg,
            arrayReg, exprReg, "LSL #2"));
      }

      // frees the expression register
      program.getRegisters().freeRegister(exprReg);

    }
    return null;
  }

  @Override
  public Void visitAssignrhsArrayLtrl(AssignrhsArrayLtrlContext ctx) {

    final int ARRAY_MEMORY_SIZE = 4;
    final int ONE_BYTE_MEMORY_SIZE = 1;
    final int FOUR_BYTE_MEMORY_SIZE = 4;

    Register register0 = program.getRegisters().getRegister("r0");

    // Getting the size of the array
    int size = ctx.arrayltrl().expr().size();
    String valueSize = String.valueOf(size);

    // Getting the offset of an element in the array
    int arrayElementOffset = 0;

    if (size > 0) {

      ExprContext firstExpr = ctx.arrayltrl().expr(0);

      if (firstExpr instanceof CharLiteralContext
          || firstExpr instanceof BoolLiteralContext) {
        arrayElementOffset = ONE_BYTE_MEMORY_SIZE;

      } else {
        arrayElementOffset = FOUR_BYTE_MEMORY_SIZE;
      }

    }

    // Getting amount of memory needed
    int memoryAllocation = ARRAY_MEMORY_SIZE + arrayElementOffset * size;
    String sizeStringValue = String.valueOf(memoryAllocation);

    // Loading the memory needed into r0
    program.addInstructions(new LoadInstruction(word, register0, sizeStringValue));

    // Calling malloc to allocate space in memory
    program.addInstructions(new BLInstruction("malloc"));

    // Moving into a new register the amount of memory needed
    Register storage = program.getRegisters().getFreeRegister();
    program.addInstructions(new MovInstruction(storage, register0));

    int i = 0;

    for (ExprContext expr : ctx.arrayltrl().expr()) {

      visit(expr);

      String offset;
      if (expr instanceof CharLiteralContext
          || expr instanceof BoolLiteralContext) {

        offset = String.valueOf(ARRAY_MEMORY_SIZE + i);

      } else {
        offset = String.valueOf(ARRAY_MEMORY_SIZE * (i + 1));
      }
      Register strRegister = program.usedRegisters.pop();
      program.getRegisters().freeRegister(strRegister);
      program.addInstructions(new StoreInstruction(word, strRegister, storage,
          offset, true, false));
      i++;
    }

    Register strRegister = program.getRegisters().getFreeRegister();
    program.usedRegisters.push(strRegister);
    program.addInstructions(new LoadInstruction(word, strRegister, valueSize));
    program.addInstructions(new StoreInstruction(word, strRegister, storage));

    program.usedRegisters.push(storage);
    program.getRegisters().freeRegister(strRegister);

    return null;
  }

  @Override
  public Void visitAssignlhsPairelem(AssignlhsPairelemContext ctx) {
    ExprContext expr;
    String pairElemCase;
    if (ctx.pairelem() instanceof PairElemFstContext) {
      expr = ((PairElemFstContext) ctx.pairelem()).expr();
      pairElemCase = "fst";
    } else if (ctx.pairelem() instanceof PairElemSndContext) {
      pairElemCase = "snd";
      expr = ((PairElemSndContext) ctx.pairelem()).expr();
    } else {
      expr = null;
      pairElemCase = null;
    }

    if (expr != null) {
      visit(expr);
    }

    Register exprReg = program.usedRegisters.peek();
    Register register0 = program.getRegisters().getRegister("r0");

    // Mov expr register into r0
    program.addInstructions(new MovInstruction(register0, exprReg));

    // load the correct value into the expression reg corresponding to
    // the position requested
    if (pairElemCase != null) {
      switch (pairElemCase) {

        case "fst":
          program.addInstructions(new LoadInstruction(word, exprReg, exprReg));
          break;
        case "snd":
          program.addInstructions(new LoadInstruction(word,
              exprReg, exprReg, "4", true, false));
          break;

        default:
          break;
      }
    }

    return null;
  }

  @Override
  public Void visitAssignrhsPairelem(AssignrhsPairelemContext ctx) {
    ExprContext expr;
    String pairElemCase;

    if (ctx.pairelem() instanceof PairElemFstContext) {
      pairElemCase = "fst";
      expr = ((PairElemFstContext) ctx.pairelem()).expr();
      visit(expr);
    } else if (ctx.pairelem() instanceof PairElemSndContext) {
      pairElemCase = "snd";
      expr = ((PairElemSndContext) ctx.pairelem()).expr();
      visit(expr);
    } else {
      expr = null;
      pairElemCase = null;
    }

    // generates and add the commands of the expression into the list of
    // commands

    // gets the expression register
    Register exprReg = program.usedRegisters.peek();
    Register register0 = program.getRegisters().getRegister("r0");

    // Mov expr register into r0

    program.addInstructions(new MovInstruction(register0, exprReg));

    // load the correct value into the expression reg corresponding to
    // the position requested
    if (pairElemCase != null) {
      switch (pairElemCase) {

        case "fst":
          program.addInstructions(new LoadInstruction(word, exprReg, exprReg));
          break;
        case "snd":
          program.addInstructions(new LoadInstruction(word, exprReg, exprReg, "4", true, false));
          break;

        default:
          break;
      }
    }

    // gets the type of the pair
    if (expr instanceof IdentExprContext) {
      String ident = ((IdentExprContext) expr).ident().getText();
      Variable variable = program.symbolTable.getFirstVar(Symbol.symbol(ident));
      PairType pair = (PairType) variable.getType();

      int offset = 0;

      switch (pairElemCase) {

        case "fst":
          // gets the type of the first element of the pair
          Type pairElementType = pair.getFst();

          offset = getOffset(pairElementType);
          break;

        case "snd":
          // gets the type of the second element of the pair
          pairElementType = pair.getSnd();

          offset = getOffset(pairElementType);
          break;

        default:
          break;
      }

      // generate the correct load command depending on the offset
      if (offset == SymbolTable.STACK_SIZE_1) {
        program.addInstructions(new LoadInstruction(byteSize, exprReg, exprReg));

      } else {
        program.addInstructions(new LoadInstruction(word, exprReg, exprReg));
      }
    }

    return null;

  }

  private int getOffset(Type pairElementType) {
    int offset;

    if (pairElementType != null) {

      // set the offset depending on the type of the element
      offset = getTypeOffset(pairElementType);

    } else {

      offset = SymbolTable.STACK_SIZE_4;
    }
    return offset;
  }

  private int getTypeOffset(Type type) {

    int offset;
    if (type.typeCheck(new BaseType(baseTypeEnum.BOOL))
        || type.typeCheck(new BaseType(baseTypeEnum.CHAR))) {
      offset = SymbolTable.STACK_SIZE_1;
    } else {
      offset = SymbolTable.STACK_SIZE_4;
    }
    return offset;
  }

  @Override
  public Void visitAssignrhsPair(AssignrhsPairContext ctx) {
    Register register0 = program.getRegisters().getRegister("r0");

    // load the value 8 in R0
    program.addInstructions(new LoadInstruction(word, register0, "8"));

    // allocate the first elem of newpair
    program.addInstructions(new BLInstruction("malloc"));

    Register exprRegister = program.getRegisters().getFreeRegister();
    program.usedRegisters.push(exprRegister);

    //mov exprRegister in R0
    program.addInstructions(new MovInstruction(exprRegister, register0));

    // generates command for the first elem
    visit(ctx.expr(0));

    // left expression register
    Register leftExprRegister = program.usedRegisters.pop();
    program.getRegisters().freeRegister(leftExprRegister);

    int offset;

    // load the correct value in R0
    if (ctx.expr(0) instanceof CharLiteralContext
        || ctx.expr(0) instanceof BoolLiteralContext) {

      program.addInstructions(new LoadInstruction(word, register0, "1"));
      offset = SymbolTable.STACK_SIZE_1;

    } else {
      program.addInstructions(new LoadInstruction(word, register0, "4"));
      offset = SymbolTable.STACK_SIZE_4;
    }

    // allocate the second elem of newpair
    program.addInstructions(new BLInstruction("malloc"));

    // store last register in R0
    StoreInstruction strLeftRegInR0;

    if (offset == SymbolTable.STACK_SIZE_1) {
      strLeftRegInR0
          = new StoreInstruction(byteSize, leftExprRegister, register0);
    } else {
      strLeftRegInR0 = new StoreInstruction(word, leftExprRegister, register0);
    }
    program.addInstructions(strLeftRegInR0);

    // store R0 in memory

    program.addInstructions(new StoreInstruction(word, register0, exprRegister));

    // generates command for second expression
    visit(ctx.expr(1));
    Register rightExprRegister = program.usedRegisters.pop();
    program.getRegisters().freeRegister(rightExprRegister);

    // load the correct value in R0
    if (ctx.expr(1) instanceof CharLiteralContext
        || ctx.expr(1) instanceof BoolLiteralContext) {

      program.addInstructions(new LoadInstruction(word, register0, "1"));
      offset = SymbolTable.STACK_SIZE_1;

    } else {
      program.addInstructions(new LoadInstruction(word, register0, "4"));
      offset = SymbolTable.STACK_SIZE_4;
    }
    // allocate the new pair
    program.addInstructions(new BLInstruction("malloc"));

    // store last register in R0

    StoreInstruction strRightRegInR0;
    if (offset == SymbolTable.STACK_SIZE_1) {

      strRightRegInR0
          = new StoreInstruction(byteSize, rightExprRegister, register0);

    } else {

      strRightRegInR0 = new StoreInstruction(word, rightExprRegister, register0);
    }
    program.addInstructions(strRightRegInR0);

    // store R0 in memory
    program.addInstructions(new StoreInstruction(word, register0, exprRegister, "4", true, false));

    return null;
  }

  @Override
  public Void visitAssignrhsFunctionCall(AssignrhsFunctionCallContext ctx) {
    Register spRegister = program.getRegisters().getRegister("sp");

    // SP Register

    int totalOffsetSize = 0;
    // total offset = 0

    // Get function Name
    String funcName = ctx.ident().getText();

    // Get Parameter Offsets
    List<Integer> sizeParameter = program.symbolTable.getFirstFunc(Symbol.symbol(funcName))
        .getParameterOffset();

    if (ctx.arglist() != null) {

      // for loop backwards over arglist
      for (int i = ctx.arglist().expr().size() - 1; i >= 0; i--) {

        int currentParameterSize = sizeParameter.get(i);
        String currentParameter = "-"
            + String.valueOf(currentParameterSize);
        totalOffsetSize += currentParameterSize;

        // Generate commands for argument i
        visit(ctx.arglist().expr(i));

        // Get register to use
        Register usedRegister = program.usedRegisters.pop();

        // Add argument in the stack
        if (currentParameterSize == SymbolTable.STACK_SIZE_1) {
          program.addInstructions(new StoreInstruction(byteSize, usedRegister,
              spRegister, currentParameter, true, true));
        } else if (currentParameterSize == SymbolTable.STACK_SIZE_4) {
          program.addInstructions(new StoreInstruction(word, usedRegister,
              spRegister, currentParameter, true, true));
        }

        // Free used register
        program.getRegisters().freeRegister(usedRegister);

        // Add temporary offset
        program.addToTemporaryOffset(currentParameterSize);
      }
    }

    // Jump command to function Identifier
    program.addInstructions(new BLInstruction("f_" + funcName));

    // Reset stack pointer to its original value if totalOffset is not zero
    List<Instruction> stackAddition =
        program.returnScopeOffset(totalOffsetSize);
    for (Instruction instruction : stackAddition) {
      program.addInstructions(instruction);
    }

    // Reset temporary offset
    program.resetTemporaryOffset();

    // Mov command to retrieve function return statement
    Register usedRegister = program.getRegisters().getFreeRegister();
    program.addInstructions(new MovInstruction(usedRegister,
        program.getRegisters().getRegister("r0")));

    program.usedRegisters.push(usedRegister);
    return null;
  }

  @Override
  public Void visitFreeStatement(FreeStatementContext ctx) {

    //List<Command> commands = new ArrayList<>();
    program.setMemoryAddressBeingFreed(true);
    visit(ctx.expr());
    Register register = program.usedRegisters.pop();
    program.getRegisters().freeRegister(register);
    Register register0 = program.getRegisters().getRegister("r0");
    // mov the expression register into R0;
    program.addInstructions(new MovInstruction(register0, register));
    // calls p_free_pair
    program.addInstructions(new BLInstruction("p_free_pair"));
    if (!program.functionAlreadyDefined("free_pair")) {
      program.freePair();
    }

    return null;
  }

}
