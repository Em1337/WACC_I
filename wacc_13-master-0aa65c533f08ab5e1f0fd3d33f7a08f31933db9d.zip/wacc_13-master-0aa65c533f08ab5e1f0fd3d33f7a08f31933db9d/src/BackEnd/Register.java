package BackEnd;

public class Register {

  private final String name;
  public boolean free;

  public Register(String name) {
    this.name = name;
    free = true;
  }

  public Register(String name, boolean free) {
    this.name = name;
    this.free = free;
  }

  public String getName() {
    return name;
  }

  public boolean isFree() {
    return free;
  }

  void inUse() {
    free = false;
  }

  void setFree() {
    free = true;
  }

  @Override
  public String toString() {
    return this.getName();
  }
}
