package BackEnd.Instructions;

public class BLLTInstruction implements Instruction {

  private String label;

  public BLLTInstruction(String label) {
    this.label = label;
  }

  @Override
  public String generateCode() {
    return "BLLT " + label;
  }

}
