package BackEnd.Instructions;

public class BLCSInstruction implements Instruction {
  private String funcName;

  public BLCSInstruction(String funcName) {
    this.funcName = funcName;
  }

  @Override
  public String generateCode() {
    return "BLCS " + funcName;
  }
}
