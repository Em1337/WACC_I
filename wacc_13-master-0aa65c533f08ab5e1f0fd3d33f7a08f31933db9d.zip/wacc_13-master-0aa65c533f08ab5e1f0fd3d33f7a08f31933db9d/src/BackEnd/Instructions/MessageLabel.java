package BackEnd.Instructions;

public class MessageLabel implements Instruction {


    private String message;
    private int length;
    private String ident;

    public MessageLabel(String message, int index) {
      this.ident = "msg_" + index;
      this.message = message;
      this.length = reduce(message).length();
    }

    public String getIdent() {
      return ident;
    }

    private String reduce(String message) {
    return message.replace("\\0", "\0").replace("\\b", "\b").replace("\\n", "\n").replace("\\f", "\f").replace("\\r", "\r").replace("\\\"", "\"").replace("\\'", "'").replace("\\\\", "\\");
      }

  @Override
  public String generateCode() {
    return ident + ":\n"
        + "\t.word " + length + '\n'
        + "\t.ascii \"" +  message  + "\"\n";
  }
}
