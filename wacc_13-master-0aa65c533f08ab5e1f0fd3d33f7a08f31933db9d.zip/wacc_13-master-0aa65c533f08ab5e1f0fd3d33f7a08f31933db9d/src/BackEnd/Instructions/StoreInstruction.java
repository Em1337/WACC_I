package BackEnd.Instructions;

import BackEnd.Register;
import BackEnd.Registers.Sizes;

public class StoreInstruction implements Instruction{

  private Sizes size;
  private Register dest;
  private Register src;
  private Register src2;
  private boolean isPreIndexAddressing;
  private String value;
  private String offset;
  private AddressType addressType;

  public String getOffset() {
    if (offset != null) {
      return offset;
    } else {
      return "";
    }
  }

  public Register getDest() {
    return dest;
  }

  public Register getSrc() {
    return src;
  }

  public StoreInstruction(Sizes size,
      Register dest,
      Register src) {

    this.size = size;
    this.dest = dest;
    this.src = src;
    this.src2 = null;
    this.isPreIndexAddressing = false;
    this.value = null;
    this.offset = null;

    addressType = AddressType.REGISTER;
  }

  public StoreInstruction(Sizes size,
      Register dest,
      Register src,
      String offset,
      boolean isPreIndexAddressing,
      boolean isDualUpdating) {

    this.size = size;
    this.dest = dest;
    this.src = src;
    this.src2 = null;
    this.isPreIndexAddressing = isPreIndexAddressing;
    this.offset = offset;
    this.value = null;

    if (isDualUpdating) {
      addressType = AddressType.IMMEDIATE_OFFSET_DUAL_UPDATING;
    } else {
      addressType = AddressType.IMMEDIATE_OFFSET;
    }
  }



  @Override
  public String generateCode() {
    String dataType;
    if (size == Sizes.W) {
      dataType = "";
    } else {
      dataType = size.toString();
    }

    switch (addressType) {

      case VALUE:
        return "STR" + dataType + " "
            + dest.getName() + ", =" + value;

      case REGISTER:
        return "STR" + dataType + " "
            + dest.getName() + ", " + "[" + src.getName() + "]";

      case IMMEDIATE_OFFSET:

        if (isPreIndexAddressing) {

          return "STR" + dataType
              + " " + dest.getName() + ", " + "["
              + src.getName() + ", #" + offset + "]";

        } else {

          return "STR" + dataType
              + " " + dest.getName() + ", " + "["
              + src.getName() + "], " + offset;

        }

      case IMMEDIATE_OFFSET_DUAL_UPDATING:

        return "STR" + dataType
            + " " + dest.getName() + ", " + "["
            + src.getName() + ", #" + offset + "]!";

      case REGISTER_OFFSET:

        if (isPreIndexAddressing) {

          return "STR" + dataType
              + " " + dest.getName() + ", " + "["
              + src.getName() + ", " + src2.getName() + "]";

        } else {

          return "STR" + dataType
              + " " + dest.getName() + ", " + "["
              + src.getName() + "], [" + src2.getName() + "]";

        }

      case REGISTER_OFFSET_DUAL_UPDATING:

        return "STR" + dataType
            + " " + dest.getName() + ", " + "["
            + src.getName() + ", " + src2.getName() + "]!";

      case REGISTER_SHIFTED_OFFSET:

        if (isPreIndexAddressing) {

          return "STR" + dataType
              + " " + dest.getName() + ", " + "["
              + src.getName() + ", " + src2.getName() + ", "
              + offset + "]";

        } else {

          return "STR" + dataType
              + " " + dest.getName() + ", " + "["
              + src.getName() + "], " + src2.getName() + ", "
              + offset;

        }

      case REGISTER_SHIFTED_OFFSET_DUAL_UPDATING:

        return "STR" + dataType
            + " " + dest.getName() + ", " + "["
            + src.getName() + ", " + src2.getName() + ", "
            + offset + "]!";

      default:
        return null;
    }
  }

}
