package BackEnd.Instructions;

import BackEnd.Register;

public class LoadCSInstruction implements Instruction {

  private Register dest;
  private String srcChar;
  private Boolean isLabel;

  public LoadCSInstruction(Register dest, String srcChar, Boolean isLabel) {
    this.dest = dest;
    this.srcChar = srcChar;
    this.isLabel = isLabel;
  }

  public Register getDest() {
    return dest;
  }

  @Override
  public String generateCode() {
    if (isLabel){
      return "LDRCS " + dest.getName() + ", =" + srcChar;
      }
      return "LDRCS " + dest.getName() + ", #" + srcChar;
    }
}

