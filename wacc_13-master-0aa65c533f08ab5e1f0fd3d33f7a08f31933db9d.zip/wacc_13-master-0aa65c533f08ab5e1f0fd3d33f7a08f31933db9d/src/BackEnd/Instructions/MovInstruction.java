package BackEnd.Instructions;

import BackEnd.Register;

public class MovInstruction implements Instruction {

    private Register dest;
    private Register src;
    private int srcInt;
    private String srcChar;

    public MovInstruction(Register dest, Register src) {
      this.dest = dest;
      this.src = src;
    }


  public MovInstruction(Register dest, int srcInt) {
    this.dest = dest;
    this.srcInt = srcInt;
  }

  public MovInstruction(Register dest, String srcChar){
    this.dest = dest;
    this.srcChar = srcChar;
  }

  public Register getSrc() {
      return src;
    }

  public Register getDest() {
      return dest;
    }

  @Override
  public String generateCode() {
    if (src != null){
      return "MOV " + dest.getName() + ", " + src.getName();
    } else if (srcChar != null){
      return "MOV " + dest.getName() + ", #" + srcChar;
    } else {
      return "MOV " + dest.getName() + ", #" + srcInt;
    }

  }
}
