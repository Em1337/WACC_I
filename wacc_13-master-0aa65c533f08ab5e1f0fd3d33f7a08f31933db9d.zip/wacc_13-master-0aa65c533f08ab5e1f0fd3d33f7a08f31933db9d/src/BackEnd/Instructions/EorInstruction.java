package BackEnd.Instructions;

import BackEnd.Register;

public class EorInstruction implements Instruction {
  private Register dest;
    private Register src;
    private String value;

  public EorInstruction(Register dest,
        Register src,
        String value) {

      this.dest = dest;
      this.src = src;
      this.value = value;
    }


    @Override
    public String generateCode() {

        return "EOR " + dest + ", " + src + ", #" + value;
    }
}
