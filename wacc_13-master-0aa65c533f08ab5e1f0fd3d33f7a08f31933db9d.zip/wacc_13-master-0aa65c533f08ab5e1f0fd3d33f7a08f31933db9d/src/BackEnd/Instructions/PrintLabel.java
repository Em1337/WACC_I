package BackEnd.Instructions;

public class PrintLabel implements Instruction {

  private String label;

  public PrintLabel(String label) {
    this.label = label;
  }

  @Override
  public String generateCode() {
      return "p_" + label + ":";
  }

}
