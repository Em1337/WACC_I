package BackEnd.Instructions;

public interface Instruction {

  String generateCode();
}
