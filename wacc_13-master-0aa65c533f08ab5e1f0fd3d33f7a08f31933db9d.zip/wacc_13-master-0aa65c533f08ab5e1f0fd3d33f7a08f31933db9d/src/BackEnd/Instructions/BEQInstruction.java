package BackEnd.Instructions;

public class BEQInstruction implements Instruction {
  private String label;

  public BEQInstruction(String label) {
    this.label = label;
  }

  @Override
  public String generateCode() {
    return "BEQ " + label;
  }
}
