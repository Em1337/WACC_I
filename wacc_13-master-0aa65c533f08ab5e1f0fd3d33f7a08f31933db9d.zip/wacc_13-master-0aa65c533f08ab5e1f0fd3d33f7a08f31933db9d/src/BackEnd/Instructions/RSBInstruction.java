package BackEnd.Instructions;

import BackEnd.Register;

public class RSBInstruction implements Instruction {
  private Register dest;
  private Register src;
  private String value;

  public RSBInstruction(Register dest,
      Register src,
      String value) {

    this.dest = dest;
    this.src = src;
    this.value = value;
  }

  @Override
  public String generateCode() {

      return "RSBS " + dest + ", " + src + ", #" + value;

  }
}
