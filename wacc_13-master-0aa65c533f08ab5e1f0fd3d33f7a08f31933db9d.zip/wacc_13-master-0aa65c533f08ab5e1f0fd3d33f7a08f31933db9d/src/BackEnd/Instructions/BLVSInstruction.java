package BackEnd.Instructions;

public class BLVSInstruction implements Instruction {

  private String label;

  public BLVSInstruction(String label) {
    this.label = label;
  }

  @Override
  public String generateCode() {
    return "BLVS " + label;
  }

}
