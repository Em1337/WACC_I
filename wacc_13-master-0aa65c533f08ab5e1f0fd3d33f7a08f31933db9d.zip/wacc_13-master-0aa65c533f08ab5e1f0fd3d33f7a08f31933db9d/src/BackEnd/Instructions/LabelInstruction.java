package BackEnd.Instructions;

public class LabelInstruction implements Instruction {

  private String label;

  public LabelInstruction(String label) {
    this.label = label;
  }

  @Override
  public String generateCode() {
    if (label.equals("main")) {
      return label + ":";
    } else {
      return "f_" + label + ":";
    }
  }
}
