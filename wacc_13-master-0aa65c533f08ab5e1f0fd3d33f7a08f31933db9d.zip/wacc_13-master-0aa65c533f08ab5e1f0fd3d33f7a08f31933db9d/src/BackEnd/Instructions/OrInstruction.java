package BackEnd.Instructions;

import BackEnd.Register;

public class OrInstruction implements Instruction {
  private Register dest;
  private Register src;
  private Register src2;

  public OrInstruction(Register dest,
      Register src,
      Register src2) {

    this.dest = dest;
    this.src = src;
    this.src2 = src2;
  }

  @Override
  public String generateCode() {

      return "ORR " + dest + ", " + src + ", " + src2;

  }
}
