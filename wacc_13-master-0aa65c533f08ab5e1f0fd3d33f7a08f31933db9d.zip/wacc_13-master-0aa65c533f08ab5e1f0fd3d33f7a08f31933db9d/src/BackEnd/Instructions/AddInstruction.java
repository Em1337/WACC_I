package BackEnd.Instructions;

import BackEnd.Register;

public class AddInstruction implements Instruction {

  private Register destinationRegister;
  private Register sourceRegister;
  private String value;
  private Register sourceRegister2;
  private String registerShift;

  public AddInstruction(Register destinationRegister,
      Register sourceRegister,
      String value) {

    this.destinationRegister = destinationRegister;
    this.sourceRegister = sourceRegister;
    this.value = value;
    this.sourceRegister2 = null;
    this.registerShift = null;
  }

  public AddInstruction(Register destinationRegister,
      Register sourceRegister,
      Register sourceRegister2) {

    this.destinationRegister = destinationRegister;
    this.sourceRegister = sourceRegister;
    this.sourceRegister2 = sourceRegister2;
    this.value = null;
    this.registerShift = null;
  }

  public AddInstruction(Register destinationRegister,
      Register sourceRegister,
      Register sourceRegister2,
      String registerShift) {

    this.destinationRegister = destinationRegister;
    this.sourceRegister = sourceRegister;
    this.sourceRegister2 = sourceRegister2;
    this.registerShift = registerShift;
    this.value = null;
  }

  @Override
  public String generateCode() {
    if (sourceRegister2 == null) {

      return "ADD " + destinationRegister + ", " + sourceRegister + ", #" + value;

    } else if (registerShift == null) {

      return "ADD " + destinationRegister + ", " + sourceRegister + ", " + sourceRegister2;

    } else {

      return "ADD " + destinationRegister + ", " + sourceRegister + ", " + sourceRegister2 + ", " + registerShift;
    }
  }
}
