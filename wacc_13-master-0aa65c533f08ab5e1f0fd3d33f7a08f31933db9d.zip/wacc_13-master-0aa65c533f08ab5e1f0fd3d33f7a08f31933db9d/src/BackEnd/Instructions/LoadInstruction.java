package BackEnd.Instructions;

import BackEnd.Register;
import BackEnd.Registers.Sizes;

public class LoadInstruction implements Instruction {

  private Sizes size;
  private Register destinationRegister;
  private Register sourceRegister;
  private Register sourceRegister2;
  private boolean isPreIndexAddressing;
  private String value;
  private String registerOffset;
  private AddressType addressType;
  private Boolean isValue;

  public Boolean getValue() {
    return isValue;
  }

  public Register getDestinationRegister() {
    return destinationRegister;
  }

  public Register getSourceRegister() {
    return sourceRegister;
  }

  public String getRegisterOffset() {
    if (registerOffset != null) {
      return registerOffset;
    } else {
      return "";
    }
  }

  public AddressType getAddressType() {
    return addressType;
  }

  public LoadInstruction(Sizes size, Register destinationRegister, String value) {

    this.size = size;
    this.destinationRegister = destinationRegister;
    this.value = value;
    this.sourceRegister = null;
    this.sourceRegister2 = null;
    this.isPreIndexAddressing = false;
    this.registerOffset = null;
    addressType = AddressType.VALUE;

  }

  public LoadInstruction(Sizes size, Register destinationRegister, Register sourceRegister) {

    this.size = size;
    this.destinationRegister = destinationRegister;
    this.sourceRegister = sourceRegister;
    this.sourceRegister2 = null;
    this.isPreIndexAddressing = false;
    this.value = null;
    this.registerOffset = null;

    addressType = AddressType.REGISTER;

  }

  public LoadInstruction(Sizes size, Register destinationRegister, Register sourceRegister, String registerOffset,
      boolean isPreIndexAddressing,
      boolean isDualUpdating) {

    this.size = size;
    this.destinationRegister = destinationRegister;
    this.sourceRegister = sourceRegister;
    this.sourceRegister2 = null;
    this.isPreIndexAddressing = isPreIndexAddressing;
    this.registerOffset = registerOffset;
    this.value = null;

    if (isDualUpdating) {
      addressType = AddressType.IMMEDIATE_OFFSET_DUAL_UPDATING;
    } else {
      addressType = AddressType.IMMEDIATE_OFFSET;
    }

  }


  public LoadInstruction(Register dest, Register src) {
    this.destinationRegister = dest;
    this.sourceRegister = src;
    this.isValue = true;
  }

  public LoadInstruction(Register dest, String value) {
    this.destinationRegister = dest;
    this.value = value;
  }

  @Override
  public String generateCode() {

    if (size == null){
      if (value == null) {
        return "LDR " + destinationRegister + ", " + "[" + sourceRegister + "]";
      }
      return "LDR " + destinationRegister + ", =" + value;
    }

    String dataType;
    if (size == Sizes.W) {
      dataType = "";
    } else {
      dataType = size.toString();
    }

    switch (addressType) {

      case VALUE:
        return "LDR" + dataType + " "
            + destinationRegister + ", =" + value;

      case REGISTER:
        return "LDR" + dataType + " "
            + destinationRegister + ", " + "[" + sourceRegister + "]";

      case IMMEDIATE_OFFSET:

        if (isPreIndexAddressing) {

          return "LDR" + dataType
              + " " + destinationRegister + ", " + "["
              + sourceRegister + ", #" + registerOffset + "]";

        } else {

          return "LDR" + dataType
              + " " + destinationRegister + ", " + "["
              + sourceRegister + "], " + registerOffset;

        }

      case IMMEDIATE_OFFSET_DUAL_UPDATING:

        return "LDR" + dataType
            + " " + destinationRegister + ", " + "["
            + sourceRegister + ", #" + registerOffset + "]!";

      case REGISTER_OFFSET:

        if (isPreIndexAddressing) {

          return "LDR" + dataType
              + " " + destinationRegister + ", " + "["
              + sourceRegister + ", " + sourceRegister2 + "]";

        } else {

          return "LDR" + dataType
              + " " + destinationRegister + ", " + "["
              + sourceRegister + "], [" + sourceRegister2 + "]";

        }

      case REGISTER_OFFSET_DUAL_UPDATING:

        return "LDR" + dataType
            + " " + destinationRegister + ", " + "["
            + sourceRegister + ", " + sourceRegister2 + "]!";

      case REGISTER_SHIFTED_OFFSET:

        if (isPreIndexAddressing) {

          return "LDR" + dataType
              + " " + destinationRegister + ", " + "["
              + sourceRegister + ", " + sourceRegister2 + ", "
              + registerOffset + "]";

        } else {

          return "LDR" + dataType
              + " " + destinationRegister + ", " + "["
              + sourceRegister + "], " + sourceRegister2 + ", "
              + registerOffset;

        }

      case REGISTER_SHIFTED_OFFSET_DUAL_UPDATING:

        return "LDR" + dataType
            + " " + destinationRegister + ", " + "["
            + sourceRegister + ", " + sourceRegister2 + ", "
            + registerOffset + "]!";

      default:
        return null;
    }
  }
}
