package BackEnd.Instructions;


import BackEnd.Register;

public class LoadNEInstruction implements Instruction {

  private Register dest;
  private String srcChar;
  private Boolean isLabel;


  public LoadNEInstruction(Register dest, String srcChar, Boolean isLabel) {
    this.dest = dest;
    this.srcChar = srcChar;
    this.isLabel = isLabel;
  }

  public Register getDest() {
    return dest;
  }

  @Override
  public String generateCode() {
      if (isLabel){
        return "LDRNE " + dest.getName() + ", =" + srcChar;
      }
      return "LDRNE " + dest.getName() + ", #" + srcChar;
  }
}
