package BackEnd.Instructions;

import BackEnd.Register;

public class LoadEQInstruction implements Instruction {

  private Register dest;
  private String srcChar;
  private Boolean isLabel;


  public LoadEQInstruction(Register dest, String srcChar, Boolean isLabel) {
    this.dest = dest;
    this.srcChar = srcChar;
    this.isLabel = isLabel;
  }

  public Register getDest() {
    return dest;
  }

  @Override
  public String generateCode() {

      if (isLabel){
        return "LDREQ " + dest.getName() + ", =" + srcChar;
      }
      return "LDREQ " + dest.getName() + ", #" + srcChar;
    }
}
