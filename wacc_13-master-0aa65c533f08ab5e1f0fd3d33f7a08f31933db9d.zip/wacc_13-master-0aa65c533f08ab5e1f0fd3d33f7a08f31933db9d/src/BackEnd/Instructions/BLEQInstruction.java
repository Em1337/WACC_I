package BackEnd.Instructions;

public class BLEQInstruction implements Instruction {

  private String label;

  public BLEQInstruction(String label) {
    this.label = label;
  }

  @Override
  public String generateCode() {
    return "BLEQ " + label;
  }
}
