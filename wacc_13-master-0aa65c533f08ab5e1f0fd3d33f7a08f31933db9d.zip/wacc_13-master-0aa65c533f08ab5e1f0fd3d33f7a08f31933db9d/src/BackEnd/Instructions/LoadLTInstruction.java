package BackEnd.Instructions;

import BackEnd.Register;

public class LoadLTInstruction implements Instruction{
  private Register dest;
  private String srcChar;
  private Boolean isLabel;


  public LoadLTInstruction(Register dest, String srcChar, Boolean isLabel) {
    this.dest = dest;
    this.srcChar = srcChar;
    this.isLabel = isLabel;
  }


  public Register getDest() {
    return dest;
  }

  @Override
  public String generateCode() {
      if (isLabel){
        return "LDRLT " + dest.getName() + ", =" + srcChar;
      }
      return "LDRLT " + dest.getName() + ", #" + srcChar;
  }
}
