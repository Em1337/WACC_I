package BackEnd.Instructions;

public class BLInstruction implements Instruction {

  private String label;

  public BLInstruction(String label) {
    this.label = label;
  }

  @Override
  public String generateCode() {
    return "BL " + label;
  }
}
