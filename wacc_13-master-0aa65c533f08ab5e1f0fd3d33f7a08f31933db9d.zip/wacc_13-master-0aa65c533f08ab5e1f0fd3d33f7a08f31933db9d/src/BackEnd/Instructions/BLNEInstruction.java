package BackEnd.Instructions;

public class BLNEInstruction implements Instruction {

  private String label;

  public BLNEInstruction(String label) {
    this.label = label;
  }

  @Override
  public String generateCode() {
    return "BLNE " + label;
  }

}
