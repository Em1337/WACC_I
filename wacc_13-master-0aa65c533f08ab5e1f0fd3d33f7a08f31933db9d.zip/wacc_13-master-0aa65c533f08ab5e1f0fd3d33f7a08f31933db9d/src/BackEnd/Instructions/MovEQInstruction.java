package BackEnd.Instructions;


import BackEnd.Register;

public class MovEQInstruction implements Instruction {
  private Register dest;
  private String srcChar;

  public MovEQInstruction(Register dest, String srcChar){
    this.dest = dest;
    this.srcChar = srcChar;
  }


  public Register getDest() {
    return dest;
  }

  @Override
  public String generateCode() {
      return "MOVEQ " + dest.getName() + ", #" + srcChar;
  }

}
