package BackEnd.Instructions;

import BackEnd.Register;

public class SubsInstruction implements Instruction {

  private Register destinationRegister;
  private Register sourceRegister;
  private Register sourceRegister2;

  public SubsInstruction(Register destinationRegister,
      Register sourceRegister,
      Register sourceRegister2) {

    this.destinationRegister = destinationRegister;
    this.sourceRegister = sourceRegister;
    this.sourceRegister2 = sourceRegister2;
  }

  @Override
  public String generateCode() {

      return "SUBS "
          + destinationRegister.getName() + ", " + sourceRegister.getName() + ", "
          + sourceRegister2.getName();
  }

}
