package BackEnd.Instructions;


public class InsideLabel implements Instruction {

  private String Dname;

  public InsideLabel(String Dname){
    this.Dname = Dname;
  }

  public String generateCode(){

      return "." + Dname;
  }

}

