package BackEnd.Instructions;

import BackEnd.Register;

public class PushInstruction implements Instruction{

  private Register src;

  public PushInstruction(Register src) {
    this.src = src;
  }

  public Register getSrc() {
    return src;
  }

  @Override
  public String generateCode() {
    return "PUSH {" + src.getName() + "}";
  }
}
