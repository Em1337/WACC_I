package BackEnd.Instructions;

import BackEnd.Register;

public class AndInstruction implements Instruction {
  private Register dest;
  private Register src;
  private Register src2;

  public AndInstruction(Register dest,
      Register src,
      Register src2) {

    this.dest = dest;
    this.src = src;
    this.src2 = src2;
  }

  @Override
  public String generateCode() {
      return "AND " + dest + ", " + src + ", " + src2;
  }
}
