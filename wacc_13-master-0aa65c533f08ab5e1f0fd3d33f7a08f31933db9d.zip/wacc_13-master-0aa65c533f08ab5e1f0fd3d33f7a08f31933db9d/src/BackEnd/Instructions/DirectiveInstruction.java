package BackEnd.Instructions;

public class DirectiveInstruction implements Instruction {

  private String Dname;
  private String name;

  public DirectiveInstruction(String Dname){
    this.Dname = Dname;
  }

  public DirectiveInstruction(String Dname, String name){
    this.Dname = Dname;
    this.name  = name;
  }
  public String generateCode(){
    if (Dname == null) {
      return "." + name;
    }
    if (name == null) {
      return "." + Dname;
    }
    return "." + Dname + " " + name;
  }

}
