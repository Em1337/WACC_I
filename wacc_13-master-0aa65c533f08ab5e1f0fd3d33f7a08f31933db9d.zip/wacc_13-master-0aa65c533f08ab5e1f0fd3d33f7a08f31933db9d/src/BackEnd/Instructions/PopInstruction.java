package BackEnd.Instructions;

import BackEnd.Register;

public class PopInstruction implements Instruction {

  private Register src;

  public PopInstruction(Register src) {
    this.src = src;
  }

  public Register getSrc() {
    return src;
  }

  @Override
  public String generateCode() {
    return "POP {" + src.getName() + "}";
  }
}
