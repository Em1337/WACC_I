package BackEnd.Instructions;


import BackEnd.Register;

public class CmpInstruction implements Instruction {

  private Register src;
  private String value;
  private Register src2;
  private String shift;

  public CmpInstruction(Register src, String value) {

    this.src = src;
    this.value = value;
    this.src2 = null;
    this.shift = null;
  }

  public CmpInstruction(Register src, Register src2) {

    this.src = src;
    this.src2 = src2;
    this.value = null;
    this.shift = null;
  }

  public CmpInstruction(Register src, Register src2, String shift) {

    this.src = src;
    this.src2 = src2;
    this.shift = shift;
    this.value = null;
  }

  @Override
  public String generateCode() {
    if (src2 == null) {

      return "CMP " + src
          + ", #" + value;

    } else if (shift == null) {

      return "CMP " + src
          + ", " + src2;

    } else {

      return "CMP " + src
          + ", " + src2 + ", " + shift;
    }
  }
}
