package BackEnd.Instructions;


public class BInstruction implements Instruction {
  private String label;

  public BInstruction(String label) {
    this.label = label;
  }

  @Override
  public String generateCode() {
    return "B " + label;
  }
}
