package BackEnd.Instructions;

import BackEnd.Register;

public class MulInstruction implements Instruction {

  private Register destinationRegisterMSB;
  private Register destinationRegisterLSB;
  private Register sourceRegister1;
  private Register sourceRegister2;

  public MulInstruction(Register destinationRegisterMSB,
      Register destinationRegisterLSB,
      Register sourceRegister1,
      Register sourceRegister2) {
    this.destinationRegisterMSB = destinationRegisterMSB;
    this.destinationRegisterLSB = destinationRegisterLSB;
    this.sourceRegister1 = sourceRegister1;
    this.sourceRegister2 = sourceRegister2;
  }

  @Override
  public String generateCode() {

    return "SMULL " + destinationRegisterMSB
        + ", " + destinationRegisterLSB + ", " + sourceRegister1 + ", "
        + sourceRegister2;
  }
}
