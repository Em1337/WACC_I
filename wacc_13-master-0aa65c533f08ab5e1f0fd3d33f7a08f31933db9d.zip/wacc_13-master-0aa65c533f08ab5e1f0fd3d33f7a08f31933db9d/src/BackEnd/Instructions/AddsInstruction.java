package BackEnd.Instructions;

import BackEnd.Register;

public class AddsInstruction implements Instruction {


  private Register destinationRegister;
  private Register sourceRegister;
  private Register sourceRegister2;


  public AddsInstruction(Register destinationRegister,
      Register sourceRegister,
      Register sourceRegister2) {

    this.destinationRegister = destinationRegister;
    this.sourceRegister = sourceRegister;
    this.sourceRegister2 = sourceRegister2;
  }


  @Override
  public String generateCode() {

      return "ADDS " + destinationRegister + ", " + sourceRegister + ", " + sourceRegister2;

  }

}
