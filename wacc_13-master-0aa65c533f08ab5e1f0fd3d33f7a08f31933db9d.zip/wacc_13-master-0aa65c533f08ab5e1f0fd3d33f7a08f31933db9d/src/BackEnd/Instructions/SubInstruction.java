package BackEnd.Instructions;

import BackEnd.Register;

public class SubInstruction implements Instruction {

  private Register destinationRegister;
  private Register sourceRegister;
  private String value;

  public SubInstruction(Register destinationRegister,
      Register sourceRegister,
      String value) {
    this.destinationRegister = destinationRegister;
    this.sourceRegister = sourceRegister;
    this.value = value;
  }

  @Override
  public String generateCode() {

      return "SUB "
          + destinationRegister.getName() + ", " + sourceRegister.getName() + ", #" + value;
  }
}
