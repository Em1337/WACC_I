package BackEnd;

import BackEnd.Instructions.*;
import BackEnd.Registers.Sizes;
import FrontEnd.SymbolTable.Symbol;
import FrontEnd.SymbolTable.SymbolTable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

public class Program {

  private static final int MAX_INT_BYTE = 1024;

  private Registers registers = new Registers();
  private List<Instruction> instructions = new ArrayList<>();
  private List<Instruction> labelInstructions = new ArrayList<>();
  private List<Instruction> pLabels = new ArrayList<>();
  private List<MessageLabel> messageLabels = new ArrayList<>();
  private Map<String, List<Instruction>> fInstructions = new LinkedHashMap<>();
  private Map<String, List<Instruction>> printFInstructions = new LinkedHashMap<>();
  private List<String> pFnames = new ArrayList<>();
  List<String> fNames = new ArrayList<>();
  private Stack<String> currentFunctionLevel = new Stack<>();
  SymbolTable symbolTable;
  Stack<Register> usedRegisters = new Stack<>();
  private Set<Symbol> alreadyFreed = new HashSet<>();
  private int temporaryScopeOffset;
  private boolean isBeingFreed;

  Registers getRegisters() {
    return registers;
  }

  public Map<String, List<Instruction>> getfInstructions() {
    return fInstructions;
  }

  public List<Instruction> getMainInstructions(){
    return instructions;
  }

  void setSymbolTable(SymbolTable symbolTable) {
    this.symbolTable = symbolTable;
  }

  void addInstructions(Instruction instruction) {
    if (currentFunctionLevel.empty()) {
      instructions.add(instruction);
    } else {
      fInstructions.get(currentFunctionLevel.peek()).add(instruction);
    }

  }

  private void addPrintInstructions(Instruction instruction) {
    printFInstructions.get(currentFunctionLevel.peek()).add(instruction);
  }

  private void addInstructions(String function, Instruction instruction) {
    fInstructions.get(function).add(instruction);
  }

  void beginFunction(String function) {
    addLabel(new LabelInstruction(function));
    fNames.add(function);
    currentFunctionLevel.push(function);
    fInstructions.put(function, new ArrayList<>());
    addInstructions(function, new PushInstruction(registers.getRegister("lr")));
  }

  void endFunction(String function) {
    addInstructions(function, new PopInstruction(registers.getRegister("pc")));
    addInstructions(new InsideLabel("ltorg"));
    currentFunctionLevel.pop();
  }

  private void endPFunction() {
    addPrintInstructions(new PopInstruction(registers.getRegister("pc")));
    currentFunctionLevel.pop();
  }

  public List<Instruction> getInstructions() {
    List<Instruction> programInstructions = new ArrayList<>();
    programInstructions.add(instructions.get(0));
    instructions.remove(0);
    programInstructions.addAll(messageLabels);
    programInstructions.addAll(instructions);

    for (int i = fNames.size() - 1; 0 <= i; i--) {
      programInstructions.add(labelInstructions.get(i));
      programInstructions.addAll(fInstructions.get(fNames.get(i)));
    }

    for (int i = pFnames.size() - 1; 0 <= i; i--) {
      programInstructions.add(pLabels.get(i));
      programInstructions.addAll(printFInstructions.get(pFnames.get(i)));
    }

    return programInstructions;
  }

  List<Instruction> initializeScopeOffset(int totalOffset) {
    List<Instruction> instructions = new ArrayList<>();

    while (totalOffset > 0) {
      String totalOffsetRepresentation;
      if (totalOffset >= MAX_INT_BYTE) {
        totalOffsetRepresentation = String.valueOf(MAX_INT_BYTE);
      } else {
        totalOffsetRepresentation = String.valueOf(totalOffset);
      }

      SubInstruction stackSubtraction = new SubInstruction(registers.getRegister("sp"),
          registers.getRegister("sp"),
          totalOffsetRepresentation);
      instructions.add(stackSubtraction);

      totalOffset = totalOffset - MAX_INT_BYTE;
    }

    return instructions;
  }

  List<Instruction> returnScopeOffset(int totalOffset) {
    List<Instruction> instructions = new ArrayList<>();

    while (totalOffset > 0) {
      String totalOffsetRepresentation;
      if (totalOffset >= MAX_INT_BYTE) {
        totalOffsetRepresentation = String.valueOf(MAX_INT_BYTE);
      } else {
        totalOffsetRepresentation = String.valueOf(totalOffset);
      }

      AddInstruction stackAddition = new AddInstruction(
          registers.getRegister("sp"),
          registers.getRegister("sp"), totalOffsetRepresentation);
      instructions.add(stackAddition);

      totalOffset = totalOffset - MAX_INT_BYTE;
    }

    return instructions;
  }

  private void addLabel(Instruction labelInstruction) {
    labelInstructions.add(labelInstruction);
  }

  void moveIntoNextScope() {
    symbolTable = symbolTable.getNextSymbolTable();
  }

  int addToTemporaryOffset(int value) {
    temporaryScopeOffset += value;
    return temporaryScopeOffset;
  }

  void resetTemporaryOffset() {
    temporaryScopeOffset = 0;
  }

  int getTemporaryScopeOffset() {
    return temporaryScopeOffset;
  }

  void printString() {
    String stringLabel = MessageLabelGenerator("%.*s\\0");
    beginPFunction("Print_String");
    Register r1 = registers.getRegister("r1");
    Register r0 = registers.getRegister("r0");
    Register r2 = registers.getRegister("r2");
    addPrintInstructions(new LoadInstruction(r1, r0));
    addPrintInstructions(new AddInstruction(r2, r0, "4"));
    addPrintInstructions(new LoadInstruction(r0, stringLabel));
    addPrintInstructions(new AddInstruction(r0, r0, "4"));
    addPrintInstructions(new BLInstruction("printf"));
    addPrintInstructions(new MovInstruction(r0, 0));
    addPrintInstructions(new BLInstruction("fflush"));
    endPFunction();
  }

  void printBool() {
    String trueCase = MessageLabelGenerator("true\\0");
    String falseCase = MessageLabelGenerator("false\\0");
    beginPFunction("Print_Bool");
    Register r0 = registers.getRegister("r0");
    addPrintInstructions(new CmpInstruction(r0, "0"));
    addPrintInstructions(new LoadNEInstruction(r0, trueCase, true));
    addPrintInstructions(new LoadEQInstruction(r0, falseCase, true));
    addPrintInstructions(new AddInstruction(r0, r0, "4"));
    addPrintInstructions(new BLInstruction("printf"));
    addPrintInstructions(new MovInstruction(r0, 0));
    addPrintInstructions(new BLInstruction("fflush"));
    endPFunction();
  }

  void printLn() {
    String lncase = MessageLabelGenerator("\\0");
    beginPFunction("Print_Ln");
    Register r0 = registers.getRegister("r0");
    addPrintInstructions(new LoadInstruction(r0, lncase));
    addPrintInstructions(new AddInstruction(r0, r0, "4"));
    addPrintInstructions(new BLInstruction("puts"));
    addPrintInstructions(new MovInstruction(r0, 0));
    addPrintInstructions(new BLInstruction("fflush"));
    endPFunction();
  }

  void printInt() {
    String intLabel = MessageLabelGenerator("%d\\0");
    beginPFunction("Print_Int");
    Register r1 = registers.getRegister("r1");
    Register r0 = registers.getRegister("r0");
    addPrintInstructions((new MovInstruction(r1, r0)));
    addPrintInstructions(new LoadInstruction(r0, intLabel));
    addPrintInstructions(new AddInstruction(r0, r0, "4"));
    addPrintInstructions(new BLInstruction("printf"));
    addPrintInstructions(new MovInstruction(r0, 0));
    addPrintInstructions(new BLInstruction("fflush"));
    endPFunction();
  }

  void printRef() {
    String refLabel = MessageLabelGenerator("%p\\0");
    beginPFunction("Print_Ref");
    Register r1 = registers.getRegister("r1");
    Register r0 = registers.getRegister("r0");
    addPrintInstructions((new MovInstruction(r1, r0)));
    addPrintInstructions(new LoadInstruction(r0, refLabel));
    addPrintInstructions(new AddInstruction(r0, r0, "4"));
    addPrintInstructions(new BLInstruction("printf"));
    addPrintInstructions(new MovInstruction(r0, 0));
    addPrintInstructions(new BLInstruction("fflush"));
    endPFunction();
  }

  void readInt() {
    String readIntLabel = MessageLabelGenerator("%d\\0");
    Register register0 = registers.getRegister("r0");
    beginPFunction("Read_Int");
    addPrintInstructions(new MovInstruction(registers.getRegister("r1"), register0));
    // Load message in r0 (different if char or int)
    addPrintInstructions(new LoadInstruction(Sizes.W, register0, readIntLabel));
    // Increment r0
    addPrintInstructions(new AddInstruction(register0, register0, "4"));
    // Call function scanf
    addPrintInstructions(new BLInstruction("scanf"));
    // Pop program counter (pc)
    endPFunction();
  }

  void readChar() {
    String readIntLabel = MessageLabelGenerator(" %c\\0");
    Register register0 = registers.getRegister("r0");
    beginPFunction("Read_Char");
    addPrintInstructions(new MovInstruction(registers.getRegister("r1"), register0));
    // Load message in r0 (different if char or int)
    addPrintInstructions(new LoadInstruction(Sizes.W, register0, readIntLabel));
    // Increment r0
    addPrintInstructions(new AddInstruction(register0, register0, "4"));
    // Call function scanf
    addPrintInstructions(new BLInstruction("scanf"));
    // Pop program counter (pc)
    endPFunction();
  }

  void freePair() {
    String errorMessageLabel = MessageLabelGenerator(
        "NullReferenceError: dereference a null reference\\n\\0");
    Register register0 = registers.getRegister("r0");
    beginPFunction("free_pair");
    addPrintInstructions(new CmpInstruction(register0, "0"));
    addPrintInstructions(new LoadEQInstruction(register0, errorMessageLabel, true));
    addPrintInstructions(new BEQInstruction("p_Runtime_Error"));
    if (!functionAlreadyDefined("Runtime_Error")) {
      addRuntimeError();
    }
    addPrintInstructions(new PushInstruction(register0));
    addPrintInstructions(new LoadInstruction(register0, register0));
    addPrintInstructions(new BLInstruction("free"));
    addPrintInstructions(new LoadInstruction(register0, registers.getRegister("sp")));
    addPrintInstructions(new LoadInstruction(Sizes.W, register0, register0, "4", true, false));
    addPrintInstructions(new BLInstruction("free"));
    addPrintInstructions(new PopInstruction(register0));
    addPrintInstructions(new BLInstruction("free"));
    endPFunction();
  }

  Boolean functionAlreadyDefined(String fName) {
    for (String pFname : pFnames) {
      if (fName.equals(pFname)) {
        return true;
      }
    }
    return false;
  }

  private void beginPFunction(String function) {
    pLabels.add(new PrintLabel(function));
    pFnames.add(function);
    currentFunctionLevel.push(function);
    printFInstructions.put(function, new ArrayList<>());
    addPrintInstructions(new PushInstruction(registers.getRegister("lr")));
  }

  String MessageLabelGenerator(String message) {
    if (messageLabels.size() == 0) {
      instructions.add(0, new DirectiveInstruction("data"));
    }
    for (MessageLabel messageLabel : messageLabels) {
      if (messageLabel.getIdent().equals(message)) {
        return messageLabel.getIdent();
      }
    }
    MessageLabel label = new MessageLabel(message, messageLabels.size());
    messageLabels.add(label);
    return label.getIdent();
  }

  void addRuntimeError() {
    beginPFunction("Runtime_Error");
    Register r0 = registers.getRegister("r0");
    addPrintInstructions(new BLInstruction("p_Print_String"));
    if (!functionAlreadyDefined("Print_String")) {
      printString();
    }
    addPrintInstructions(new MovInstruction(r0, -1));
    addPrintInstructions(new BLInstruction("exit"));
    endPFunction();
  }

  void addOverflowFunc() {
    String overflowLabel = MessageLabelGenerator(
        "OverflowError: the result is too small/large to store in a 4-byte signed-integer.\\n");
    addLabel(new LabelInstruction("Overflow"));
    fNames.add("Overflow");
    currentFunctionLevel.push("Overflow");
    fInstructions.put("Overflow", new ArrayList<>());
    Register r0 = registers.getRegister("r0");
    addInstructions(new LoadInstruction(r0, overflowLabel));
    addInstructions(new BLInstruction("p_Runtime_Error"));
    if (!functionAlreadyDefined("Runtime_Error")) {
      addRuntimeError();
    }
    currentFunctionLevel.pop();
  }

  void divideByZero() {
    String divideZeroLabel = MessageLabelGenerator(
        "DivideByZeroError: divide or modulo by zero\\n\\0");
    beginPFunction("Divide_By_Zero");
    Register r0 = registers.getRegister("r0");
    Register r1 = registers.getRegister("r1");
    addPrintInstructions((new CmpInstruction(r1, "0")));
    addPrintInstructions(new LoadEQInstruction(r0, divideZeroLabel, true));
    addPrintInstructions(new BLEQInstruction("p_Runtime_Error"));
    if (!functionAlreadyDefined("Runtime_Error")) {
      addRuntimeError();
    }
    endPFunction();
  }



  void setMemoryAddressBeingFreed(boolean b) {
    isBeingFreed = b;
  }

  boolean isMemoryAddressBeingFreed() {
    return isBeingFreed;
  }

  boolean hasAlreadyBeenFreed(String ident) {
    return alreadyFreed.contains(Symbol.symbol(ident));
  }

  void setToALreadyFreed(String ident) {
    alreadyFreed.add(Symbol.symbol(ident));
  }

  void arrayOutBounds() {
    String arrayBoundNegative = MessageLabelGenerator("ArrayIndexOutOfBoundsError: negative index\\n\\0");
    String arrayBoundTooBig = MessageLabelGenerator("ArrayIndexOutOfBoundsError: index too big\\n\\0");
    beginPFunction("Array_Out_Bounds");
    addPrintInstructions(new CmpInstruction(registers.getRegister("r0"), "0"));
    addPrintInstructions(new LoadLTInstruction(registers.getRegister("r0"), arrayBoundNegative, true));
    addPrintInstructions(new BLLTInstruction("p_Runtime_Error"));
    addPrintInstructions(new LoadInstruction(registers.getRegister("r1"), registers.getRegister("r1")));
    addPrintInstructions(new CmpInstruction(registers.getRegister("r0"), registers.getRegister("r1")));
    addPrintInstructions(new LoadCSInstruction(registers.getRegister("r0"), arrayBoundTooBig, true));
    addPrintInstructions(new BLCSInstruction("p_Runtime_Error"));
    if(!functionAlreadyDefined("Runtime_Error")) {
      addRuntimeError();
    }
    endPFunction();
  }
}

