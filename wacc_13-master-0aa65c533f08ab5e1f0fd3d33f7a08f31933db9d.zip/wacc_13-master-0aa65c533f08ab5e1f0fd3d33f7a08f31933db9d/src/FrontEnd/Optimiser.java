package FrontEnd;

import BackEnd.Instructions.AddressType;
import BackEnd.Instructions.Instruction;
import BackEnd.Instructions.LoadInstruction;
import BackEnd.Instructions.PopInstruction;
import BackEnd.Instructions.StoreInstruction;
import BackEnd.Program;
import BackEnd.Register;
import java.util.List;
import java.util.Map;

public class Optimiser {

  private List<Instruction> mainInstructions;
  private Map<String, List<Instruction>> fInstructions;

  public Optimiser(Program thisProgram) {
    Program program = thisProgram;
    this.mainInstructions = program.getMainInstructions();
    this.fInstructions = program.getfInstructions();
  }

  public void optimiseMainInstructions(){
    for (int i = 0; i < mainInstructions.size() - 1; i++){
      Instruction current = mainInstructions.get(i);
      Instruction next = mainInstructions.get(i + 1);

      if (current instanceof StoreInstruction && next instanceof LoadInstruction){
        StoreInstruction store = (StoreInstruction) current;
        LoadInstruction load = (LoadInstruction) next;
        if (load.getDestinationRegister() == store.getSrc() && load.getSourceRegister() == store.getDest() && load.getRegisterOffset().equals(store.getOffset())){
          System.out.println("Main Optimisation");
          mainInstructions.remove(next);
        }
      }
      if (current instanceof LoadInstruction && next instanceof LoadInstruction){
        LoadInstruction load = (LoadInstruction) current;
        LoadInstruction repeatedLoad = (LoadInstruction) next;
        if (load.getSourceRegister() == repeatedLoad.getSourceRegister() && load.getDestinationRegister() == repeatedLoad.getDestinationRegister()){
          if (load.getRegisterOffset().equals("") && repeatedLoad.getRegisterOffset().equals("")){
            System.out.println("Main Optimisation");
            mainInstructions.remove(next);
          }
          else if(load.getRegisterOffset().equals(repeatedLoad.getRegisterOffset())){
            System.out.println("Main Optimisation");
            mainInstructions.remove(next);
          }
        }
      }

      if (current instanceof StoreInstruction && next instanceof LoadInstruction){
        StoreInstruction store = (StoreInstruction) current;
        LoadInstruction load = (LoadInstruction) next;
        if (load.getSourceRegister() == store.getSrc() && load.getDestinationRegister() == store.getDest()){
          if (load.getRegisterOffset().equals("") && store.getOffset().equals("")){
            System.out.println("Main Optimisation");
            mainInstructions.remove(next);
          }
          else if(load.getRegisterOffset().equals(store.getOffset())){
            System.out.println("Main Optimisation");
            mainInstructions.remove(next);
          }
        }
      }

      if (current instanceof PopInstruction && next instanceof PopInstruction){
        PopInstruction firstPop = (PopInstruction) current;
        PopInstruction secondPop = (PopInstruction) next;
        if (firstPop.getSrc().getName().equals("sp") && secondPop.getSrc().getName().equals("sp")){
          mainInstructions.remove(next);
        }
      }
    }
  }

  public void optimiseFunctionInstructions(){
    for (Map.Entry<String, List<Instruction>> entry : fInstructions.entrySet()) {
      List<Instruction> instructions = entry.getValue();
      for (int i = 0; i < instructions.size() - 1; i++){
        Instruction current = instructions.get(i);
        Instruction next = instructions.get(i + 1);

        if (current instanceof StoreInstruction && next instanceof LoadInstruction){
          StoreInstruction store = (StoreInstruction) current;
          LoadInstruction load = (LoadInstruction) next;
          if (load.getDestinationRegister() == store.getSrc() && load.getSourceRegister() == store.getDest() && load.getRegisterOffset().equals(store.getOffset())){
            System.out.println("Function Optimisation");
            instructions.remove(next);
          }
        }

        if (current instanceof LoadInstruction && next instanceof LoadInstruction){
          LoadInstruction load = (LoadInstruction) current;
          LoadInstruction repeatedLoad = (LoadInstruction) next;
          if (load.getSourceRegister() == repeatedLoad.getSourceRegister() && load.getDestinationRegister() == repeatedLoad.getDestinationRegister()){
            if (load.getRegisterOffset().equals("") && repeatedLoad.getRegisterOffset().equals("") && !load.getAddressType().equals(
                AddressType.REGISTER)){
              System.out.println("no offset");
              System.out.println("Function Optimisation");
              instructions.remove(next);
            }
            else if((load.getRegisterOffset().equals(repeatedLoad.getRegisterOffset())&& !load.getAddressType().equals(
                AddressType.REGISTER))){
              System.out.println("offset");
              System.out.println("Function Optimisation");
              instructions.remove(next);
            }
          }
        }

        if (current instanceof StoreInstruction && next instanceof LoadInstruction){
          StoreInstruction store = (StoreInstruction) current;
          LoadInstruction load = (LoadInstruction) next;
          if (load.getSourceRegister() == store.getSrc() && load.getDestinationRegister() == store.getDest()){
            if (load.getRegisterOffset().equals("") && store.getOffset().equals("")){
              instructions.remove(next);
            }
            else if(load.getRegisterOffset().equals(store.getOffset())){
              instructions.remove(next);
            }
          }
        }

        if (current instanceof PopInstruction && next instanceof PopInstruction){
          PopInstruction firstPop = (PopInstruction) current;
          PopInstruction secondPop = (PopInstruction) next;
          if (firstPop.getSrc().getName().equals("sp") && secondPop.getSrc().getName().equals("sp")){
            instructions.remove(next);
          }
        }

      }
    }
  }

}
