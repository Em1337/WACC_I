package FrontEnd;

import FrontEnd.Types.Type;
import java.util.Collections;
import java.util.List;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.TerminalNode;


public class ErrorHandler extends BaseErrorListener {
  static final int INT_MAX = (int) (Math.pow(2, 31) - 1);
  static final int INT_MIN = (int) -Math.pow(2, 31);
  private static final int SemnanticExit = 200;
  private static final int SyntaxExit = 100;


  @Override
  public void syntaxError(Recognizer<?, ?> recognizer, Object offendingSymbol, int line, int charPositionInLine, String msg, RecognitionException e) {
    List<String> stack = ((Parser)recognizer).getRuleInvocationStack();
    Collections.reverse(stack);
    System.err.println("Error in " + stack.get(stack.size() - 1));
    System.err.println(msg + " at line " + line + " at postion " + charPositionInLine);
    System.exit(SyntaxExit);
   }

  private int getPosition(ParseTree ctx){
    int position = 0;
    if (ctx instanceof TerminalNode) {
      position = ((TerminalNode) ctx).getSymbol().getStartIndex();
    }else if (ctx instanceof ParserRuleContext){
      position = ((ParserRuleContext) ctx).getStart().getStartIndex();
    }
    return position;
  }

  private int getLine(ParseTree ctx){
    int line = 0;
    if (ctx instanceof TerminalNode) {
      line = ((TerminalNode) ctx).getSymbol().getLine();
    }else if (ctx instanceof ParserRuleContext){
      line = ((ParserRuleContext) ctx).getStart().getLine();
    }
    return line;
  }

  public void divideByZero(ParseTree ctx){
    String errorMessage = "Divide By Zero Error";
    error(ctx, errorMessage, SemnanticExit);
  }

  void functionNoReturnExit(ParseTree fctx ,String fname){
    String errorMessage = "FrontEnd.SymbolTable.Function " + fname + " has one or more execution paths that do not return or exit";
    error(fctx, errorMessage, SyntaxExit);
  }

  void intOverflow(ParseTree intLtrl){
    String overflow = "Integer Overflow Detected Offending FrontEnd.SymbolTable.Symbol: " + intLtrl.getText();
    error(intLtrl, overflow, SyntaxExit);
  }

  void notInScope(ParseTree ctx){
    String errorMessage = ctx.getText() + " has not been defined in current scope";
    error(ctx, errorMessage, SemnanticExit);
  }

  void functionArguments(ParseTree ctx, int expected, int actual){
    String errorMessage = "FrontEnd.SymbolTable.Function " + ctx.getText() + " called with wrong number of arguments Expected: " + expected + " Actual: " + actual;
    error(ctx, errorMessage, SemnanticExit);
  }

  void typeError(ParseTree ctx, String message , Type expected, Type actual){
    String errorMessage = "FrontEnd.Types.Type Match Error " + message + "\nExpected FrontEnd.Types.Type: " + expected + " and Actual FrontEnd.Types.Type: " + actual;
    error(ctx, errorMessage, SemnanticExit);
  }

  void typeOpError(ParseTree ctx, String operator, Type[] firstExpected, Type firstActual, Type secondActual){
    StringBuilder types = new StringBuilder();
    for (int i = 0; i < firstExpected.length; i++){
      if (i == firstExpected.length - 1){
        types.append(firstExpected[i]);
      }else {
        types.append(firstExpected[i]).append(" or ");

      }

    }
    String errorMessage = "FrontEnd.Types.Type Error for input expressions to " + operator + " operator \n" + "Expected Types of Both Expressions: " + types + " and Actual FrontEnd.Types.Type: " +
        firstActual + " and " + secondActual;
    error(ctx, errorMessage, SemnanticExit);
  }

  void typeUnaryOpError(ParseTree ctx, String operator, Type expected, Type actual){
    String errorMessage = "FrontEnd.Types.Type Match Error for input expression to " + operator + "Unary operator \n"+ "Expected FrontEnd.Types.Type of expression: " + expected + " and Actual Types: " +
        actual;
    error(ctx, errorMessage, SemnanticExit);
  }

  void readInput(ParseTree ctx, Type actual){
    String errorMessage = "FrontEnd.Types.Type error of input expression to Read Statement, Input FrontEnd.Types.Type Can only be of FrontEnd.Types.Type INT or Char but Actual FrontEnd.Types.Type: " + actual ;
    error(ctx, errorMessage, SemnanticExit);
  }

  void freeInput(ParseTree ctx, Type actual){
    String errorMessage = "FrontEnd.Types.Type error of input expression to Free Statement, Input FrontEnd.Types.Type Can only be of FrontEnd.Types.Type Array or Pair but Actual FrontEnd.Types.Type: " + actual ;
    error(ctx, errorMessage, SemnanticExit);
  }

  void redefintion(ParseTree ctx){
    String errorMessage = ctx.getText() + " has already been defined in current scope";
    error(ctx, errorMessage, SemnanticExit);
  }

  void returnNotAllowed(ParseTree ctx){
    String errorMessage = "Return Statment in Non - Main FrontEnd.SymbolTable.Function Context not Allowed";
    error(ctx, errorMessage, SemnanticExit);
  }

  private void error(ParseTree ctx, String Message, int exitcode) {
    System.err.println(Message + " at Line No: " + getLine(ctx) + " Position No: " + getPosition(ctx));
    System.exit(exitcode);
  }



}
