package FrontEnd;

import antlr.WaccParserBaseVisitor;
import antlr.WaccParserParser.*;
import java.lang.*;
import java.lang.Boolean;
import org.antlr.v4.runtime.misc.NotNull;

public class SyntaxAnalyser extends WaccParserBaseVisitor<Boolean> {

  private ErrorHandler errorHandler;

  public SyntaxAnalyser(){
    errorHandler = new ErrorHandler();
  }

  @Override
  public Boolean visitProgram(@NotNull ProgramContext ctx) {
    visitChildren(ctx);
    int functionCount = ctx.func().size();
    boolean function = true;
    String fName = "";
    FuncContext fctx = null;
    for (int i = 0; i < functionCount; i++){
      if (!visit(ctx.func(i))){
        function = false;
        fName = ctx.func(i).ident().getText();
        fctx = ctx.func(i);
      }
    }
    if (!function){
      errorHandler.functionNoReturnExit(fctx, fName);
    }
    return function;
  }

  @Override
  public Boolean visitFunc(@NotNull FuncContext ctx) {
    visitChildren(ctx);
    return visit(ctx.stat());
  }

  @Override
  public Boolean visitIfStatement(@NotNull IfStatementContext ctx) {
    visitChildren(ctx);
    return visit(ctx.stat(0)) && visit(ctx.stat(1));
  }

  @Override
  public Boolean visitWhileStatement(@NotNull WhileStatementContext ctx) {
    visitChildren(ctx);
    return visit(ctx.stat());
  }

  @Override
  public Boolean visitBeginStatement(@NotNull BeginStatementContext ctx) {
    visitChildren(ctx);
    return visit(ctx.stat());
  }

  @Override
  public Boolean visitExitStatement(@NotNull ExitStatementContext ctx) {
    return true;
  }

  @Override
  public Boolean visitReturnStatement(@NotNull ReturnStatementContext ctx) {
    return true;
  }

  @Override
  public Boolean visitAssignStatement(@NotNull AssignStatementContext ctx) {
    visitChildren(ctx);
    return false;
  }

  @Override
  public Boolean visitSkipStatement(@NotNull SkipStatementContext ctx) {
    return false;
  }

  @Override
  public Boolean visitDeclareStatement(@NotNull DeclareStatementContext ctx) {
    visitChildren(ctx);
    return false;
  }

  @Override
  public Boolean visitReadStatement(@NotNull ReadStatementContext ctx) {
    visitChildren(ctx);
    return false;
  }

  @Override
  public Boolean visitFreeStatement(@NotNull FreeStatementContext ctx) {
    return false;
  }

  @Override
  public Boolean visitPrintStatement(@NotNull PrintStatementContext ctx) {
    return false;
  }

  @Override
  public Boolean visitPrintlnStatement(@NotNull PrintlnStatementContext ctx) {
    return false;
  }

  @Override
  public Boolean visitSeqComposition(@NotNull SeqCompositionContext ctx) {
    visitChildren(ctx);
    return visit(ctx.stat(1));
  }

  @Override
  public Boolean visitIntltrl(@NotNull IntltrlContext ctx) {
    int integer;
    try {
      integer = Integer.parseInt(ctx.getText());
    }catch (NumberFormatException exception){
      errorHandler.intOverflow(ctx);
      return null;
    }
    if (integer < ErrorHandler.INT_MIN || integer > ErrorHandler.INT_MAX){
      errorHandler.intOverflow(ctx);
    }
    return null;
  }
}
