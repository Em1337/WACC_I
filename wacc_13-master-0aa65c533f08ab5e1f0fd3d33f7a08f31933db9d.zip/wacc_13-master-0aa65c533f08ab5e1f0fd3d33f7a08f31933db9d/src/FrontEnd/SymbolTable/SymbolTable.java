package FrontEnd.SymbolTable;

import FrontEnd.Types.ArrayType;
import FrontEnd.Types.BaseType;
import FrontEnd.Types.PairType;
import FrontEnd.Types.Type;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Collectors;

// FrontEnd.SymbolTable.SymbolTable Class acts as a scope for the program
// holds a Hashmap of Variables and a Hashmap of Functions
// also holds a FrontEnd.SymbolTable.SymbolTable which represents the previous scope
// has functions for getting a variable/function in the current symbol table or
// searching all of the above symbolTables acting as searching the global scope
public class SymbolTable {

  public static final int STACK_SIZE_4 = 4;
  public static final int STACK_SIZE_1 = 1;
  private static final int STACK_SIZE_INT = STACK_SIZE_4;
  private static final int STACK_SIZE_CHAR = STACK_SIZE_1;
  private static final int STACK_SIZE_STRING = STACK_SIZE_4;
  private static final int STACK_SIZE_BOOL = STACK_SIZE_1;
  private static final int STACK_SIZE_ARRAY = STACK_SIZE_4;
  private static final int STACK_SIZE_PAIR = STACK_SIZE_4;
  public static final int PC_OFFSET = 4;

  private LinkedHashMap<Symbol, Variable> variables;
  private LinkedHashMap<Symbol, Function> functions;
  private SymbolTable parentSymbolTable;
  private List<SymbolTable> childrenSymbolTables;
  private int nextChildIndex;
  private int totalOffset;
  private int currentOffset;
  private Set<Symbol> alreadyInitialised;

  public SymbolTable() {
    variables = new LinkedHashMap<>();
    functions = new LinkedHashMap<>();
    alreadyInitialised = new HashSet<>();
    parentSymbolTable = null;
    childrenSymbolTables = new ArrayList<>();
    nextChildIndex = 0;
  }

  public SymbolTable(SymbolTable symbolTable) {
    variables = new LinkedHashMap<>();
    functions = new LinkedHashMap<>();
    alreadyInitialised = new HashSet<>();
    parentSymbolTable = symbolTable;
    childrenSymbolTables = new ArrayList<>();
    nextChildIndex = 0;
  }

  public void addChildSymbolTable(SymbolTable symbolTable) {
    childrenSymbolTables.add(symbolTable);
  }

  public SymbolTable getParentSymbolTable() {
    return parentSymbolTable;
  }

  public Function getFunc(Symbol funcSymbol) {
    return functions.get(funcSymbol);
  }

  public Function addFunc(Symbol funcSymbol, Function func) {
    return functions.put(funcSymbol, func);
  }

  public Function getFirstFunc(Symbol funcSymbol) {

    Function func;

    for (SymbolTable tempTable = this; tempTable != null;
        tempTable = tempTable.getParentSymbolTable()) {
      func = tempTable.getFunc(funcSymbol);
      if (func != null) {
        return func;
      }
    }
    return null;
  }

  public Variable getVar(Symbol varSymbol) {
    return variables.get(varSymbol);
  }

  public Variable addVar(Symbol varSymbol, Variable var) {
    return variables.put(varSymbol, var);
  }

  public Variable getFirstVar(Symbol varSymbol) {

    Variable var;

    for (SymbolTable tempTable = this; tempTable != null;
        tempTable = tempTable.getParentSymbolTable()) {
      var = tempTable.getVar(varSymbol);
      if (var != null) {
        return var;
      }
    }
    return null;
  }


  public SymbolTable getNextSymbolTable() {

    if (childrenSymbolTables.size() == 0 || nextChildIndex == childrenSymbolTables.size()) {

      return parentSymbolTable;
    }

    SymbolTable nextSymbolTable = childrenSymbolTables.get(nextChildIndex);

    nextChildIndex++;
    nextSymbolTable.initializeOffsets(0);

    return nextSymbolTable;
  }

  public void initializeOffsets(int shift) {

    Set<Symbol> variableSymbols = variables.keySet();

    List<Variable> variablesList = variableSymbols.stream()
        .map(variableSymbol ->
            variables.get(variableSymbol))
        .collect(Collectors.toList());

    Consumer<Variable> initialiseOffset = variable -> {
      int memorySize = SymbolTable
          .calculateMemorySize(variable.getType());
      variable.setMemorySize(memorySize);
      totalOffset += memorySize;
    };
    // Count the total offset
    variablesList.forEach(initialiseOffset);

    currentOffset = totalOffset;
    currentOffset += shift;

    // Set the offset for every variable
    variablesList.forEach(this::setVariableCurrentOffset);
  }

  private int setVariableCurrentOffset(Variable variable) {
    currentOffset -= variable.getMemorySize();
    variable.setOffset(currentOffset);

    return currentOffset;
  }

  public int getTotalOffset() {
    return totalOffset;
  }

  static int calculateMemorySize(Type type) {
    if (type instanceof BaseType) {
      switch (((BaseType) type).getType()) {
        case INT:
          return STACK_SIZE_INT;
        case CHAR:
          return STACK_SIZE_CHAR;
        case BOOL:
          return STACK_SIZE_BOOL;
        case STRING:
          return STACK_SIZE_STRING;
      }
    } else if (type instanceof PairType) {
      return STACK_SIZE_PAIR;
    } else if (type instanceof ArrayType) {
      return STACK_SIZE_ARRAY;
    }
    throw new RuntimeException("type of variable not known");
  }

  public int getVariableTotalOffset(String variableName) {
    Symbol varSymbol = Symbol.symbol(variableName);
    Variable variable = getVar(varSymbol);
    Boolean isInitialisedIdentifier = alreadyInitialised.contains(varSymbol);
    if (getParentSymbolTable() != null) {

      if (variable == null || !isInitialisedIdentifier) {
        return totalOffset
            + getParentSymbolTable().getVariableTotalOffset(variableName);
      }
    }

    return variable.getCurrentOffset();
  }

  public void setAlreadyInitialised(Symbol symbol) {
    alreadyInitialised.add(symbol);
  }


  @Override
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("Variables: ");
    for (Symbol symbol : variables.keySet()) {
      stringBuffer.append(symbol.toString()).append(" ");
    }
    stringBuffer.append(", Functions:");
    for (Symbol symbol : functions.keySet()) {
      stringBuffer.append(symbol.toString()).append(" ");
    }
    return String.valueOf(stringBuffer);
  }

}
