package FrontEnd.SymbolTable;

import FrontEnd.Types.Type;

// Class for Variables to be stored in the FrontEnd.SymbolTable.Symbol Table
// has a FrontEnd.Types.Type and a boolean whether it is declared in scope (not a parameter)
public class Variable {

  private Type type;
  private boolean isDeclaredInScope;
  private int memorySize;
  private int currentOffset;

  public Variable(Type type) {
    this.type = type;
    isDeclaredInScope = false;
  }

  public void setDeclaredInScope() {
    isDeclaredInScope = true;
  }

  public boolean getDeclaredInScope() {
    return isDeclaredInScope;
  }

  public Type getType() {
    return type;
  }

  void setMemorySize(int memorySize) {
    this.memorySize = memorySize;
  }

  public int getMemorySize() {
    return memorySize;
  }

  void setOffset(int currentOffset) {
    this.currentOffset = currentOffset;
  }

  public int getCurrentOffset() {
    return currentOffset;
  }
}

