package FrontEnd.SymbolTable;

import FrontEnd.Types.Type;
import java.util.ArrayList;
import java.util.List;

// FrontEnd.SymbolTable.Function Class for functions in symboltable
// has a FrontEnd.Types.Type for returnType and a FrontEnd.Types.Type Array for parameters
// overloaded constructor for no params or params
public class Function {

  private Type returnType;
  private Type[] paramsTypes;
  private SymbolTable symbolTable;

  public Function(Type returnType, Type[] paramsTypes, SymbolTable symbolTable) {
    this.returnType = returnType;
    this.paramsTypes = paramsTypes;
    this.symbolTable = symbolTable;
  }

  public Function(Type returnType, SymbolTable symbolTable) {
    this.returnType = returnType;
    paramsTypes = null;
    this.symbolTable = symbolTable;
  }

  public SymbolTable getSymbolTable() {
    return symbolTable;
  }

  public Type getReturnType() {
    return returnType;
  }

  public Type[] getParamsTypes() {
    return paramsTypes;
  }

  public List<Integer> getParameterOffset() {

    List<Integer> result = new ArrayList<>();

    if (paramsTypes == null) {
      return result;
    }

    for (Type argument : paramsTypes) {
      result.add(SymbolTable.calculateMemorySize(argument));
    }

    return result;
  }

}


