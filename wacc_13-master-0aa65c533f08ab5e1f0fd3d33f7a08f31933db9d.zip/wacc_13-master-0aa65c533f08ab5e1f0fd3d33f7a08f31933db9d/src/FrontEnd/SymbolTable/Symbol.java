package FrontEnd.SymbolTable;

import java.util.HashMap;
import java.util.Map;

// FrontEnd.SymbolTable.Symbol class to optimise searching the Hashmaps
// converts strings to unique symbols for each string
public class Symbol {

  private static Map<String, Symbol> symbols = new HashMap<>();
  private String object;

  public Symbol(String name) {
    object = name;
  }

  @Override
  public String toString() {
    return object;
  }

  public static Symbol symbol(String n) {
    String u = n.intern();
    return symbols.computeIfAbsent(u, k -> new Symbol(u));
  }
}
