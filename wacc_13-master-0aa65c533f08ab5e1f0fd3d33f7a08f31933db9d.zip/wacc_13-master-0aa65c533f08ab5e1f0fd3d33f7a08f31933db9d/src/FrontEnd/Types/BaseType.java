package FrontEnd.Types;

// FrontEnd.Types.BaseType Class
// has a FrontEnd.Types.baseTypeEnum as a base type
public class BaseType implements Type {

    private baseTypeEnum baseT;

    public BaseType (baseTypeEnum baseT) {
        this.baseT = baseT;
    }

    public baseTypeEnum getType() {
        return baseT;
    }

    @Override
    public boolean typeCheck(Type type) {
        // typecheck checks whether type is also a FrontEnd.Types.BaseType class with the same enum
        if (type == null || baseT == null) {
            return true;
        }
        if (type instanceof BaseType){
            return baseT == ((BaseType) type).getType();
        } else {
            return false;
        }
    }

    @Override
    public String toString(){
        return baseT.toString();
    }
}
