package FrontEnd.Types;

// enum for FrontEnd.Types.BaseType Class, Epsilon is to signify the loss of type information in pair types
public enum baseTypeEnum {INT, BOOL, STRING, CHAR, EPSILON}
