package FrontEnd.Types;

// FrontEnd.Types.PairType Class, class for the Pair FrontEnd.Types.Type
// contains two inner types fst and snd of the pair
// has an overloaded constructor for when type information is lost
public class PairType implements Type {

    private Type fst;
    private Type snd;

    public PairType(Type fst, Type snd) {
        this.fst = fst;
        this.snd = snd;
    }

    public PairType () {
        this.fst = new BaseType(baseTypeEnum.EPSILON);
        this.snd = new BaseType(baseTypeEnum.EPSILON);
    }

    public Type getFst() {
        return fst;
    }

    public Type getSnd() {
        return snd;
    }

    @Override
    public boolean typeCheck(Type type) {
        // if the type we are checking against is null or was a pair with a nested pair that has lost type information
        // we can return true as a pairltrl is null
        if (type == null || type.typeCheck(new BaseType(baseTypeEnum.EPSILON))) {
            return true;
        }
        // otherwise it checks if type is an instanceof FrontEnd.Types.PairType
        if (type instanceof PairType) {
            if (fst.typeCheck(new BaseType(baseTypeEnum.EPSILON))) {
                if (snd.typeCheck(new BaseType(baseTypeEnum.EPSILON))) {
                    // if fst and snd have lose type information return true
                    return true;
                }
                // if just fst has lost type information typeCheck snd
                return snd.typeCheck(((PairType) type).getSnd());
            }
            // if just snd has lost type information typeCheck fst
            if (snd.typeCheck(new BaseType(baseTypeEnum.EPSILON))) {
                return fst.typeCheck(((PairType) type).getFst());
            }
            // otherwise typeCheck both fst and snd
            return fst.typeCheck(((PairType) type).getFst()) && snd.typeCheck(((PairType) type).getSnd());
        } else {
            // false if not a FrontEnd.Types.PairType
            return false;
        }
    }

    @Override
    public String toString(){
        if (fst.typeCheck(new BaseType(baseTypeEnum.EPSILON)) && snd.typeCheck(new BaseType(baseTypeEnum.EPSILON))){
            return "Pairtype";
        }
        return "FrontEnd.Types.PairType: " + fst + " " + snd;
    }
}
