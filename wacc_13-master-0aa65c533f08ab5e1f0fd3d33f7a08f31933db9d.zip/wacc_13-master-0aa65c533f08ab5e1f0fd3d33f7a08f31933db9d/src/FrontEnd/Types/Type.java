package FrontEnd.Types;

// Interface for Types as all Types can be typeChecked against one another
public interface Type {

    boolean typeCheck(Type type);

}
