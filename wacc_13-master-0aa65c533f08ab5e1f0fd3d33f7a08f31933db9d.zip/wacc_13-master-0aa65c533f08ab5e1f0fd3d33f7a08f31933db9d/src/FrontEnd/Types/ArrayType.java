package FrontEnd.Types;

// Array Class has a FrontEnd.Types.Type for arrayelemTypes
public class ArrayType implements Type {

    private Type arrayType;

    public ArrayType(Type type) {
        arrayType = type;
    }

    public Type getType(){
        return arrayType;
    }

    public void setType(Type type) {
        arrayType = type;
    }

    @Override
    public boolean typeCheck(Type type) {
        // checks whether type is also an FrontEnd.Types.ArrayType and has the same arrayelem type
        if (type instanceof ArrayType){
            return arrayType.typeCheck(((ArrayType) type).getType());
        } else {
            return false;
        }
    }

    @Override
    public String toString() {
        return "Array type: " + arrayType;
    }
}
