package FrontEnd;

import FrontEnd.SymbolTable.Function;
import FrontEnd.SymbolTable.Symbol;
import FrontEnd.SymbolTable.SymbolTable;
import FrontEnd.SymbolTable.Variable;
import FrontEnd.Types.ArrayType;
import FrontEnd.Types.BaseType;
import FrontEnd.Types.PairType;
import FrontEnd.Types.Type;
import FrontEnd.Types.baseTypeEnum;
import antlr.*;
import antlr.WaccParserParser.BinaryOperation2ExprContext;
import org.antlr.v4.runtime.misc.NotNull;

public class SemanticChecker extends WaccParserBaseVisitor<Type> {
    // Any non-overrided visits just visit their children

    private ErrorHandler errorHandler;
    private SymbolTable currentScopeSymbolTable;

    // FrontEnd.SymbolTable.SymbolTable passed in has a null FrontEnd.SymbolTable.SymbolTable field since it is the global scope
    public SemanticChecker(SymbolTable symbolTable) {
        currentScopeSymbolTable = symbolTable;
        errorHandler = new ErrorHandler();
    }

    // Returns a type for nested arrays by looping through the number of array brackets to build up a nested FrontEnd.Types.Type
    // The base array, the inner most arrayType, is set to null so when it is returned it can be set to the correct
    // base type of the array
    @Override
    public Type visitNestedarray(WaccParserParser.NestedarrayContext ctx) {
        ArrayType nestedArrayType = new ArrayType(null);
        for (int index = 0; ctx.nestedarray().size() > index; index++){
            nestedArrayType = new ArrayType(nestedArrayType);
        }
        return nestedArrayType;
    }

    // Checks whether an array is a nested array or not. If it is then it calls visit on the nested part of the array
    // It then loops through the nested array (with a temp so the tweaked array can be returned)
    // that is returned until it finds the last nested array so it can set the baseType of that array
    @Override
    public Type visitArraytype(WaccParserParser.ArraytypeContext ctx) {
        if (ctx.nestedarray() != null){
            ArrayType nestedArray = (ArrayType) visit(ctx.nestedarray());
            ArrayType lastArray = nestedArray;
            while (lastArray.getType() != null) {
                lastArray = (ArrayType) lastArray.getType();
            }
            lastArray.setType(visit(ctx.getChild(0)));
            return nestedArray;
        }
        return new ArrayType(visit(ctx.getChild(0)));
    }

    // Returns a new FrontEnd.Types.PairType with the inner types of its pairelems from the program
    @Override
    public Type visitPairtype(WaccParserParser.PairtypeContext ctx) {
        return new PairType(visit(ctx.pairelemtype(0)), visit(ctx.pairelemtype(1)));
    }

    // Returns a pairtype with null fields since type information is lost, the nulls can then be type checked against other types and return true
    @Override
    public Type visitPairelemTypePair(WaccParserParser.PairelemTypePairContext ctx) {
        return new PairType();
    }

    // Returns the correct baseType for the given input by checking the text and using a switch case
    // to find the correct case
    @Override
    public Type visitBasetype(WaccParserParser.BasetypeContext ctx) {
        String realType = ctx.BASETYPE().getText();
        Type newBaseType;
        switch (realType) {

            case "int" : newBaseType = new BaseType(baseTypeEnum.INT);
                break;
            case "bool" : newBaseType = new BaseType(baseTypeEnum.BOOL);
                break;
            case "string" : newBaseType = new BaseType(baseTypeEnum.STRING);
                break;
            case "char" : newBaseType = new BaseType(baseTypeEnum.CHAR);
                break;
            default : newBaseType = null;
        }
        return newBaseType;
    }

    // Returns new INT baseType
    @Override
    public Type visitIntltrl(WaccParserParser.IntltrlContext ctx) {
        return new BaseType(baseTypeEnum.INT);
    }

    // Returns new BOOL baseType
    @Override
    public Type visitBoolltrl(WaccParserParser.BoolltrlContext ctx) {
        return new BaseType(baseTypeEnum.BOOL);
    }

    // Returns new CHAR baseType
    @Override
    public Type visitCharltrl(WaccParserParser.CharltrlContext ctx) {
        return new BaseType(baseTypeEnum.CHAR);
    }

    // Returns new STRING baseType
    @Override
    public Type visitStrltrl(WaccParserParser.StrltrlContext ctx) {
        return new BaseType(baseTypeEnum.STRING);
    }

    // Returns null as pairltrl value
    @Override
    public Type visitPairltrl(WaccParserParser.PairltrlContext ctx) {
        return null;
    }

    // Returns new FrontEnd.Types.ArrayType with an inner FrontEnd.Types.Type of its ExpressionType
    @Override
    public Type visitArrayltrl(WaccParserParser.ArrayltrlContext ctx) {
        if (ctx.expr().size() != 0){
        return new ArrayType(visit(ctx.expr(0)));
        }
        return new ArrayType(null);
    }

    // Returns expr FrontEnd.Types.Type
    @Override
    public Type visitBracketedExpr(WaccParserParser.BracketedExprContext ctx) {
        return visit(ctx.expr());
    }

    // Returns the inner FrontEnd.Types.Type of an array (the FrontEnd.Types.Type of its element)
    @Override
    public Type visitArrayelem(WaccParserParser.ArrayelemContext ctx) {
        String varIdent = ctx.IDENT().getText();
        Symbol varSymbol = Symbol.symbol(varIdent);
        Variable variable;
        // if the variable is not in any of the symbol tables it hasn't been defined
        if (currentScopeSymbolTable.getFirstVar(varSymbol) == null) {
            errorHandler.notInScope(ctx.IDENT());
            // not in scope call here
        } else {
            variable = currentScopeSymbolTable.getFirstVar(varSymbol);
            // if it is in the symbol table it can be used in scope so we must typecheck it
            // if the array was a String then we can return a FrontEnd.Types.Type of CHAR
            if (variable.getType().typeCheck(new BaseType(baseTypeEnum.STRING))){
                return new BaseType(baseTypeEnum.CHAR);
            }
            // otherwise if it's an array we return the type of inner FrontEnd.Types.Type
            if (variable.getType() instanceof ArrayType) {
                return ((ArrayType) variable.getType()).getType();
            } else {
                errorHandler.typeError(ctx.IDENT(),"", new ArrayType(null), variable.getType());
            }
        }
        return null;
    }

    // Returns a new FrontEnd.Types.PairType with the inner Types of its expressions
    @Override
    public Type visitAssignrhsPair(WaccParserParser.AssignrhsPairContext ctx) {
        return new PairType(visit(ctx.expr(0)), visit(ctx.expr(1)));
    }

    // Returns the ReturnType of the function being called
    @Override
    public Type visitAssignrhsFunctionCall(WaccParserParser.AssignrhsFunctionCallContext ctx) {
        String funcName = ctx.ident().getText();
        Symbol funcSymbol = Symbol.symbol(funcName);
        // if no FrontEnd.SymbolTable.Symbol Table has the function then it is not declared
        if (currentScopeSymbolTable.getFirstFunc(funcSymbol) == null) {
            // function not defined aka not in scope
            errorHandler.notInScope(ctx.ident());
        }
        Function function = currentScopeSymbolTable.getFirstFunc(funcSymbol);
        Type[] functionParams = function.getParamsTypes();

        // have to check null cases to prevent nullPtr exception
        if (functionParams == null) {
            if ((ctx.arglist() != null)) {
                // if the function has no params in the table but the argument list called with does
                // then we exit as the parameters do not match up
                errorHandler.functionArguments(ctx.ident(), 0, ctx.arglist().expr().size() );
            }
            else {
                // if the function has no params and the arglist is null then they both have
                // the same number of arguments so we can return the ReturnType
                return currentScopeSymbolTable.getFirstFunc(funcSymbol).getReturnType();
            }
        }
        if (ctx.arglist() == null) {
            if (functionParams != null) {
                // if the argument list is null but the function has parameters then we exit
                errorHandler.functionArguments(ctx.ident(), functionParams.length, 0);
            }
        }
        if (functionParams != null) {
            if (functionParams.length != ctx.arglist().expr().size()) {
                // if the func parameters and arguments do not match in number we exit
                errorHandler.functionArguments(ctx.ident(), functionParams.length, ctx.arglist().expr().size());
            } else {
                // otherwise we can check each parameter has the correct type with the argument list
                int index = 0;
                while (ctx.arglist().expr().size() > index) {
                    Type paramType = visit(ctx.arglist().expr(index));
                    if (!functionParams[index].typeCheck(paramType)) {
                        // exit if the types do not match
                        errorHandler.typeError(ctx.arglist(), ("FrontEnd.SymbolTable.Function " + funcName + " Parameter " + ctx.arglist().expr(index).getText()), functionParams[index], paramType);
                    }
                    index++;
                }
            }
        }
        return currentScopeSymbolTable.getFirstFunc(funcSymbol).getReturnType();
    }

    // Returns the type of the First element in a FrontEnd.Types.PairType
    @Override
    public Type visitPairElemFst(WaccParserParser.PairElemFstContext ctx) {
        Type expression = visit(ctx.expr());
        if (expression instanceof PairType) {
            return ((PairType) expression).getFst();
        } else {
            // function applied to wrong type
            errorHandler.typeError(ctx, "fst applied to input expression of incorrect type", new PairType(), expression);
        }
        return null;
    }

    // Returns the type of the Second element in a FrontEnd.Types.PairType
    @Override
    public Type visitPairElemSnd(WaccParserParser.PairElemSndContext ctx) {
        Type expression = visit(ctx.expr());
        if (expression instanceof PairType) {
            return ((PairType) expression).getSnd();
        } else {
            // function applied to wrong type
            errorHandler.typeError(ctx, "fst applied to input expression of incorrect type", new PairType(), expression);
        }
        return null;
    }

    // Checks whether exit code is an INT, returns INT baseType
    @Override
    public Type visitExitStatement(WaccParserParser.ExitStatementContext ctx) {
        Type exprType = visit(ctx.expr());

        if(!(exprType.typeCheck(new BaseType(baseTypeEnum.INT)))) {
            errorHandler.typeError(ctx, "Exit Statement given expression not of type INT",new BaseType(baseTypeEnum.INT), exprType );
        }

        return null;
    }

    // Visits the && and || operators, Returns a type BOOL
    @Override
    public Type visitLogicalOperationExpr(WaccParserParser.LogicalOperationExprContext ctx) {

        Type typeExpr1 = visit(ctx.expr(0));
        Type typeExpr2 = visit(ctx.expr(1));

        // if both expressions aren't of type BOOL we exit
        if (!typeExpr1.typeCheck(new BaseType(baseTypeEnum.BOOL))
                || !typeExpr2.typeCheck(new BaseType(baseTypeEnum.BOOL))) {
            errorHandler.typeOpError(ctx, ctx.logicaloper().getText(),new Type[] {new BaseType(baseTypeEnum.BOOL)}, typeExpr1, typeExpr2);
        }
        return new BaseType(baseTypeEnum.BOOL);
    }

    // FrontEnd.Types.Type checks binaryOperators and returns an INT or BOOL depending on the operator

    @Override
    public Type visitBinaryOperation1Expr(WaccParserParser.BinaryOperation1ExprContext ctx) {
        String binaryOperator = ctx.binaryoper1().getText();
        Type typeExpr1 = visit(ctx.expr(0));
        Type typeExpr2 = visit(ctx.expr(1));

//         the following operators can only take expressions of INT '*' '/' '%' '+' '-'
        if ((binaryOperator.matches(".*[*/%+-].*"))
                && (!typeExpr1.typeCheck(new BaseType(baseTypeEnum.INT))
                || !typeExpr2.typeCheck(new BaseType(baseTypeEnum.INT)))) {
            errorHandler.typeOpError(ctx, binaryOperator,new Type[] {new BaseType(baseTypeEnum.INT)}, typeExpr1, typeExpr2 );
        }

//         the following operators can only take expressions of both INT or CHAR '<' '>' '<=' '>='
        if ((binaryOperator.matches(".*[><].*")
                || binaryOperator.equals("<=")
                || binaryOperator.equals(">="))
                && !(typeExpr1.typeCheck(typeExpr2)
                && (typeExpr1.typeCheck(new BaseType(baseTypeEnum.CHAR))
                || typeExpr1.typeCheck(new BaseType(baseTypeEnum.INT))))) {

            errorHandler.typeOpError(ctx, binaryOperator,new Type[] {new BaseType(baseTypeEnum.INT), new BaseType(baseTypeEnum.CHAR)}, typeExpr1, typeExpr2);
        }

//         the following operators can only take expressions of both INT, CHAR, BOOL or PAIR '==' '!='
        if ((binaryOperator.equals("==")
                || binaryOperator.equals("!="))
                && !typeExpr1.typeCheck(typeExpr2)
                && (!typeExpr1.typeCheck(new BaseType(baseTypeEnum.CHAR))
                || !typeExpr1.typeCheck(new BaseType(baseTypeEnum.BOOL))
                || !typeExpr1.typeCheck(new BaseType(baseTypeEnum.INT))
                || !(typeExpr1 instanceof PairType))) {
            errorHandler.typeOpError(ctx, binaryOperator,new Type[] {new BaseType(baseTypeEnum.INT), new BaseType(baseTypeEnum.CHAR), new BaseType(baseTypeEnum.BOOL), new PairType()}, typeExpr1, typeExpr2);
        }

//         the following operators then return a BOOL type
        if (binaryOperator.equals("<=") || binaryOperator.equals(">=") || binaryOperator.equals("==")
                || binaryOperator.equals("!=") || binaryOperator.equals("<") || binaryOperator.equals(">")) {
            return new BaseType(baseTypeEnum.BOOL);
        }

//         the other operators then return an INT type
        return new BaseType(baseTypeEnum.INT);
    }

    @Override
    public Type visitBinaryOperation2Expr(@NotNull BinaryOperation2ExprContext ctx) {
        String binaryOperator = ctx.binaryoper2().getText();
        Type typeExpr1 = visit(ctx.expr(0));
        Type typeExpr2 = visit(ctx.expr(1));

//         the following operators can only take expressions of INT '*' '/' '%' '+' '-'
        if ((binaryOperator.matches(".*[*/%+-].*"))
            && (!typeExpr1.typeCheck(new BaseType(baseTypeEnum.INT))
            || !typeExpr2.typeCheck(new BaseType(baseTypeEnum.INT)))) {
            errorHandler.typeOpError(ctx, binaryOperator,new Type[] {new BaseType(baseTypeEnum.INT)}, typeExpr1, typeExpr2 );
        }

//         the following operators can only take expressions of both INT or CHAR '<' '>' '<=' '>='
        if ((binaryOperator.matches(".*[><].*")
            || binaryOperator.equals("<=")
            || binaryOperator.equals(">="))
            && !(typeExpr1.typeCheck(typeExpr2)
            && (typeExpr1.typeCheck(new BaseType(baseTypeEnum.CHAR))
            || typeExpr1.typeCheck(new BaseType(baseTypeEnum.INT))))) {

            errorHandler.typeOpError(ctx, binaryOperator,new Type[] {new BaseType(baseTypeEnum.INT), new BaseType(baseTypeEnum.CHAR)}, typeExpr1, typeExpr2);
        }

//         the following operators can only take expressions of both INT, CHAR, BOOL or PAIR '==' '!='
        if ((binaryOperator.equals("==")
            || binaryOperator.equals("!="))
            && !typeExpr1.typeCheck(typeExpr2)
            && (!typeExpr1.typeCheck(new BaseType(baseTypeEnum.CHAR))
            || !typeExpr1.typeCheck(new BaseType(baseTypeEnum.BOOL))
            || !typeExpr1.typeCheck(new BaseType(baseTypeEnum.INT))
            || !(typeExpr1 instanceof PairType))) {
            errorHandler.typeOpError(ctx, binaryOperator,new Type[] {new BaseType(baseTypeEnum.INT), new BaseType(baseTypeEnum.CHAR), new BaseType(baseTypeEnum.BOOL), new PairType()}, typeExpr1, typeExpr2);
        }

//         the following operators then return a BOOL type
        if (binaryOperator.equals("<=") || binaryOperator.equals(">=") || binaryOperator.equals("==")
            || binaryOperator.equals("!=") || binaryOperator.equals("<") || binaryOperator.equals(">")) {
            return new BaseType(baseTypeEnum.BOOL);
        }

//        the other operators then return an INT type
        return new BaseType(baseTypeEnum.INT);
    }

    @Override
    public Type visitBinaryOperation3Expr(WaccParserParser.BinaryOperation3ExprContext ctx) {
        String binaryOperator = ctx.binaryoper3().getText();
        Type typeExpr1 = visit(ctx.expr(0));
        Type typeExpr2 = visit(ctx.expr(1));

//         the following operators can only take expressions of INT '*' '/' '%' '+' '-'
        if ((binaryOperator.matches(".*[*/%+-].*"))
            && (!typeExpr1.typeCheck(new BaseType(baseTypeEnum.INT))
            || !typeExpr2.typeCheck(new BaseType(baseTypeEnum.INT)))) {
            errorHandler.typeOpError(ctx, binaryOperator,new Type[] {new BaseType(baseTypeEnum.INT)}, typeExpr1, typeExpr2 );
        }

//         the following operators can only take expressions of both INT or CHAR '<' '>' '<=' '>='
        if ((binaryOperator.matches(".*[><].*")
            || binaryOperator.equals("<=")
            || binaryOperator.equals(">="))
            && !(typeExpr1.typeCheck(typeExpr2)
            && (typeExpr1.typeCheck(new BaseType(baseTypeEnum.CHAR))
            || typeExpr1.typeCheck(new BaseType(baseTypeEnum.INT))))) {

            errorHandler.typeOpError(ctx, binaryOperator,new Type[] {new BaseType(baseTypeEnum.INT), new BaseType(baseTypeEnum.CHAR)}, typeExpr1, typeExpr2);
        }

//         the following operators can only take expressions of both INT, CHAR, BOOL or PAIR '==' '!='
        if ((binaryOperator.equals("==")
            || binaryOperator.equals("!="))
            && !typeExpr1.typeCheck(typeExpr2)
            && (!typeExpr1.typeCheck(new BaseType(baseTypeEnum.CHAR))
            || !typeExpr1.typeCheck(new BaseType(baseTypeEnum.BOOL))
            || !typeExpr1.typeCheck(new BaseType(baseTypeEnum.INT))
            || !(typeExpr1 instanceof PairType))) {
            errorHandler.typeOpError(ctx, binaryOperator,new Type[] {new BaseType(baseTypeEnum.INT), new BaseType(baseTypeEnum.CHAR), new BaseType(baseTypeEnum.BOOL), new PairType()}, typeExpr1, typeExpr2);
        }

//         the following operators then return a BOOL type
        if (binaryOperator.equals("<=") || binaryOperator.equals(">=") || binaryOperator.equals("==")
            || binaryOperator.equals("!=") || binaryOperator.equals("<") || binaryOperator.equals(">")) {
            return new BaseType(baseTypeEnum.BOOL);
        }

//         the other operators then return an INT type
        return new BaseType(baseTypeEnum.INT);
    }

    @Override
    public Type visitBinaryOperation4Expr(WaccParserParser.BinaryOperation4ExprContext ctx) {
        String binaryOperator = ctx.binaryoper4().getText();
        Type typeExpr1 = visit(ctx.expr(0));
        Type typeExpr2 = visit(ctx.expr(1));

//         the following operators can only take expressions of INT '*' '/' '%' '+' '-'
        if ((binaryOperator.matches(".*[*/%+-].*"))
            && (!typeExpr1.typeCheck(new BaseType(baseTypeEnum.INT))
            || !typeExpr2.typeCheck(new BaseType(baseTypeEnum.INT)))) {
            errorHandler.typeOpError(ctx, binaryOperator,new Type[] {new BaseType(baseTypeEnum.INT)}, typeExpr1, typeExpr2 );
        }

//         the following operators can only take expressions of both INT or CHAR '<' '>' '<=' '>='
        if ((binaryOperator.matches(".*[><].*")
            || binaryOperator.equals("<=")
            || binaryOperator.equals(">="))
            && !(typeExpr1.typeCheck(typeExpr2)
            && (typeExpr1.typeCheck(new BaseType(baseTypeEnum.CHAR))
            || typeExpr1.typeCheck(new BaseType(baseTypeEnum.INT))))) {

            errorHandler.typeOpError(ctx, binaryOperator,new Type[] {new BaseType(baseTypeEnum.INT), new BaseType(baseTypeEnum.CHAR)}, typeExpr1, typeExpr2);
        }

//         the following operators can only take expressions of both INT, CHAR, BOOL or PAIR '==' '!='
        if ((binaryOperator.equals("==")
            || binaryOperator.equals("!="))
            && !typeExpr1.typeCheck(typeExpr2)
            && (!typeExpr1.typeCheck(new BaseType(baseTypeEnum.CHAR))
            || !typeExpr1.typeCheck(new BaseType(baseTypeEnum.BOOL))
            || !typeExpr1.typeCheck(new BaseType(baseTypeEnum.INT))
            || !(typeExpr1 instanceof PairType))) {
            errorHandler.typeOpError(ctx, binaryOperator,new Type[] {new BaseType(baseTypeEnum.INT), new BaseType(baseTypeEnum.CHAR), new BaseType(baseTypeEnum.BOOL), new PairType()}, typeExpr1, typeExpr2);
        }

//         the following operators then return a BOOL type
        if (binaryOperator.equals("<=") || binaryOperator.equals(">=") || binaryOperator.equals("==")
            || binaryOperator.equals("!=") || binaryOperator.equals("<") || binaryOperator.equals(">")) {
            return new BaseType(baseTypeEnum.BOOL);
        }

//         the other operators then return an INT type
        return new BaseType(baseTypeEnum.INT);
    }

    // FrontEnd.Types.Type checks unaryOperators and returns the type of the expr or a CHAR or INT depending on the unaryOP
    @Override
    public Type visitUnaryOperationExpr(WaccParserParser.UnaryOperationExprContext ctx) {

        Type exprType = visit(ctx.unaryexpr().expr());
        String unaryOperation = ctx.unaryexpr().unaryoper().getText();

        if (unaryOperation.equals("!")
                && !exprType.typeCheck(new BaseType(baseTypeEnum.BOOL))) {
            // unaryoperator error function
            errorHandler.typeUnaryOpError(ctx, ctx.getText(), new BaseType(baseTypeEnum.BOOL), exprType);
        } else if ((!exprType.typeCheck(new BaseType(baseTypeEnum.INT))
                && (unaryOperation.matches(".*[+-].*") || unaryOperation.equals("chr")))) {
            errorHandler.typeUnaryOpError(ctx, ctx.getText(), new BaseType(baseTypeEnum.INT), exprType);
        } else if (unaryOperation.equals("len") && !(exprType instanceof ArrayType)) {
            errorHandler.typeUnaryOpError(ctx, ctx.getText(), new ArrayType(null), exprType);
        } else if (!exprType.typeCheck(new BaseType(baseTypeEnum.CHAR))
                && unaryOperation.equals("ord")) {
            errorHandler.typeUnaryOpError(ctx, ctx.getText(), new BaseType(baseTypeEnum.CHAR), exprType);
        }

        // len and ord return INT and chr returns CHAR
        if (unaryOperation.equals("chr")) {
            return new BaseType(baseTypeEnum.CHAR);
        }
        if (unaryOperation.equals("len") || unaryOperation.equals("ord")) {
            return new BaseType(baseTypeEnum.INT);
        }
        return exprType;
    }

    // Returns the FrontEnd.Types.Type of the variable stored under the ident in the symbol table, if not present
    // throws an error
    @Override
    public Type visitIdent(WaccParserParser.IdentContext ctx) {
        String identName = ctx.IDENT().getText();
        Symbol identSymbol = Symbol.symbol(identName);
        Variable var = currentScopeSymbolTable.getFirstVar(identSymbol);


        if (var == null) {
            errorHandler.notInScope(ctx.IDENT());
        }

        assert var != null;
        return var.getType();
    }

    @Override
    public Type visitSkipStatement(WaccParserParser.SkipStatementContext ctx) {
        return null;
    }

    // typeChecks the FrontEnd.Types.Type with the RHS FrontEnd.Types.Type, returns null because doesn't need to be typeChecked on return
    @Override
    public Type visitDeclareStatement(WaccParserParser.DeclareStatementContext ctx) {
        Type rhs = visit(ctx.assignrhs());
        Type varType = visit(ctx.type());
        Symbol varSymbol = Symbol.symbol(ctx.ident().getText());
        Variable variable =  new Variable(varType);

        // if the variable doesn't typeCheck with the rhs then exit
        if (!variable.getType().typeCheck(rhs)) {
            errorHandler.typeError(ctx,"between " + ctx.ident().getText() + " and " + ctx.assignrhs().getText() ,varType, rhs);
        }
        else {
            // otherwise we check if the variable exists in the scope and is declared in the scope
            // (we need the boolean declaredInScope because for example the parameters of a function are added to
            // the scope but they do not count as declared) we exit if they are true
            if (currentScopeSymbolTable.getVar(varSymbol) != null
                    && currentScopeSymbolTable.getVar(varSymbol).getDeclaredInScope()) {
                errorHandler.redefintion(ctx.ident());
            }
            // else we just declare the variable and add it to the table
            variable.setDeclaredInScope();
            currentScopeSymbolTable.addVar(varSymbol, variable);

        }
        return null;
    }

    // typeChecks the lhs and rhs and returns null since the return does not need to be typeChecked
    // exits if the type do not match
    @Override
    public Type visitAssignStatement(WaccParserParser.AssignStatementContext ctx) {
        Type lhsType = visit(ctx.assignlhs());
        Type rhsType = visit(ctx.assignrhs());

        if(!lhsType.typeCheck(rhsType)) {
            errorHandler.typeError(ctx, "between assignment of " + ctx.assignlhs().getText() + " and " + ctx.assignrhs().getText(), lhsType, rhsType);
        }

        return null;
    }

    // Read statements cant take anything other than INT or CHAR
    @Override
    public Type visitReadStatement(WaccParserParser.ReadStatementContext ctx) {
        Type lhsType = visit(ctx.assignlhs());

        if (!(lhsType.typeCheck(new BaseType(baseTypeEnum.INT)) || lhsType.typeCheck(new BaseType(baseTypeEnum.CHAR)))) {
            errorHandler.readInput(ctx, lhsType);
        }

        return null;
    }

    // Free statements can only be of FrontEnd.Types.Type Array or Pair
    @Override
    public Type visitFreeStatement(WaccParserParser.FreeStatementContext ctx) {
        Type exprType = visit(ctx.expr());

        if(!(exprType instanceof ArrayType
                || exprType instanceof PairType)){
            errorHandler.freeInput(ctx, exprType);
        }

        return null;
    }

    @Override
    public Type visitPrintStatement(WaccParserParser.PrintStatementContext ctx) {
        visit(ctx.expr());
        return null;
    }

    @Override
    public Type visitPrintlnStatement(WaccParserParser.PrintlnStatementContext ctx) {
        visit(ctx.expr());
        return null;
    }

    // typeChecks the condition of the if to be of type bool returns elseType or thenType of relevant bodies
    @Override
    public Type visitIfStatement(WaccParserParser.IfStatementContext ctx) {
        Type ifCond = visit(ctx.expr());

        if (!(ifCond.typeCheck(new BaseType(baseTypeEnum.BOOL)))) {
            errorHandler.typeError(ctx, "If Statement Condition", new BaseType(baseTypeEnum.BOOL), ifCond);
        }

        // makes scope for then
        currentScopeSymbolTable = new SymbolTable(currentScopeSymbolTable);
        // visits then body
        Type thenType = visit(ctx.stat(0));
        // goes back to outer scope
        currentScopeSymbolTable.getParentSymbolTable().addChildSymbolTable(currentScopeSymbolTable);
        currentScopeSymbolTable = currentScopeSymbolTable.getParentSymbolTable();
        // makes new scope for else
        currentScopeSymbolTable = new SymbolTable(currentScopeSymbolTable);
        // visits else body
        Type elseType = visit(ctx.stat(1));
        // goes back to outter scope
        currentScopeSymbolTable.getParentSymbolTable().addChildSymbolTable(currentScopeSymbolTable);
        currentScopeSymbolTable = currentScopeSymbolTable.getParentSymbolTable();
        // if thenType is null (i.e ended with a print)
        // then return elseType otherwise vice versa
        if (thenType == null){
            return elseType;
        }
        return thenType;
    }

    // returns the returnType at the end of the while
    @Override
    public Type visitWhileStatement(WaccParserParser.WhileStatementContext ctx) {
        Type whileCond = visit(ctx.expr());
        // checks while cond is of type BOOL
        if (!(whileCond.typeCheck(new BaseType(baseTypeEnum.BOOL)))) {
            errorHandler.typeError(ctx, "While Statement Condition", new BaseType(baseTypeEnum.BOOL), whileCond);
        }
        // makes a new scope for the while body
        currentScopeSymbolTable = new SymbolTable(currentScopeSymbolTable);
        // visits the body while still within the scope and gets the returnType
        Type bodyType = visit(ctx.stat());
        // returns back to the outer scope once its visited the body
        currentScopeSymbolTable.getParentSymbolTable().addChildSymbolTable(currentScopeSymbolTable);
        currentScopeSymbolTable = currentScopeSymbolTable.getParentSymbolTable();


        return bodyType;
    }

    // returns the returnType of the body
    @Override
    public Type visitBeginStatement(WaccParserParser.BeginStatementContext ctx) {
        // makes a new scope
        currentScopeSymbolTable = new SymbolTable(currentScopeSymbolTable);
        // visits the body while within the scope
        Type bodyType = visit(ctx.stat());
        // goes back to the outter scope
        currentScopeSymbolTable.getParentSymbolTable().addChildSymbolTable(currentScopeSymbolTable);
        currentScopeSymbolTable = currentScopeSymbolTable.getParentSymbolTable();

        return bodyType;
    }

    // returns the returnType of the last stat
    @Override
    public Type visitSeqComposition(WaccParserParser.SeqCompositionContext ctx) {
        visit(ctx.stat(0));
        return visit(ctx.stat(1));
    }

    @Override
    public Type visitParamlist(WaccParserParser.ParamlistContext ctx) {
        if (ctx.param().size() != 0) {
            for (int i = ctx.param().size() - 1; i>= 0; i--) {
                Type paramType = visit(ctx.param(i).type());
                String paramName = ctx.param(i).ident().getText();
                Symbol paramSymbol = Symbol.symbol(paramName);
                Variable param = new Variable(paramType);
                currentScopeSymbolTable.addVar(paramSymbol, param);
            }
        }
        return null;
    }

    // returns the FrontEnd.Types.Type of the parameter and adds the parameter to the current scope (notDeclared)

    // returns the return FrontEnd.Types.Type of a function
    @Override
    public Type visitFunc(WaccParserParser.FuncContext ctx) {
        // if the functions has parameters, visit them
        if (ctx.paramlist() != null) {
            visit(ctx.paramlist());
        }
        currentScopeSymbolTable = new SymbolTable(currentScopeSymbolTable);
        // returnType is the function return FrontEnd.Types.Type
        Type returnType = visit(ctx.type());
        // thebodyType is the return type of the last stat in the function
        Type bodyType = visit(ctx.stat());
        // checks whether the returnType and bodyType match
        currentScopeSymbolTable.getParentSymbolTable().addChildSymbolTable(currentScopeSymbolTable);
        currentScopeSymbolTable = currentScopeSymbolTable.getParentSymbolTable();
        if (!returnType.typeCheck(bodyType)) {
            errorHandler.typeError(ctx, "between Return type of " + ctx.ident().getText() + " and return in function body", returnType, bodyType);
        }

        return returnType;
    }

    // returns null as doesn't need to be FrontEnd.Types.Type checked
    @Override
    public Type visitProgram(WaccParserParser.ProgramContext ctx) {
        // checks if there is a return in the program scope
        // exits if there is
        if (ctx.stat().getText().contains("return")) {
            errorHandler.returnNotAllowed(ctx.stat());
        }
        // loops through all the functions of the program
        for (WaccParserParser.FuncContext func : ctx.func()) {
            String funcName = func.ident().getText();
            Symbol funcSymbol = Symbol.symbol(funcName);
            Type returnType = visit(func.type());
            // if the func is already in the table then it is already previously defined
            if (currentScopeSymbolTable.getFunc(funcSymbol) != null) {
                errorHandler.redefintion(func.ident());
            }
            // create a new scope for each function
            currentScopeSymbolTable = new SymbolTable(currentScopeSymbolTable);
            // funcParams is an array to hold the parameters
            Type[] funcParams;
            // if there are no params we set it to null
            if (func.paramlist() == null){
                currentScopeSymbolTable.getParentSymbolTable().addFunc(funcSymbol, new Function(returnType, currentScopeSymbolTable));
            } else {
                // otherwise we create a FrontEnd.Types.Type Array of the same size as the paramlist
                funcParams = new Type[func.paramlist().param().size()];
                int index = func.paramlist().param().size() - 1;
                while (index >= 0) {
                    funcParams[index] = visit(func.paramlist().param(index).type());
                    index--;
                }
                currentScopeSymbolTable.getParentSymbolTable().addFunc(funcSymbol, new Function(returnType, funcParams, currentScopeSymbolTable));
            }
        // we go back to the program scope
            currentScopeSymbolTable.getParentSymbolTable().addChildSymbolTable(currentScopeSymbolTable);
            currentScopeSymbolTable = currentScopeSymbolTable.getParentSymbolTable();
        }
        for (WaccParserParser.FuncContext func : ctx.func()){
            // enter the scope of the function, visit it then return to parent symbol table
            currentScopeSymbolTable = currentScopeSymbolTable.getFirstFunc(
                Symbol.symbol(func.ident().getText())).getSymbolTable();
            visit(func);
            currentScopeSymbolTable = currentScopeSymbolTable.getParentSymbolTable();
        }
        // once we have visited all the functions we visit the body of the program
        visit(ctx.stat());
        return null;
    }

}
