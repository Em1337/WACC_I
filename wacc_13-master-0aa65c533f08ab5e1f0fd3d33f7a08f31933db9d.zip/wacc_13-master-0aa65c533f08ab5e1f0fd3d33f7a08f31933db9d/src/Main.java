// import Parser and Lexer
import BackEnd.CodeGeneratorVisitor;
import BackEnd.Program;
import FrontEnd.ErrorHandler;
import FrontEnd.Optimiser;
import FrontEnd.SemanticChecker;
import FrontEnd.SymbolTable.SymbolTable;
import FrontEnd.SyntaxAnalyser;
import antlr.*;

// import ANTLR's runtime libraries
import java.io.FileInputStream;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

public class Main {

  public static void main(String[] args) throws Exception {

    if (args.length == 1) {
      System.setIn(new FileInputStream(args[0]));
    }
    // create a CharStream that reads from first argument
    ANTLRInputStream input = new ANTLRInputStream(System.in);
    // create a lexer that feeds off of input CharStream
    WaccParserLexer lexer = new WaccParserLexer(input);
    // create a buffer of tokens pulled from the lexer
    CommonTokenStream tokens = new CommonTokenStream(lexer);
    // create a parser that feeds off the tokens buffer
    WaccParserParser parser = new WaccParserParser(tokens);

    // remove ConsoleErrorListener
    parser.removeErrorListeners();
    // Set Error listener to our Error Handler
    parser.addErrorListener(new ErrorHandler());
    // begin parsing at program rule
    ParseTree tree = parser.program();
    //Create Syntax Analyser
    SyntaxAnalyser syntaxAnalyser = new SyntaxAnalyser();


    //Run Syntax Analysis Pass on AST
    syntaxAnalyser.visit(tree);

    // Create a symbolTable for program scope for Semantic Checker
    SymbolTable symbolTable = new SymbolTable();

    // create a new Semantic Checker with the symboltable
    SemanticChecker semanticChecker = new SemanticChecker(symbolTable);
    // visit the tree with the Semantic Checker
    semanticChecker.visit(tree);

    CodeGeneratorVisitor codeGeneratorVisitor = new CodeGeneratorVisitor(symbolTable);
    codeGeneratorVisitor.visit(tree);
    Program thisProgram = codeGeneratorVisitor.getProgram();
    Optimiser optimser = new Optimiser(thisProgram);
    optimser.optimiseMainInstructions();
    optimser.optimiseFunctionInstructions();


    FileWriter fileWriter = new FileWriter(args[0]);

    fileWriter.writeToFile(thisProgram);
  }
}

